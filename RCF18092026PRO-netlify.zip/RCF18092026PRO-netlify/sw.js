/* Service Worker — ريلز القرآن Pro (P3 + v33)
   استراتيجية: App Shell يُخزن مسبقاً، والملاحة تسقط إلى offline.html عند انقطاع الشبكة.
   v33: حفظ كامل + تقسية. v32: الاسم تحت الشعار. v31: تأثيرات الشعار/التذييل.
   ملاحظة: ملفات الصوت/الخطوط الخارجية (everyayah/jsdelivr) تُترك للشبكة ولا تُخزن لتفادي الحجم والـ CORS. */
const CACHE_NAME = 'quran-reels-v33';
// ASSET_V33: نفس ?v= الموجود في index.html — أي نشر جديد يستلزم رفع الرقم هنا وفي index.html معاً.
const APP_SHELL = [
  './',
  './index.html',
  './offline.html',
  './404.html',
  './manifest.webmanifest',
  './icon.svg',
  './icon-192.png',
  './icon-512.png',
  './icon-maskable-512.png',
  './apple-touch-icon.png',
  './og-cover.png',
  './css/base.css?v=30',
  './css/responsive.css?v=6',
  './js/state.js?v=32',
  './js/api.js?v=16',
  './js/quran.js?v=16',
  './js/audio.js?v=4',
  './js/video.js?v=13',
  './js/canvas.js?v=32',
  './js/timeline.js?v=4',
  './js/projects.js?v=33',
  './js/presets.js?v=19',
  './js/ui.js?v=32',
  './js/app.js?v=4'
];

self.addEventListener('install', event => {
  // v4: تخزين مرن — فشل ملف واحد لا يُفشل التثبيت كله (مشكلة cache.addAll السابقة).
  event.waitUntil(
    caches.open(CACHE_NAME).then(async cache => {
      await Promise.all(APP_SHELL.map(async url => {
        try { await cache.add(url); }
        catch (e) { console.warn('SW: تعذر تخزين', url, e?.message || e); }
      }));
      await self.skipWaiting();
    })
  );
});

self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys().then(keys =>
      Promise.all(keys.filter(k => k !== CACHE_NAME).map(k => caches.delete(k)))
    ).then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', event => {
  const req = event.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);
  // خارج النطاق: اتركه للشبكة (APIs + صوتيات + خطوط CDN).
  if (url.origin !== self.location.origin) return;
  // التنقل بين الصفحات: شبكة أولاً ثم offline.
  if (req.mode === 'navigate') {
    event.respondWith(
      fetch(req).catch(() => caches.match('./offline.html'))
    );
    return;
  }
  // الأصول المحلية: كاش أولاً ثم شبكة مع تحديث الكاش.
  // ملاحظة: تجاهل ?v= عند المطابقة حتى لا تتضاعف الإدخالات بين النشرات.
  event.respondWith(
    caches.match(req, { ignoreSearch: true }).then(hit => {
      const net = fetch(req).then(res => {
        if (res && res.ok) {
          const copy = res.clone();
          caches.open(CACHE_NAME).then(c => c.put(req, copy)).catch(() => {});
        }
        return res;
      }).catch(() => hit);
      return hit || net;
    })
  );
});
