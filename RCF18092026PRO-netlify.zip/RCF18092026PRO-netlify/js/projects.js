// ============ المرحلة 1: محرك المشروع والحفظ التلقائي ============
const projectControlIds = [
  'surahSelect','riwayahSelect','ayahRangeToggle','startAyah','endAyah','translationSelect','tafsirToggle','captionText',
  'reciterSelect','audioModeReciter','audioModeUpload','fontFamilySelect','fontSizeRange','fontColorPicker','fontWeightSelect','lineHeightRange',
  'fontBgColorPicker','fontBgOpacityRange','fontBorderColorPicker','fontBorderWidthRange','fontBorderRadiusRange','fontShadowSelect',
  'transFontFamilySelect','transFontSizeRange','transFontColorPicker','transFontWeightSelect','transLineHeightRange','transFontBgColorPicker',
  'transFontBgOpacityRange','transFontBorderColorPicker','transFontBorderWidthRange','transFontBorderRadiusRange','transFontShadowSelect',
  'effectSelect','effectSpeedRange','quranTextEffectSelect','quranTextEffectIntensityRange','quranMotionEffectSelect','quranMotionIntensityRange',
  'translationTransitionSelect','translationEffectSpeedRange','translationTextEffectSelect','translationTextEffectIntensityRange','translationMotionEffectSelect','translationMotionIntensityRange',
  'logoUpload','logoSizeRange','logoPositionSelect','logoOpacityRange','logoBorderWidthRange','logoBorderColorPicker','logoNameInput','logoNameFontSelect','logoNameSizeRange','logoNameGapRange','logoNameOpacityRange','logoNameColorPicker',
  'footerTextInput','footerFontSelect','footerSizeRange','footerOpacityRange','footerColorPicker',
  'logoTransitionSelect','logoTextEffectSelect','logoMotionEffectSelect','footerTransitionSelect','footerTextEffectSelect','footerMotionEffectSelect',
  'gradientEffectSelect','particleEffectToggle','vignetteEffectToggle','videoFormatSelect','exportModeSelect','finalExportQualitySelect','videoBrightnessRange','videoContrastRange','videoSaturationRange','videoWarmthRange','videoHueRange','videoBlurRange','videoVignetteRange','videoExposureRange','videoBlackPointRange'
  ,'presetBackgroundContrastRange','presetBackgroundSpeedRange'
];

function normalizeHexColor(value, fallback = '#d4af37') {
  const color = String(value ?? '').trim();
  return /^#[0-9a-fA-F]{3}(?:[0-9a-fA-F]{3})?$/.test(color) ? color : fallback;
}

function getProjectStore() {
  try {
    const raw = localStorage.getItem(PROJECT_STORAGE_KEY);
    const parsed = raw ? JSON.parse(raw) : [];
    return Array.isArray(parsed) ? parsed : [];
  } catch (e) { console.warn('تعذر قراءة المشاريع المحفوظة:', e); return []; }
}

function setProjectStore(projects) { try { localStorage.setItem(PROJECT_STORAGE_KEY, JSON.stringify(projects)); } catch (e) { throw new Error('تعذر حفظ المشاريع: مساحة التخزين المحلية ممتلئة أو غير متاحة.'); } }

// P0-2: options.forStorage=true يحفظ مراجع خفيفة فقط (سورة/نطاق/رواية/مفاتيح) بدل النصوص الكاملة
// لتفادي فيضان localStorage (المختصر في التفسير + ترجمات قد تتجاوز 1MB للمشروع الواحد).
// السجل (Undo) وملف التصدير يستخدمان النسخة الكاملة، والتخزين المحلي يستخدم الخفيفة.
function captureProjectState(options = {}) {
  const forStorage = Boolean(options && options.forStorage);
  const controls = {};
  projectControlIds.forEach(id => {
    const el = document.getElementById(id);
    if (!el || el.type === 'file') return;
    controls[id] = (el.type === 'checkbox' || el.type === 'radio') ? el.checked : el.value;
  });
  const cleanAyah = ayah => {
    if (!ayah || typeof ayah !== 'object') return ayah;
    const copy = { ...ayah };
    delete copy.audio; delete copy.audioCandidates; delete copy.audioCandidateIndex; delete copy.audioVerified; delete copy.audioDurationMs;
    return copy;
  };
  // مرجع خفيف يسمح بإعادة الجلب عند الاستعادة دون تخزين النصوص.
  let lightRef = null;
  try {
    const rangeToggle = document.getElementById('ayahRangeToggle');
    const startEl = document.getElementById('startAyah');
    const endEl = document.getElementById('endAyah');
    const surahVal = document.getElementById('surahSelect')?.value || surahNumberCurrent || null;
    lightRef = {
      surah: surahVal != null ? String(surahVal) : null,
      riwayah: currentRiwayah || document.getElementById('riwayahSelect')?.value || 'hafs',
      translationKey: translationKey || '',
      tafsirEnabled: Boolean(tafsirEnabled),
      rangeEnabled: Boolean(rangeToggle?.checked),
      rangeStart: Number(startEl?.value) || Number(currentAyahs[0]?.numberInSurah) || 1,
      rangeEnd: Number(endEl?.value) || Number(currentAyahs[currentAyahs.length - 1]?.numberInSurah) || Number(currentAyahs.length) || 1,
      ayahCount: Array.isArray(currentAyahs) ? currentAyahs.length : 0
    };
  } catch (e) { lightRef = null; }

  if (forStorage) {
    // تخزين محلي: بدون نصوص آيات/ترجمة/تفسير/رواية — يعاد جلبها عند الاستعادة.
    return {
      schemaVersion: PROJECT_SCHEMA_VERSION,
      savedAt: new Date().toISOString(),
      storageMode: 'light',
      controls,
      state: {
        fullSurahData: null,
        currentAyahs: [],
        surahNumberCurrent, currentRiwayah, translationKey, tafsirEnabled,
        translationsData: {}, tafsirData: {}, riwayahAyahsData: {},
        lightRef,
        activePresetId: typeof activePresetId === 'string' ? activePresetId : null,
        templateId: currentExportProfile,
        designOverrides: { fontSettings, transFontSettings, currentBgIndex, frameIndex, frameColor, frameOpacity, transitionEffect, textColor, contrastLevel, glowEnabled, quranTextEffect, quranTextEffectIntensity, bgMotionEffect, bgMotionSpeed, dynamicBackgroundContrast, dynamicBackgroundSpeed, gradientEffect, particleEffectEnabled, vignetteEffectEnabled },
        fontSettings, transFontSettings, currentBgIndex, frameIndex, frameColor, frameOpacity,
        transitionEffect, ayahDisplayDuration, effectAnimationDuration, textColor, contrastLevel, glowEnabled,
        quranTextEffect, quranTextEffectIntensity, quranMotionEffect, quranMotionIntensity, translationTransitionEffect, translationDisplayDuration,
        translationAnimationDuration, translationTextEffect, translationTextEffectIntensity, translationMotionEffect, translationMotionIntensity,
        logoSizePct, logoPosition, logoOpacity, logoBorderWidth, logoBorderColor, logoName, logoNameFont, logoNameSize, logoNameGap, logoNameOpacity, logoNameColor,
        logoTransitionEffect, logoTextEffect, logoMotionEffect,
        footerText, footerFont, footerSize, footerOpacity, footerColor,
        footerTransitionEffect, footerTextEffect, footerMotionEffect, bgMotionEffect, bgMotionSpeed, dynamicBackgroundContrast, dynamicBackgroundSpeed,
        timingMode, adaptiveFactor, gradientEffect, particleEffectEnabled, vignetteEffectEnabled, playbackSpeed, audioSourceMode, currentExportProfile, currentExportMode, currentVideoFormat, currentExportQuality, videoAdjustments
      }
    };
  }

  const cleanFullSurahData = fullSurahData && typeof fullSurahData === 'object'
    ? { ...fullSurahData, ayahs: Array.isArray(fullSurahData.ayahs) ? fullSurahData.ayahs.map(cleanAyah) : [] }
    : null;
  return {
    schemaVersion: PROJECT_SCHEMA_VERSION,
    savedAt: new Date().toISOString(),
    storageMode: 'full',
    controls,
    state: {
      fullSurahData: cleanFullSurahData,
      currentAyahs: Array.isArray(currentAyahs) ? currentAyahs.map(cleanAyah) : [],
      surahNumberCurrent, currentRiwayah, translationKey, tafsirEnabled, translationsData, tafsirData, riwayahAyahsData,
      lightRef,
      activePresetId: typeof activePresetId === 'string' ? activePresetId : null,
      templateId: currentExportProfile,
      designOverrides: { fontSettings, transFontSettings, currentBgIndex, frameIndex, frameColor, frameOpacity, transitionEffect, textColor, contrastLevel, glowEnabled, quranTextEffect, quranTextEffectIntensity, bgMotionEffect, bgMotionSpeed, dynamicBackgroundContrast, dynamicBackgroundSpeed, gradientEffect, particleEffectEnabled, vignetteEffectEnabled },
      fontSettings, transFontSettings, currentBgIndex, frameIndex, frameColor, frameOpacity,
      transitionEffect, ayahDisplayDuration, effectAnimationDuration, textColor, contrastLevel, glowEnabled,
      quranTextEffect, quranTextEffectIntensity, translationTransitionEffect, translationDisplayDuration,
      translationAnimationDuration, translationTextEffect, translationTextEffectIntensity, bgMotionEffect, bgMotionSpeed, dynamicBackgroundContrast, dynamicBackgroundSpeed,
      timingMode, adaptiveFactor, gradientEffect, particleEffectEnabled, vignetteEffectEnabled, playbackSpeed, audioSourceMode, currentExportProfile, currentExportMode, currentVideoFormat, currentExportQuality, videoAdjustments
    }
  };
}

function updateProjectStatus(msg, type = '') {
  const el = document.getElementById('projectStatus');
  const indicator = document.getElementById('autosaveIndicator');
  if (el) { el.textContent = msg; el.style.color = type === 'error' ? '#e74c3c' : type === 'success' ? '#7ed6a5' : '#7a8a99'; }
  if (indicator && type === 'success') { indicator.textContent = '✓ محفوظ تلقائياً'; indicator.style.color = '#7ed6a5'; }
}

function refreshSavedProjectOptions(selectId = null) {
  const select = document.getElementById('savedProjectSelect');
  if (!select) return;
  const projects = getProjectStore().sort((a,b) => new Date(b.updatedAt || 0) - new Date(a.updatedAt || 0));
  select.innerHTML = '<option value="">-- اختر مشروعاً --</option>';
  projects.forEach(project => {
    const opt = document.createElement('option');
    opt.value = project.id;
    opt.textContent = `${project.name || 'مشروع بدون اسم'} — ${new Date(project.updatedAt || project.savedAt || Date.now()).toLocaleString('ar-EG')}`;
    select.appendChild(opt);
  });
  if (selectId && projects.some(p => p.id === selectId)) select.value = selectId;
}

function persistProject(name = null, silent = false) {
  if (projectRestoreInProgress) return false;
  const input = document.getElementById('projectNameInput');
  const projectName = String(name || input?.value || 'مشروع قرآن جديد').trim() || 'مشروع قرآن جديد';
  if (input) input.value = projectName;
  const now = new Date().toISOString();
  const id = currentProjectId || ('project-' + Date.now() + '-' + Math.random().toString(36).slice(2,8));
  const projects = getProjectStore();
  const old = projects.find(p => p.id === id);
  // v33: حفظ كامل أولاً (نصوص + ترجمة + تفسير) حتى يعود كل شيء بعد التحديث دون إعادة جلب.
  // عند تجاوز الحصة نتراجع تدريجياً: نسخة خفيفة، ثم حذف الأقدم — ولا نفقد الحفظ أبداً بصمت.
  const FULL_JSON_LIMIT = 4000000;
  let data;
  try {
    const full = captureProjectState();
    data = JSON.stringify(full).length > FULL_JSON_LIMIT ? captureProjectState({ forStorage: true }) : full;
  } catch (e) {
    try { data = captureProjectState({ forStorage: true }); }
    catch (e2) { console.error('Project capture error:', e2); if (!silent) updateProjectStatus('❌ تعذر تجهيز المشروع للحفظ.', 'error'); return false; }
  }
  const project = { id, name: projectName, savedAt: old?.savedAt || now, updatedAt: now, data };
  const index = projects.findIndex(p => p.id === id);
  if (index >= 0) projects[index] = project; else projects.unshift(project);
  projects.sort((a,b) => new Date(b.updatedAt) - new Date(a.updatedAt));
  // محاولة 1: الكل (10 كحد أقصى). محاولة 2: نسخة خفيفة للمشروع الحالي + إسقاط الأقدم حتى يتسع.
  try {
    setProjectStore(projects.slice(0, 10));
  } catch (e) {
    console.warn('Project store full, downgrading:', e?.message || e);
    try {
      project.data = captureProjectState({ forStorage: true });
      let slim = projects.slice(0, 10);
      let saved = false, guard = 0;
      while (!saved && guard++ < 12) {
        try { setProjectStore(slim); saved = true; }
        catch (e2) {
          const dropIdx = slim.findIndex(p => p.id !== id);
          if (dropIdx < 0) break;
          slim.splice(dropIdx, 1);
        }
      }
      if (!saved) throw new Error('quota');
    } catch (e2) {
      console.error('Project save error:', e2);
      if (!silent) updateProjectStatus('❌ تعذر حفظ المشروع. مساحة التخزين المحلية ممتلئة.', 'error');
      return false;
    }
  }
  try {
    currentProjectId = id;
    localStorage.setItem(PROJECT_CURRENT_KEY, id);
    refreshSavedProjectOptions(id);
    if (!silent) updateProjectStatus(`✅ تم حفظ المشروع «${projectName}» بنجاح.`, 'success');
    return true;
  } catch (e) {
    console.error('Project save error:', e);
    if (!silent) updateProjectStatus('❌ تعذر حفظ المشروع. التخزين المحلي غير متاح.', 'error');
    return false;
  }
}

function scheduleProjectAutosave() {
  if (projectRestoreInProgress) return;
  clearTimeout(projectAutosaveTimer);
  const indicator = document.getElementById('autosaveIndicator');
  if (indicator) { indicator.textContent = '⏳ حفظ تلقائي...'; indicator.style.color = '#f39c12'; }
  projectAutosaveTimer = setTimeout(() => {
    persistProject(null, true);
    updateProjectStatus('💾 تم الحفظ التلقائي للمشروع الحالي.', 'success');
  }, 900);
}

function applySavedControl(id, value) {
  const el = document.getElementById(id);
  if (!el || el.type === 'file') return;
  if (el.type === 'checkbox' || el.type === 'radio') el.checked = Boolean(value); else el.value = value ?? '';
}

function restoreProject(project) {
  if (!project?.data?.state) return false;
  projectRestoreInProgress = true;
  try {
    const state = project.data.state, controls = project.data.controls || {};
    const savedDesign = state.designOverrides || {};
    const savedTemplateId = exportProfiles[state.templateId || state.currentExportProfile] ? (state.templateId || state.currentExportProfile) : 'default';
    Object.entries(controls).forEach(([id,value]) => applySavedControl(id,value));
    fullSurahData = state.fullSurahData || null;
    currentAyahs = Array.isArray(state.currentAyahs) ? state.currentAyahs.map(a => ({...a, audioVerified:false, audio:null, audioCandidates:[], audioCandidateIndex:0})) : [];
    surahNumberCurrent = state.surahNumberCurrent ?? null; currentRiwayah = state.currentRiwayah || 'hafs';
    translationKey = state.translationKey || ''; tafsirEnabled = Boolean(state.tafsirEnabled);
    translationsData = state.translationsData || {}; tafsirData = state.tafsirData || {}; riwayahAyahsData = state.riwayahAyahsData || {};
    if (savedDesign.fontSettings || state.fontSettings) fontSettings = {...fontSettings,...(savedDesign.fontSettings || state.fontSettings)};
    if (savedDesign.transFontSettings || state.transFontSettings) transFontSettings = {...transFontSettings,...(savedDesign.transFontSettings || state.transFontSettings)};
    currentBgIndex = Number.isFinite(savedDesign.currentBgIndex) ? savedDesign.currentBgIndex : (Number.isFinite(state.currentBgIndex) ? state.currentBgIndex : 0); frameIndex = Number.isFinite(savedDesign.frameIndex) ? savedDesign.frameIndex : (Number.isFinite(state.frameIndex) ? state.frameIndex : 0);
    frameColor = normalizeHexColor(savedDesign.frameColor || state.frameColor, '#d4af37'); frameOpacity = Number.isFinite(savedDesign.frameOpacity) ? savedDesign.frameOpacity : (Number.isFinite(state.frameOpacity) ? state.frameOpacity : 1);
    // v25: قوائم التأثيرات المعاد بناؤها (5+5) — القيم القديمة تُردّ للآمن بدل قائمة فارغة.
    const allowedTransitions = ['fade', 'slideUp', 'rise', 'mist', 'flip', 'zoom', 'scaleIn'];
    transitionEffect = allowedTransitions.includes(savedDesign.transitionEffect || state.transitionEffect) ? (savedDesign.transitionEffect || state.transitionEffect) : 'fade'; ayahDisplayDuration = Number(state.ayahDisplayDuration) || 5000; effectAnimationDuration = Number(state.effectAnimationDuration) || 800;
    const restoredTextColor = savedDesign.textColor || state.textColor || fontSettings.color || '#ffffff';
    const isLegacyProject = Number(project.data.schemaVersion || 1) < 2;
    textColor = isLegacyProject ? restoredTextColor : (fontSettings.color || restoredTextColor);
    fontSettings.color = textColor; contrastLevel = Number.isFinite(savedDesign.contrastLevel) ? savedDesign.contrastLevel : (Number.isFinite(state.contrastLevel) ? state.contrastLevel : 80); glowEnabled = typeof savedDesign.glowEnabled === 'boolean' ? savedDesign.glowEnabled : state.glowEnabled !== false;
    const supportedTextEffects = ['none', 'glow', 'outline', 'gradient', 'pulseglow', 'flowgradient', 'shine', 'neon'];
    const supportedMotionEffects = ['none', 'linewave', 'wave', 'breathe', 'float', 'sway', 'heartbeat', 'tremor'];
    const restoredQuranTextEffect = savedDesign.quranTextEffect || state.quranTextEffect || 'none';
    const restoredTranslationTextEffect = state.translationTextEffect || 'none';
    quranTextEffect = supportedTextEffects.includes(restoredQuranTextEffect) ? restoredQuranTextEffect : 'none'; quranTextEffectIntensity = Number(savedDesign.quranTextEffectIntensity ?? state.quranTextEffectIntensity) || 1;
    quranMotionEffect = supportedMotionEffects.includes(state.quranMotionEffect) ? state.quranMotionEffect : 'none'; quranMotionIntensity = Number(state.quranMotionIntensity) || 1;
    translationTransitionEffect = allowedTransitions.includes(state.translationTransitionEffect) ? state.translationTransitionEffect : 'fade'; translationDisplayDuration = Number(state.translationDisplayDuration) || 3000; translationAnimationDuration = Number(state.translationAnimationDuration) || 600;
    translationTextEffect = supportedTextEffects.includes(restoredTranslationTextEffect) ? restoredTranslationTextEffect : 'none'; translationTextEffectIntensity = Number(state.translationTextEffectIntensity) || 1;
    translationMotionEffect = supportedMotionEffects.includes(state.translationMotionEffect) ? state.translationMotionEffect : 'none'; translationMotionIntensity = Number(state.translationMotionIntensity) || 1;
    // v30: الشعار والتذييل — الصورة محلية لا تُحفظ (كخلفيات الرفع)، والإعدادات تُستعاد.
    const allowedDisplayFonts = ['Cairo', 'Amiri', 'Tajawal', 'Almarai', 'Poppins', 'Montserrat', 'Bebas Neue', 'Playfair Display'];
    const pickFont = (v, fb) => allowedDisplayFonts.includes(v) ? v : fb;
    const allowedLogoPositions = ['bottom-right', 'bottom-left', 'top-right', 'top-left', 'bottom-center'];
    logoSizePct = Math.max(4, Math.min(25, Number(state.logoSizePct) || 12));
    logoPosition = allowedLogoPositions.includes(state.logoPosition) ? state.logoPosition : 'bottom-right';
    logoOpacity = Math.max(0, Math.min(100, Number.isFinite(Number(state.logoOpacity)) ? Number(state.logoOpacity) : 100));
    logoBorderWidth = Math.max(0, Math.min(10, Number.isFinite(Number(state.logoBorderWidth)) ? Number(state.logoBorderWidth) : 3));
    logoBorderColor = normalizeHexColor(state.logoBorderColor, '#d4af37');
    logoName = String(state.logoName || '').slice(0, 30);
    logoNameFont = pickFont(state.logoNameFont, 'Cairo');
    logoNameSize = Math.max(10, Math.min(60, Number(state.logoNameSize) || 28));
    logoNameGap = Math.max(0, Math.min(60, Number.isFinite(Number(state.logoNameGap)) ? Number(state.logoNameGap) : 12));
    logoNameOpacity = Math.max(0, Math.min(100, Number.isFinite(Number(state.logoNameOpacity)) ? Number(state.logoNameOpacity) : 100));
    logoNameColor = normalizeHexColor(state.logoNameColor, '#f4e5a1');
    footerText = String(state.footerText || '').slice(0, 60);
    footerFont = pickFont(state.footerFont, 'Cairo');
    footerSize = Math.max(10, Math.min(80, Number(state.footerSize) || 44));
    footerOpacity = Math.max(0, Math.min(100, Number.isFinite(Number(state.footerOpacity)) ? Number(state.footerOpacity) : 100));
    footerColor = normalizeHexColor(state.footerColor, '#d4af37');
    // v31: تأثيرات الشعار والتذييل (نفس قوائم الآيات — تُردّ للآمن).
    logoTransitionEffect = allowedTransitions.includes(state.logoTransitionEffect) ? state.logoTransitionEffect : 'fade';
    logoTextEffect = supportedTextEffects.includes(state.logoTextEffect) ? state.logoTextEffect : 'none';
    logoMotionEffect = supportedMotionEffects.includes(state.logoMotionEffect) ? state.logoMotionEffect : 'none';
    footerTransitionEffect = allowedTransitions.includes(state.footerTransitionEffect) ? state.footerTransitionEffect : 'fade';
    footerTextEffect = supportedTextEffects.includes(state.footerTextEffect) ? state.footerTextEffect : 'none';
    footerMotionEffect = supportedMotionEffects.includes(state.footerMotionEffect) ? state.footerMotionEffect : 'none';
    logoImage = null;
    try { if (typeof revokeLogoObjectUrl === 'function') revokeLogoObjectUrl(); } catch (e) {}
    bgMotionEffect = savedDesign.bgMotionEffect || state.bgMotionEffect || 'none'; bgMotionSpeed = Number(savedDesign.bgMotionSpeed ?? state.bgMotionSpeed) || 1;
    dynamicBackgroundContrast = Math.max(0, Math.min(100, Number(savedDesign.dynamicBackgroundContrast ?? state.dynamicBackgroundContrast) || 50));
    dynamicBackgroundSpeed = Math.max(0.1, Math.min(3, Number(savedDesign.dynamicBackgroundSpeed ?? state.dynamicBackgroundSpeed) || 1));
    timingMode = state.timingMode || 'manual'; adaptiveFactor = Number(state.adaptiveFactor) || 1; gradientEffect = savedDesign.gradientEffect || state.gradientEffect || 'none';
    particleEffectEnabled = typeof savedDesign.particleEffectEnabled === 'boolean' ? savedDesign.particleEffectEnabled : Boolean(state.particleEffectEnabled); vignetteEffectEnabled = typeof savedDesign.vignetteEffectEnabled === 'boolean' ? savedDesign.vignetteEffectEnabled : Boolean(state.vignetteEffectEnabled); playbackSpeed = Number(state.playbackSpeed) || 1;
    audioSourceMode = state.audioSourceMode === 'upload' ? 'upload' : 'reciter';
    if (state.videoAdjustments && typeof state.videoAdjustments === 'object') videoAdjustments = {...videoAdjustments, ...state.videoAdjustments};
    currentExportProfile = savedTemplateId;
    // توافق خلفي: مشاريع v2 كانت تحمل currentRecordingTemplate (قالب منصة محذوف) — تُهمل وتُعامل كفيديو كامل.
    currentExportMode = exportModes[state.currentExportMode] ? state.currentExportMode : 'full';
    activePresetId = typeof state.activePresetId === 'string' && presets.some(p => p.id === state.activePresetId) ? state.activePresetId : null;
    currentVideoFormat = videoFormats[state.currentVideoFormat] ? state.currentVideoFormat : 'portrait';
    currentExportQuality = exportQualities[state.currentExportQuality] ? state.currentExportQuality : 'high';
    revokeCustomBgObjectUrl();
    customBgType = null; customBgImage = null; customBgVideo = null; manualAudioUrl = ''; manualAudioFile = null; manualAudioAyahDurationMs = 0;
    document.getElementById('projectNameInput').value = project.name || 'مشروع قرآن جديد'; currentProjectId = project.id; localStorage.setItem(PROJECT_CURRENT_KEY,currentProjectId);
    refreshReciterOptions(); refreshFontFamilyOptions(); updateExportPreview(currentExportProfile); updateFinalExportSpec(); const formatEl=document.getElementById('videoFormatSelect'); if(formatEl) formatEl.value=currentVideoFormat; const qualityEl=document.getElementById('finalExportQualitySelect'); if(qualityEl) qualityEl.value=currentExportQuality; applyExportQuality(currentExportQuality, false); updateAudioSourceUI();
    // v27: عناصر التأثيرات فارغة — القيم المحفوظة تُستعاد في المتغيرات فقط.
    // v28: مزامنة عناصر الخطوة 1 (العناصر موجودة — آمنة).
    document.getElementById('effectSelect').value = transitionEffect;
    document.getElementById('effectSpeedRange').value = effectAnimationDuration;
    document.getElementById('effectSpeedValue').textContent = effectAnimationDuration;
    document.getElementById('quranTextEffectSelect').value = quranTextEffect;
    document.getElementById('quranTextEffectIntensityRange').value = quranTextEffectIntensity;
    document.getElementById('quranTextEffectIntensityValue').textContent = Number(quranTextEffectIntensity).toFixed(1);
    document.getElementById('quranMotionEffectSelect').value = quranMotionEffect;
    document.getElementById('quranMotionIntensityRange').value = quranMotionIntensity;
    document.getElementById('quranMotionIntensityValue').textContent = Number(quranMotionIntensity).toFixed(1);
    document.getElementById('translationTransitionSelect').value = translationTransitionEffect;
    document.getElementById('translationEffectSpeedRange').value = translationAnimationDuration;
    document.getElementById('translationEffectSpeedValue').textContent = translationAnimationDuration;
    document.getElementById('translationTextEffectSelect').value = translationTextEffect;
    document.getElementById('translationTextEffectIntensityRange').value = translationTextEffectIntensity;
    document.getElementById('translationTextEffectIntensityValue').textContent = Number(translationTextEffectIntensity).toFixed(1);
    document.getElementById('translationMotionEffectSelect').value = translationMotionEffect;
    document.getElementById('translationMotionIntensityRange').value = translationMotionIntensity;
    document.getElementById('translationMotionIntensityValue').textContent = Number(translationMotionIntensity).toFixed(1);
    // v30: مزامنة الشعار والتذييل (الصورة تُعاد يدوياً — تُصفَّر المعاينة).
    document.getElementById('logoUpload').value = '';
    document.getElementById('logoSizeRange').value = logoSizePct;
    document.getElementById('logoSizeValue').textContent = Math.round(logoSizePct);
    document.getElementById('logoPositionSelect').value = logoPosition;
    document.getElementById('logoOpacityRange').value = logoOpacity;
    document.getElementById('logoOpacityValue').textContent = Math.round(logoOpacity);
    document.getElementById('logoBorderWidthRange').value = logoBorderWidth;
    document.getElementById('logoBorderWidthValue').textContent = Number(logoBorderWidth);
    document.getElementById('logoBorderColorPicker').value = logoBorderColor;
    document.getElementById('logoNameInput').value = logoName;
    document.getElementById('logoNameFontSelect').value = logoNameFont;
    document.getElementById('logoNameSizeRange').value = logoNameSize;
    document.getElementById('logoNameSizeValue').textContent = Math.round(logoNameSize);
    document.getElementById('logoNameGapRange').value = logoNameGap;
    document.getElementById('logoNameGapValue').textContent = Math.round(logoNameGap);
    document.getElementById('logoNameOpacityRange').value = logoNameOpacity;
    document.getElementById('logoNameOpacityValue').textContent = Math.round(logoNameOpacity);
    document.getElementById('logoNameColorPicker').value = logoNameColor;
    document.getElementById('footerTextInput').value = footerText;
    document.getElementById('footerFontSelect').value = footerFont;
    document.getElementById('footerSizeRange').value = footerSize;
    document.getElementById('footerSizeValue').textContent = Math.round(footerSize);
    document.getElementById('footerOpacityRange').value = footerOpacity;
    document.getElementById('footerOpacityValue').textContent = Math.round(footerOpacity);
    document.getElementById('footerColorPicker').value = footerColor;
    document.getElementById('logoTransitionSelect').value = logoTransitionEffect;
    document.getElementById('logoTextEffectSelect').value = logoTextEffect;
    document.getElementById('logoMotionEffectSelect').value = logoMotionEffect;
    document.getElementById('footerTransitionSelect').value = footerTransitionEffect;
    document.getElementById('footerTextEffectSelect').value = footerTextEffect;
    document.getElementById('footerMotionEffectSelect').value = footerMotionEffect;
    try { if (typeof syncLogoPreviewUI === 'function') syncLogoPreviewUI(); } catch (e) {}
    try { if (typeof ensureDisplayFont === 'function') { ensureDisplayFont(logoNameFont); ensureDisplayFont(footerFont); } } catch (e) {}
    document.getElementById('presetBackgroundContrastRange').value = dynamicBackgroundContrast; document.getElementById('presetBackgroundSpeedRange').value = dynamicBackgroundSpeed;
    document.getElementById('presetBackgroundContrastValue').textContent = Math.round(dynamicBackgroundContrast); document.getElementById('presetBackgroundSpeedValue').textContent = dynamicBackgroundSpeed.toFixed(1);
    document.getElementById('gradientEffectSelect').value = gradientEffect; document.getElementById('particleEffectToggle').checked = particleEffectEnabled; document.getElementById('vignetteEffectToggle').checked = vignetteEffectEnabled;
    try { if (typeof applyExportMode === 'function') applyExportMode(currentExportMode); else { const mEl = document.getElementById('exportModeSelect'); if (mEl) mEl.value = currentExportMode; } } catch (e) {}
    syncVideoAdjustmentUI();
    const playPauseEl = document.getElementById('playPauseBtn'); if (playPauseEl) { playPauseEl.dataset.state = 'idle'; playPauseEl.setAttribute('aria-label', 'تشغيل المعاينة'); }
    applyFontSettings(); applyTransFontSettings(); updateAyahTiming();
    currentAyahIndex=0; isPlaying=false; isPaused=false; audio.pause(); audio.removeAttribute('src'); audio.load();
    if (currentAyahs.length && audioSourceMode === 'reciter') setAudioStatus('⚠️ تم تحميل المشروع. يجب إعادة تجهيز الصوت قبل التسجيل.', 'warning');
    renderAyahsList(); updateStats(); syncAyahRangeControls(); refreshSavedProjectOptions(currentProjectId); buildPresets();
    if (typeof previewNeedsAnimation === 'function' && previewNeedsAnimation()) startPreviewLoop();
    // P0-2: المشاريع الخفيفة لا تحمل نصوصاً — نوجّه المستخدم للجلب بدل عرض شاشة فارغة صامتة.
    const isLight = project.data?.storageMode === 'light' || (!state.fullSurahData && state.lightRef?.surah);
    if (isLight && !currentAyahs.length) {
      const ref = state.lightRef;
      const refDesc = ref?.surah ? ` (سورة ${ref.surah}${ref.rangeEnabled ? ` • آيات ${ref.rangeStart}–${ref.rangeEnd}` : ' • كاملة'})` : '';
      setStatus(`📂 تم تحميل إعدادات المشروع «${project.name || 'بدون اسم'}»${refDesc} — اضغط "جلب الآيات" لإكمال الاستعادة الخفيفة.`, 'success');
      updateProjectStatus(`📂 مشروع خفيف${refDesc}: الإعدادات مستعادة بالكامل، والنصوص تُجلب عند الضغط على "جلب الآيات".`, 'success');
    } else {
      setStatus(`📂 تم تحميل المشروع «${project.name || 'بدون اسم'}»`, 'success'); updateProjectStatus('📂 تم تحميل المشروع. الملفات المحلية تحتاج إعادة اختيارها يدوياً.', 'success');
    }
    return true;
  } catch(e) { console.error('Project restore error:',e); updateProjectStatus('❌ تعذر تحميل المشروع: '+(e.message||e),'error'); return false; }
  finally { projectRestoreInProgress=false; }
}

function loadSelectedProject() {
  const id=document.getElementById('savedProjectSelect')?.value;
  if(!id){updateProjectStatus('⚠️ اختر مشروعاً محفوظاً أولاً.','error');return;}
  const project=getProjectStore().find(p=>p.id===id);
  if(!project){updateProjectStatus('❌ المشروع غير موجود.','error');return;}
  restoreProject(project);
}

function exportProjectFile() {
  try {
    clearTimeout(projectAutosaveTimer);
    // P0-2: الحفظ المحلي خفيف، لكن ملف التصدير يحمل النسخة الكاملة (حتى 5MB) ليعمل دون إنترنت إضافي.
    persistProject(null, true);
    const input = document.getElementById('projectNameInput');
    const projectName = String(input?.value || 'مشروع قرآن جديد').trim() || 'مشروع قرآن جديد';
    const now = new Date().toISOString();
    const stored = getProjectStore().find(p => p.id === currentProjectId);
    const project = {
      id: currentProjectId || ('project-' + Date.now()),
      name: projectName,
      savedAt: stored?.savedAt || now,
      updatedAt: now,
      data: captureProjectState()
    };
    const sizeEstimate = JSON.stringify(project.data?.state?.currentAyahs || []).length
      + JSON.stringify(project.data?.state?.translationsData || {}).length
      + JSON.stringify(project.data?.state?.tafsirData || {}).length;
    if (sizeEstimate > MAX_PROJECT_FILE_SIZE) {
      // ملف ضخم (تفسير كامل لسورة طويلة): نصدر المراجع الخفيفة بدل الفشل.
      project.data = captureProjectState({ forStorage: true });
      updateProjectStatus('⚠️ المشروع ضخم — تم تصدير نسخة خفيفة (مراجع) لتجاوز حد 5MB.', 'success');
    }
    if (!project) { updateProjectStatus('❌ لم يتم العثور على النسخة المحفوظة.','error'); return; }
    const payload = {
      app: 'Quran Studio Pro',
      type: 'quran-studio-project',
      schemaVersion: PROJECT_SCHEMA_VERSION,
      exportedAt: new Date().toISOString(),
      project
    };
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    const safeName = String(project.name || 'مشروع-قرآن').replace(/[\\/:*?"<>|]+/g, '-').trim() || 'مشروع-قرآن';
    a.href = url;
    a.download = `${safeName}.quranstudio.json`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
    updateProjectStatus(`⬇️ تم حفظ ملف المشروع «${project.name || 'بدون اسم'}» بنجاح.`,'success');
  } catch (e) {
    console.error('Project export error:', e);
    updateProjectStatus('❌ تعذر حفظ ملف المشروع.','error');
  }
}

function isPlainObject(value) {
  return Boolean(value) && typeof value === 'object' && !Array.isArray(value);
}

function validateImportedNumber(value, min, max, label) {
  if (value === undefined || value === null || value === '') return;
  if (!Number.isFinite(Number(value)) || Number(value) < min || Number(value) > max) {
    throw new Error(`قيمة ${label} خارج النطاق المسموح.`);
  }
}

function validateImportedColor(value, label) {
  if (value !== undefined && value !== null && !/^#[0-9a-fA-F]{3}(?:[0-9a-fA-F]{3})?$/.test(String(value))) {
    throw new Error(`لون ${label} غير صالح.`);
  }
}

function validateImportedFontSettings(settings, label) {
  if (settings === undefined) return;
  if (!isPlainObject(settings)) throw new Error(`إعدادات ${label} غير صالحة.`);
  if (settings.family !== undefined && (typeof settings.family !== 'string' || settings.family.length > 100)) throw new Error(`خط ${label} غير صالح.`);
  validateImportedNumber(settings.size, 8, 160, `حجم خط ${label}`);
  validateImportedNumber(settings.weight, 100, 900, `سُمك خط ${label}`);
  validateImportedNumber(settings.lineHeight, .5, 5, `تباعد خط ${label}`);
  validateImportedNumber(settings.bgOpacity, 0, 100, `شفافية خلفية ${label}`);
  validateImportedNumber(settings.borderWidth, 0, 20, `حدود ${label}`);
  validateImportedNumber(settings.borderRadius, 0, 60, `استدارة ${label}`);
  ['color', 'bgColor', 'borderColor'].forEach(key => validateImportedColor(settings[key], `${label}.${key}`));
}

function validateImportedAyahs(list, label) {
  if (list === undefined || list === null) return;
  if (!Array.isArray(list) || list.length > 286) throw new Error(`بيانات ${label} غير صالحة.`);
  list.forEach((ayah, index) => {
    if (!isPlainObject(ayah)) throw new Error(`الآية ${index + 1} في ${label} غير صالحة.`);
    validateImportedNumber(ayah.numberInSurah, 1, 286, `رقم آية ${label}`);
    if (typeof ayah.text !== 'string' || ayah.text.length === 0 || ayah.text.length > 10000) throw new Error(`نص الآية ${index + 1} في ${label} غير صالح.`);
  });
}

function validateImportedState(data) {
  const state = data.state;
  if (!isPlainObject(state)) throw new Error('حالة المشروع غير صالحة.');
  validateImportedAyahs(state.currentAyahs, 'الآيات الحالية');
  if (state.fullSurahData !== undefined && state.fullSurahData !== null) {
    if (!isPlainObject(state.fullSurahData)) throw new Error('بيانات السورة الكاملة غير صالحة.');
    validateImportedAyahs(state.fullSurahData.ayahs, 'السورة الكاملة');
    validateImportedNumber(state.fullSurahData.numberOfAyahs, 1, 286, 'عدد آيات السورة');
  }
  if (state.currentRiwayah !== undefined && !quranTextSources[state.currentRiwayah]) throw new Error('الرواية المحفوظة غير مدعومة.');
  if (state.currentExportProfile !== undefined && !exportProfiles[state.currentExportProfile]) throw new Error('قالب التصدير المحفوظ غير مدعوم.');
  if (state.currentExportMode !== undefined && !exportModes[state.currentExportMode]) throw new Error('نوع التصدير المحفوظ غير مدعوم.');
  // توافق خلفي: نتجاهل قالب المنصة القديم إن وُجد في ملفات v2.
  if (state.currentVideoFormat !== undefined && !videoFormats[state.currentVideoFormat]) throw new Error('مقاس الفيديو المحفوظ غير مدعوم.');
  if (state.currentExportQuality !== undefined && !exportQualities[state.currentExportQuality]) throw new Error('جودة التصدير المحفوظة غير مدعومة.');
  if (state.timingMode !== undefined && !['manual', 'adaptive', 'audio', 'smart'].includes(state.timingMode)) throw new Error('وضع التوقيت المحفوظ غير مدعوم.');
  validateImportedNumber(state.ayahDisplayDuration, 250, 120000, 'مدة الآية');
  validateImportedNumber(state.effectAnimationDuration, 0, 10000, 'مدة تأثير الانتقال');
  validateImportedNumber(state.translationDisplayDuration, 250, 120000, 'مدة الترجمة');
  validateImportedNumber(state.translationAnimationDuration, 0, 10000, 'مدة تأثير الترجمة');
  validateImportedNumber(state.adaptiveFactor, .1, 5, 'معامل التكيف');
  validateImportedNumber(state.playbackSpeed, .25, 4, 'سرعة التشغيل');
  validateImportedFontSettings(state.fontSettings, 'القرآن');
  validateImportedFontSettings(state.transFontSettings, 'الترجمة');
  if (state.videoAdjustments !== undefined) {
    if (!isPlainObject(state.videoAdjustments)) throw new Error('تعديلات الفيديو غير صالحة.');
    validateImportedNumber(state.videoAdjustments.brightness, 0, 300, 'إضاءة الفيديو');
    validateImportedNumber(state.videoAdjustments.contrast, 0, 300, 'تباين الفيديو');
    validateImportedNumber(state.videoAdjustments.saturation, 0, 300, 'تشبع الفيديو');
    validateImportedNumber(state.videoAdjustments.warmth, 0, 100, 'دفء الفيديو');
    validateImportedNumber(state.videoAdjustments.hue, -360, 360, 'درجة لون الفيديو');
    validateImportedNumber(state.videoAdjustments.blur, 0, 20, 'ضبابية الفيديو');
    validateImportedNumber(state.videoAdjustments.vignette, 0, 100, 'تظليل الفيديو');
    validateImportedNumber(state.videoAdjustments.exposure, -100, 100, 'تعريض الفيديو');
    validateImportedNumber(state.videoAdjustments.blackPoint, -100, 100, 'مستوى أسود الفيديو');
  }
  ['frameColor', 'textColor'].forEach(key => validateImportedColor(state[key], key));
  if (isPlainObject(state.designOverrides)) {
    ['frameColor', 'textColor'].forEach(key => validateImportedColor(state.designOverrides[key], `designOverrides.${key}`));
    validateImportedFontSettings(state.designOverrides.fontSettings, 'تصميم القرآن');
    validateImportedFontSettings(state.designOverrides.transFontSettings, 'تصميم الترجمة');
  }
}

function normalizeImportedProject(raw) {
  const project = raw?.project?.data ? raw.project : (raw?.data?.state ? raw : null);
  if (!project?.data?.state || typeof project.data !== 'object') throw new Error('ملف المشروع غير صالح أو غير مكتمل.');
  const data = project.data;
  const serializedSize = JSON.stringify(raw).length;
  if (serializedSize > MAX_PROJECT_FILE_SIZE) throw new Error('حجم ملف المشروع أكبر من الحد المسموح.');
  if (!data.schemaVersion && raw?.schemaVersion) data.schemaVersion = raw.schemaVersion;
  const schemaVersion = Number(data.schemaVersion || 1);
  if (!Number.isInteger(schemaVersion) || schemaVersion < 1) throw new Error('إصدار ملف المشروع غير صالح.');
  if (schemaVersion > PROJECT_SCHEMA_VERSION) throw new Error('إصدار ملف المشروع أحدث من الإصدار المدعوم.');
  if (typeof project.name !== 'string' || !project.name.trim() || project.name.length > 120) throw new Error('اسم المشروع غير صالح.');
  if (data.controls && (typeof data.controls !== 'object' || Array.isArray(data.controls))) throw new Error('بيانات عناصر التحكم غير صالحة.');
  if (data.controls) {
    // توافق خلفي: عناصر محذوفة (قالب المنصة v2، البحث الذكي) تُقبل ثم تُتجاهل بصمت.
    const LEGACY_CONTROL_IDS = new Set(['recordingTemplateSelect', 'surahSearch']);
    Object.entries(data.controls).forEach(([id, value]) => {
      if (LEGACY_CONTROL_IDS.has(id)) { delete data.controls[id]; return; }
      if (!projectControlIds.includes(id)) throw new Error(`عنصر تحكم غير معروف: ${id}`);
      if (!['string', 'number', 'boolean'].includes(typeof value)) throw new Error(`قيمة عنصر التحكم ${id} غير صالحة.`);
      if (typeof value === 'string' && value.length > 1000) throw new Error(`قيمة عنصر التحكم ${id} طويلة جدًا.`);
    });
  }
  // توافق خلفي v2: قالب المنصة المحذوف يُعامل كفيديو كامل.
  if (data.state && typeof data.state === 'object' && data.state.currentRecordingTemplate !== undefined && data.state.currentExportMode === undefined) {
    data.state.currentExportMode = 'full';
  }
  if (data.state && typeof data.state === 'object' && data.state.currentRecordingTemplate !== undefined) {
    try { delete data.state.currentRecordingTemplate; } catch (e) {}
  }
  validateImportedState(data);
  data.state.frameColor = normalizeHexColor(data.state.frameColor, '#d4af37');
  if (data.state.designOverrides && typeof data.state.designOverrides === 'object') {
    data.state.designOverrides.frameColor = normalizeHexColor(data.state.designOverrides.frameColor, data.state.frameColor);
  }
  return {
    id: 'project-' + Date.now() + '-' + Math.random().toString(36).slice(2,8),
    name: String(project.name || 'مشروع قرآن مستورد').trim() || 'مشروع قرآن مستورد',
    savedAt: project.savedAt || new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    data
  };
}

function importProjectFile(file) {
  if (!file) return;
  if (file.size > MAX_PROJECT_FILE_SIZE) {
    updateProjectStatus(`❌ حجم ملف المشروع أكبر من الحد المسموح (${Math.round(MAX_PROJECT_FILE_SIZE / (1024 * 1024))}MB).`, 'error');
    return;
  }
  const reader = new FileReader();
  reader.onload = () => {
    try {
      const raw = JSON.parse(String(reader.result || ''));
      const project = normalizeImportedProject(raw);
      const projects = getProjectStore();
      projects.unshift(project);
      setProjectStore(projects.slice(0, 10));
      currentProjectId = project.id;
      localStorage.setItem(PROJECT_CURRENT_KEY, currentProjectId);
      refreshSavedProjectOptions(currentProjectId);
      restoreProject(project);
      updateProjectStatus(`⬆️ تم تحميل ملف المشروع «${project.name}» بنجاح.`,'success');
    } catch (e) {
      console.error('Project import error:', e);
      updateProjectStatus('❌ تعذر تحميل ملف المشروع: ملف JSON غير صالح أو لا يحتوي على بيانات مشروع كاملة.','error');
    }
  };
  reader.onerror = () => updateProjectStatus('❌ تعذر قراءة ملف المشروع.','error');
  reader.readAsText(file, 'utf-8');
}

function resetToDefaultScreen() {
  if (!confirm('هل تريد استعادة إعدادات الصفحة الافتراضية بالكامل؟ سيتم إرجاع جميع عناصر الشاشة والإعدادات والقالب والحالة كما كانت عند فتح البرنامج لأول مرة، مع الاحتفاظ بالمشاريع المحفوظة.')) return;

  // مهم: beforeunload كان يقوم بالحفظ التلقائي قبل إعادة التحميل،
  // مما يعيد المشروع القديم ويمنع الوصول إلى الحالة الافتراضية.
  isResettingToDefaults = true;
  clearTimeout(projectAutosaveTimer);
  clearTimeout(historyCaptureTimer);

  try {
    invalidateAsyncRequest('content');
    invalidateAsyncRequest('translation');
    invalidateAsyncRequest('tafsir');
    invalidateAsyncRequest('audio');
  } catch (e) {}

  // إيقاف أي وسائط نشطة قبل إعادة تحميل الصفحة.
  try {
    isPlaying = false;
    isPaused = false;
    audio.pause();
    audio.removeAttribute('src');
    audio.load();
  } catch (e) {}

  // نحتفظ بالمشاريع المحفوظة، لكن نمسح مؤشر المشروع الحالي حتى لا تتم استعادته.
  currentProjectId = null;
  pendingProjectRestore = null;
  undoHistory = [];
  redoHistory = [];
  historyLastState = null;
  try { localStorage.removeItem(PROJECT_CURRENT_KEY); } catch (e) {}

  // إعادة الوضع الداكن أيضًا إلى حالته الأولى.
  try { localStorage.removeItem('quranStudio.darkMode.v1'); } catch (e) { }

  // إعادة تحميل حقيقية للصفحة = إعادة إنشاء DOM وجميع المتغيرات من القيم الأصلية.
  window.location.reload();
}

function createNewProject() {
  if(!confirm('هل تريد بدء مشروع جديد؟ سيتم الاحتفاظ بالمشاريع المحفوظة، لكن سيتم مسح حالة المشروع الحالي من الشاشة.')) return;
  clearTimeout(projectAutosaveTimer); currentProjectId=null; try { localStorage.removeItem(PROJECT_CURRENT_KEY); } catch (e) {} window.location.reload();
}

function deleteSelectedProject() {
  const id=document.getElementById('savedProjectSelect')?.value;
  if(!id){updateProjectStatus('⚠️ اختر مشروعاً محفوظاً أولاً.','error');return;}
  const project=getProjectStore().find(p=>p.id===id); if(!project)return;
  if(!confirm(`هل تريد حذف المشروع «${project.name||'بدون اسم'}» نهائياً من هذا الجهاز؟`))return;
  try { setProjectStore(getProjectStore().filter(p=>p.id!==id)); if(currentProjectId===id) currentProjectId=null; refreshSavedProjectOptions(currentProjectId); updateProjectStatus('🗑️ تم حذف المشروع المحفوظ.','success'); }
  catch(e){updateProjectStatus('❌ تعذر حذف المشروع.','error');}
}

// ============ المرحلة 2: Undo / Redo ============
const HISTORY_MAX_STEPS = 30;
let undoHistory = [];
let redoHistory = [];
let historyLastState = null;
let historyCaptureTimer = null;
let historyRestoring = false;

function cloneHistoryState(state) {
  try { return JSON.parse(JSON.stringify(state)); }
  catch (e) { console.warn('تعذر نسخ حالة سجل التعديلات:', e); return null; }
}

function historyStateKey(state) {
  try { return JSON.stringify(state); } catch (e) { return ''; }
}

function updateHistoryButtons() {
  const undoBtn = document.getElementById('undoBtn');
  const redoBtn = document.getElementById('redoBtn');
  const undoCount = document.getElementById('undoCount');
  const redoCount = document.getElementById('redoCount');
  if (undoBtn) undoBtn.disabled = undoHistory.length === 0;
  if (redoBtn) redoBtn.disabled = redoHistory.length === 0;
  if (undoCount) undoCount.textContent = undoHistory.length;
  if (redoCount) redoCount.textContent = redoHistory.length;
}

function resetHistoryBaseline() {
  historyLastState = cloneHistoryState(captureProjectState());
  undoHistory = [];
  redoHistory = [];
  updateHistoryButtons();
}

function commitHistoryChange() {
  if (historyRestoring || projectRestoreInProgress || !historyLastState) return;
  const current = captureProjectState();
  if (historyStateKey(current) === historyStateKey(historyLastState)) return;
  undoHistory.push(cloneHistoryState(historyLastState));
  if (undoHistory.length > HISTORY_MAX_STEPS) undoHistory.shift();
  redoHistory = [];
  historyLastState = cloneHistoryState(current);
  updateHistoryButtons();
}

function scheduleHistoryCommit() {
  if (historyRestoring || projectRestoreInProgress) return;
  clearTimeout(historyCaptureTimer);
  historyCaptureTimer = setTimeout(commitHistoryChange, 350);
}

function restoreHistorySnapshot(snapshot, direction) {
  if (!snapshot) return;
  historyRestoring = true;
  try {
    const savedId = currentProjectId;
    const project = {
      id: savedId || 'history-session',
      name: document.getElementById('projectNameInput')?.value || 'مشروع قرآن جديد',
      data: snapshot
    };
    restoreProject(project);
    currentProjectId = savedId;
    historyLastState = cloneHistoryState(captureProjectState());
    updateHistoryButtons();
    updateProjectStatus(direction === 'undo' ? '↩️ تم التراجع عن آخر تعديل.' : '↪️ تمت إعادة آخر تعديل.', 'success');
  } finally {
    historyRestoring = false;
  }
}

function performUndo() {
  if (!undoHistory.length || historyRestoring) return;
  clearTimeout(historyCaptureTimer);
  const current = cloneHistoryState(captureProjectState());
  const previous = undoHistory.pop();
  redoHistory.push(current);
  if (redoHistory.length > HISTORY_MAX_STEPS) redoHistory.shift();
  restoreHistorySnapshot(previous, 'undo');
}

function performRedo() {
  if (!redoHistory.length || historyRestoring) return;
  clearTimeout(historyCaptureTimer);
  const current = cloneHistoryState(captureProjectState());
  const next = redoHistory.pop();
  undoHistory.push(current);
  if (undoHistory.length > HISTORY_MAX_STEPS) undoHistory.shift();
  restoreHistorySnapshot(next, 'redo');
}

function initializeHistoryManager() {
  const undoBtn = document.getElementById('undoBtn');
  const redoBtn = document.getElementById('redoBtn');
  const resetDefaultsBtn = document.getElementById('resetDefaultsBtn');
  undoBtn?.addEventListener('click', performUndo);
  redoBtn?.addEventListener('click', performRedo);
  resetDefaultsBtn?.addEventListener('click', resetToDefaultScreen);

  // نلتقط الحالة قبل إجراءات الأزرار المركبة مثل القوالب والخلفيات والإطارات.
  document.addEventListener('click', (event) => {
    if (historyRestoring || projectRestoreInProgress) return;
    const target = event.target.closest('button, .preset-card, .bg-option, .frame-option');
    if (!target || target.id === 'undoBtn' || target.id === 'redoBtn' || target.closest('#projectManager')) return;
    if (!historyLastState) historyLastState = cloneHistoryState(captureProjectState());
    clearTimeout(historyCaptureTimer);
    const before = cloneHistoryState(historyLastState);
    setTimeout(() => {
      if (historyRestoring || projectRestoreInProgress) return;
      const after = captureProjectState();
      if (historyStateKey(before) !== historyStateKey(after)) {
        undoHistory.push(before);
        if (undoHistory.length > HISTORY_MAX_STEPS) undoHistory.shift();
        redoHistory = [];
        historyLastState = cloneHistoryState(after);
        updateHistoryButtons();
      }
    }, 0);
  }, true);

  projectControlIds.forEach(id => {
    const el = document.getElementById(id);
    if (!el || el.type === 'file') return;
    ['input','change'].forEach(type => el.addEventListener(type, () => {
      if (historyRestoring || projectRestoreInProgress) return;
      scheduleHistoryCommit();
    }));
  });

  document.addEventListener('keydown', (event) => {
    const mod = event.ctrlKey || event.metaKey;
    if (!mod || event.altKey) return;
    if (event.key.toLowerCase() === 'z' && !event.shiftKey) {
      event.preventDefault(); performUndo();
    } else if (event.key.toLowerCase() === 'y' || (event.key.toLowerCase() === 'z' && event.shiftKey)) {
      event.preventDefault(); performRedo();
    }
  });

  if (!historyLastState) historyLastState = cloneHistoryState(captureProjectState());
  updateHistoryButtons();
}

function initializeProjectManager() {
  refreshSavedProjectOptions();
  // v33: قراءة المؤشر داخل حماية — عطل التخزين (وضع خصوصية/كوكيز محظورة) كان يُسقط
  // ربط كل الأزرار بعده فتبدو ميتة. الآن تفشل القراءة فقط ويبقى كل شيء مربوطاً.
  let savedCurrentId = null;
  try { savedCurrentId = localStorage.getItem(PROJECT_CURRENT_KEY); } catch (e) { console.warn('التخزين المحلي للقراءة غير متاح:', e?.message || e); }
  const currentProject=savedCurrentId?getProjectStore().find(p=>p.id===savedCurrentId):null;
  if(currentProject){currentProjectId=currentProject.id; pendingProjectRestore=currentProject;}
  document.getElementById('saveProjectBtn').addEventListener('click',()=>persistProject(null,false));
  document.getElementById('exportProjectBtn').addEventListener('click',exportProjectFile);
  document.getElementById('loadProjectBtn').addEventListener('click',loadSelectedProject);
  document.getElementById('importProjectBtn').addEventListener('click',()=>document.getElementById('projectFileInput')?.click());
  document.getElementById('projectFileInput').addEventListener('change',(e)=>{ const file=e.target.files?.[0]; if(file) importProjectFile(file); e.target.value=''; });
  document.getElementById('newProjectBtn').addEventListener('click',createNewProject);
  document.getElementById('deleteProjectBtn').addEventListener('click',deleteSelectedProject);
  document.getElementById('projectNameInput').addEventListener('input',scheduleProjectAutosave);
  projectControlIds.forEach(id=>{const el=document.getElementById(id);if(!el||el.type==='file')return;el.addEventListener('input',scheduleProjectAutosave);el.addEventListener('change',scheduleProjectAutosave);});
  window.addEventListener('beforeunload',()=>{ clearTimeout(projectAutosaveTimer); if (isResettingToDefaults) return; persistProject(null,true); });
  initializeHistoryManager();
}

