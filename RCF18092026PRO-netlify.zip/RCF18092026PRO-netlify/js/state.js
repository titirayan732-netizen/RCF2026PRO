// ============ أداة تعقيم النصوص قبل حقنها في innerHTML ============
function escapeHtml(str) {
  return String(str ?? '').replace(/[&<>"']/g, ch => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  })[ch]);
}

// ============ الحالة العامة ============
let surahsData = [];
let fullSurahData = null;
let currentAyahs = [];
let audio = document.getElementById('audioPlayer');
let bgVideo = document.getElementById('bgVideo');
let canvas = document.getElementById('previewCanvas');
let ctx = canvas.getContext('2d');
let mediaRecorder = null;
let recordedChunks = [];
let animationId = null;
let previewLoopRunning = false;
let lastPreviewFrameTime = 0;
let autoPreviewEnabled = false;
let playerUiTimer = null;
let currentAyahIndex = 0;
let particles = [];
let startTime = Date.now();
let isPlaying = false;
let isPaused = false;
let playbackSpeed = 1.0;
let audioSourceMode = 'reciter';
let manualAudioUrl = '';
let manualAudioFile = null;
let manualAudioAyahDurationMs = 0;

const MAX_AUDIO_FILE_SIZE = 200 * 1024 * 1024;
const MAX_BACKGROUND_FILE_SIZE = 250 * 1024 * 1024;
const MAX_PROJECT_FILE_SIZE = 5 * 1024 * 1024;

async function fetchWithTimeout(url, options = {}, timeoutMs = 15000) {
  const controller = new AbortController();
  const externalSignal = options.signal;
  let timeoutId;
  let abortHandler;

  if (externalSignal) {
    abortHandler = () => controller.abort();
    if (externalSignal.aborted) controller.abort();
    else externalSignal.addEventListener('abort', abortHandler, { once: true });
  }

  timeoutId = setTimeout(() => controller.abort(), timeoutMs);
  try {
    return await fetch(url, { ...options, signal: controller.signal });
  } finally {
    clearTimeout(timeoutId);
    externalSignal?.removeEventListener('abort', abortHandler);
  }
}

// ============ إعدادات التأثيرات ============
let transitionEffect = 'fade';
let ayahDisplayDuration = 5000;
let effectAnimationDuration = 800;
let textColor = '#ffffff';
let contrastLevel = 80;
let glowEnabled = true;
let videoAdjustments = { brightness:100, contrast:100, saturation:100, warmth:0, hue:0, blur:0, vignette:0, exposure:0, blackPoint:0 };
let videoPostProcessCanvas = null;
let videoPostProcessCtx = null;
let ayahTransitionStart = Date.now();
let ayahDisplayStart = Date.now();
// v13: لحظة الإيقاف المؤقت — تُزاح بها الساعتان عند الاستئناف حتى لا يحسب زمن التوقف ضمن العرض.
let pausedAt = 0;
let ayahTimerHandle = null;
let audioStarted = false;
let audioEnded = false;

// ============ تأثيرات النص القرآني ============
let quranTextEffect = 'none';
let quranTextEffectIntensity = 1.0;
// v28: حركة النص المستمرة منفصلة عن نمطه البصري — تُجمعان معاً (دخول + نمط + حركة).
let quranMotionEffect = 'none';
let quranMotionIntensity = 1.0;

// ============ تأثيرات الانتقال للترجمة والتفسير ============
let translationTransitionEffect = 'fade';
let translationDisplayDuration = 3000; // v14: توافق محفوظات فقط — الترجمة الآن مقفلة مع الآية دخولاً وخروجاً.
let translationAnimationDuration = 600;

// ============ تأثيرات النص للترجمة والتفسير ============
let translationTextEffect = 'none';
let translationTextEffectIntensity = 1.0;
// v28: حركة مستمرة منفصلة (انظر quranMotionEffect).
let translationMotionEffect = 'none';
let translationMotionIntensity = 1.0;

// ============ الشعار والتذييل (v30) ============
// الشعار: صورة دائرية + اسم ملازم — تُرسمان على اللوحة في المعاينة والتصدير.
let logoImage = null;
let logoObjectUrl = null;
let logoSizePct = 12;
let logoPosition = 'bottom-right';
let logoOpacity = 100;
let logoBorderWidth = 3;
let logoBorderColor = '#d4af37';
let logoName = '';
let logoNameFont = 'Cairo';
let logoNameSize = 28;
let logoNameGap = 12;
let logoNameOpacity = 100;
let logoNameColor = '#f4e5a1';
// v31: تأثيرات الشعار (دخول/بصري/حركي — نفس قوائم الآيات).
let logoTransitionEffect = 'fade';
let logoTextEffect = 'none';
let logoMotionEffect = 'none';
// التذييل: نص مخصص (فارغ = النطاق التلقائي) أسفل الشاشة مكان الآية ورقمها.
let footerText = '';
let footerFont = 'Cairo';
let footerSize = 44;
let footerOpacity = 100;
let footerColor = '#d4af37';
// v31: تأثيرات التذييل (دخول/بصري/حركي — نفس قوائم الآيات).
let footerTransitionEffect = 'fade';
let footerTextEffect = 'none';
let footerMotionEffect = 'none';

// ============ تأثيرات الخلفية المتقدمة ============
let bgMotionEffect = 'none';
let bgMotionSpeed = 1.0;
let dynamicBackgroundContrast = 50;
let dynamicBackgroundSpeed = 1.0;

// ============ التوقيت الذكي ============
let timingMode = 'manual';
let adaptiveFactor = 1.0;

// ============ تأثيرات إضافية ============
let gradientEffect = 'none';
let particleEffectEnabled = false;
let vignetteEffectEnabled = false;

// ============ الترجمة والتفسير ============
let translationsData = {};
let tafsirData = {};
let translationKey = '';
let tafsirEnabled = false;
let surahNumberCurrent = null;
let availableTranslations = {};

// ============ الروايات والخطوط ============
let currentRiwayah = 'hafs';
let riwayahAyahsData = {};

let fontSettings = {
  family: 'auto',
  size: 68,
  color: '#ffffff',
  weight: 400,
  lineHeight: 2.2,
  bgColor: '#000000',
  bgOpacity: 0,
  borderColor: '#d4af37',
  borderWidth: 0,
  borderRadius: 8,
  shadow: 'medium'
};

// ============ إعدادات خط الترجمة والتفسير ============
let transFontSettings = {
  family: 'Cairo',
  size: 48,
  color: '#a3d0ff',
  weight: 400,
  lineHeight: 1.5,
  bgColor: '#000000',
  bgOpacity: 0,
  borderColor: '#d4af37',
  borderWidth: 0,
  borderRadius: 8,
  shadow: 'none'
};

const riwayahFontMap = {
  hafs: 'Hafs18',
  warsh: 'Warsh10'
};

const riwayahFontLabels = {
  hafs: 'KFGQPC Hafs 18 — الخط الرسمي',
  warsh: 'KFGQPC Warsh 10 — الخط الرسمي'
};

// v4: الحزمة الأولية المخففة = Cairo + Amiri Quran فقط (انظر index.html). باقي الخطوط تُحمّل عند الطلب عبر ensureGoogleFont.
const coreGoogleFonts = new Set(['Cairo', 'Amiri Quran']);
const loadedGoogleFonts = new Set(coreGoogleFonts);

function ensureGoogleFont(family) {
  const name = String(family || '').trim();
  if (!name || name === 'auto' || loadedGoogleFonts.has(name) || /^(Hafs|Warsh|Uthman|KFGQPC)/i.test(name)) return;
  const link = document.createElement('link');
  link.rel = 'stylesheet';
  link.href = `https://fonts.googleapis.com/css2?family=${encodeURIComponent(name)}&display=swap`;
  link.dataset.dynamicFont = name;
  document.head.appendChild(link);
  loadedGoogleFonts.add(name);
}

// ============ انتظار خطوط KFGQPC قبل الرسم/التصدير (P0-1a) ============
// مشكلة سابقة: أول رسم Canvas كان يحدث قبل اكتمال تحميل woff2 فيخبز fallback Amiri داخل الفيديو.
// هذه الدالة لا ترمي أبداً — تعيد true عند الجاهزية و false عند المهلة حتى لا نعلق التصدير.
const QURAN_FONT_LOAD_TIMEOUT_MS = 3500;
const _quranFontReadyCache = new Map();

function _loadSingleFont(family, timeoutMs) {
  const key = String(family || '');
  if (!key || key === 'auto') return Promise.resolve(true);
  if (_quranFontReadyCache.get(key) === true) return Promise.resolve(true);
  if (!document.fonts || typeof document.fonts.load !== 'function') return Promise.resolve(false);
  const loadPromise = Promise.all([
    document.fonts.load(`400 40px "${key}"`, 'بسم الله الرحمن الرحيم'),
    document.fonts.load(`700 40px "${key}"`, 'بسم الله الرحمن الرحيم')
  ]).then(
    () => { _quranFontReadyCache.set(key, true); return true; },
    () => false
  );
  const timeoutPromise = new Promise(resolve => setTimeout(() => resolve(false), Math.max(500, timeoutMs || QURAN_FONT_LOAD_TIMEOUT_MS)));
  return Promise.race([loadPromise, timeoutPromise]).then(ok => {
    if (ok) _quranFontReadyCache.set(key, true);
    return ok;
  });
}

async function ensureQuranFontsLoaded(families = null, timeoutMs = QURAN_FONT_LOAD_TIMEOUT_MS) {
  try {
    const wanted = Array.isArray(families) && families.length
      ? families
      : [getActiveQuranFontFamily(), 'Amiri', 'Amiri Quran'].filter((v, i, a) => v && a.indexOf(v) === i);
    const results = await Promise.all(wanted.map(f => _loadSingleFont(f, timeoutMs)));
    try {
      if (document.fonts?.ready) await Promise.race([document.fonts.ready, new Promise(r => setTimeout(r, 800))]);
    } catch (e) {}
    // مسح كاش التخطيط بعد اكتمال الخط حتى لا تبقى قياسات fallback مخبوزة.
    try { if (typeof textLayoutCache !== 'undefined' && results.some(Boolean)) textLayoutCache.clear(); } catch (e) {}
    return results.some(Boolean);
  } catch (e) {
    console.warn('تعذر انتظار خطوط القرآن:', e);
    return false;
  }
}

function preloadActiveQuranFont() {
  try {
    const family = typeof getActiveQuranFontFamily === 'function' ? getActiveQuranFontFamily() : null;
    if (family) _loadSingleFont(family, 2500).catch(() => {});
  } catch (e) {}
}

// خطوط إضافية: الخط الرسمي يبقى الخيار الافتراضي، وهذه خطوط بديلة للعرض والتصميم.
// ⚠️ قاعدة شرعية: عند اختيار ورش يجب أن تبقى الكتابة برسم ورش — لذا قائمة ورش
// تقتصر على خطوط رسم ورش (Warsh10 الرسمي + WarshV8 البديل الرسمي).
// الخطوط العامة (Amiri/Scheherazade/Noto) برسم حفص وقد تُشوّه علامات ورش
// (مثال: مَلِكِ بدون ألف، والهمزات اليائية) — تُعرض موسومة بوضوح كخيار عام.
const riwayahAdditionalFonts = {
  hafs: [
    { value:'HafsSmart8', label:'KFGQPC Hafs Smart 8 — بديل رسمي' },
    { value:'UthmanHafs', label:'Uthmanic Hafs — بديل قرآني' },
    { value:'UthmanNaskh', label:'Uthman Taha Naskh — متوافق' },
    { value:'Amiri Quran', label:'Amiri Quran — متوافق' },
    { value:'Scheherazade New', label:'Scheherazade New — متوافق' }
  ],
  warsh: [
    { value:'WarshV8', label:'KFGQPC Warsh v8 — بديل رسمي (رسم ورش)' },
    { value:'UthmanWarsh', label:'Uthmanic Warsh v2.1 — رسم ورش العثماني الأصلي (QCF)' },
    { value:'Lateef', label:'Lateef (SIL) — متوافق مع رسم ورش' },
    { value:'Noto Naskh Arabic', label:'Noto Naskh Arabic — نسخي متوافق مع ورش' },
    { value:'Scheherazade New', label:'Scheherazade New (SIL) — يدعم علامات ورش' },
    { value:'Amiri Quran', label:'Amiri Quran — عام (قد لا يعكس رسم ورش بدقة)' }
  ]
};

// خطوط برسم حفص حصراً — ممنوعة عند تفعيل رواية ورش (تُفسد رسم ورش بصرياً).
// ملاحظة v10: Noto Naskh أُخرج من هذه القائمة بعد توثيق دعمه لرسم ورش.
const hafsOnlyFontFamilies = new Set(['Hafs18', 'HafsSmart8', 'UthmanHafs', 'UthmanNaskh']);

function isFontAllowedForRiwayah(family, riwayah) {
  if (!family || family === 'auto') return true;
  if (riwayah === 'warsh' && hafsOnlyFontFamilies.has(family)) return false;
  return true;
}

// كل رواية لها قائمة قرّاء مستقلة. لا يتم خلط قرّاء رواية مع رواية أخرى.
// حافظنا على معرّفات حفص الحالية كما هي حتى لا تتأثر آلية الصوت الموجودة.
const riwayahReciters = {
  // حفص: مصادر آية-بآية معروفة في EveryAyah، مع فحص فعلي قبل تمكين التسجيل.
  hafs: [
    { value: 'ar.alafasy', label: 'مشاري العفاسي', everyAyahFolder: 'Alafasy_64kbps' },
    { value: 'ar.abdulbasitmurattal', label: 'عبد الباسط عبد الصمد (مرتل)', everyAyahFolder: 'Abdul_Basit_Murattal_64kbps' },
    { value: 'ar.abdurrahmaansudais', label: 'عبد الرحمن السديس', everyAyahFolder: 'Abdurrahmaan_As-Sudais_64kbps' },
    { value: 'ar.saoodshuraym', label: 'سعود الشريم', everyAyahFolder: 'Saood_ash-Shuraym_64kbps' },
    { value: 'ar.maaboralmueaqly', label: 'ماهر المعيقلي', everyAyahFolder: 'Maher_AlMuaiqly_64kbps' },
    { value: 'ar.husary', label: 'محمود الحصري', everyAyahFolder: 'Husary_64kbps' },
    { value: 'ar.minshawi', label: 'محمد صديق المنشاوي', everyAyahFolder: 'Minshawy_Murattal_128kbps' },
    { value: 'ar.hudhaify', label: 'علي الحذيفي', everyAyahFolder: 'Hudhaify_64kbps' },
    { value: 'ar.shaatree', label: 'أبو بكر الشاطري', everyAyahFolder: 'Abu_Bakr_Ash-Shaatree_64kbps' },
    { value: 'ar.abdullahbasfar', label: 'عبد الله بصفر', everyAyahFolder: 'Abdullah_Basfar_192kbps' },
    { value: 'ar.abdullahmatroud', label: 'عبد الله المطرود', everyAyahFolder: 'Abdullah_Matroud_128kbps' },
    { value: 'ar.faresabbad', label: 'فارس عباد', everyAyahFolder: 'Fares_Abbad_64kbps' },
    { value: 'ar.nasseralqatami', label: 'ناصر القطامي', everyAyahFolder: 'Nasser_Alqatami_128kbps' },
    { value: 'ar.yasseraldossari', label: 'ياسر الدوسري', everyAyahFolder: 'Yasser_Ad-Dussary_128kbps' }
  ],
  // ورش: نبدأ فقط بالمصادر الآية-بآية التي يمكن فحصها قبل التسجيل.
  warsh: [
    { value: 'warsh-ibrahim-aldosary', label: 'إبراهيم الدوسري (ورش)', everyAyahFolder: 'warsh/warsh_ibrahim_aldosary_128kbps', maqraFolder: 'https://huggingface.co/datasets/maqra-project/warsh-ibrahim-al-dosari-128kbps/resolve/main' },
    { value: 'warsh-yassin-al-jazaery', label: 'ياسين الجزائري (ورش)', everyAyahFolder: 'warsh/warsh_yassin_al_jazaery_64kbps' }
  ]
};

function refreshReciterOptions() {
  const select = document.getElementById('reciterSelect');
  if (!select) return;

  const reciters = riwayahReciters[currentRiwayah] || [];
  const previousValue = select.value;
  select.innerHTML = reciters.map(reciter =>
    `<option value="${reciter.value}">${reciter.label}</option>`
  ).join('');

  if (reciters.some(reciter => reciter.value === previousValue)) {
    select.value = previousValue;
  } else {
    select.value = '';
  }

  select.disabled = reciters.length === 0;
  const prepareButton = document.getElementById('prepareAudioBtn');
  if (prepareButton) prepareButton.disabled = reciters.length === 0;

  const status = document.getElementById('reciterRiwayahStatus');
  if (status) {
    const labels = { hafs: 'حفص عن عاصم', warsh: 'ورش عن نافع' };
    status.textContent = reciters.length
      ? `🔒 القائمة مقصورة على قرّاء رواية ${labels[currentRiwayah] || currentRiwayah} فقط.`
      : `⚠️ لا يتوفر مصدر صوت موثق لرواية ${labels[currentRiwayah] || currentRiwayah} حاليًا.`;
    status.style.color = reciters.length ? '#7a8a99' : '#f3c56b';
  }
}

function enforceRiwayahFont() {
  const officialFamily = riwayahFontMap[currentRiwayah] || 'Hafs18';
  fontSettings.family = officialFamily;
  const select = document.getElementById('fontFamilySelect');
  if (select) select.value = officialFamily;
  preloadActiveQuranFont();
}


function getActiveQuranFontFamily() {
  // حارس دفاعي: لو تسرب خط حفص (مشروع قديم/كاش) مع رواية ورش — نُجبر خط ورش الرسمي.
  if (currentRiwayah === 'warsh' && !isFontAllowedForRiwayah(fontSettings.family, 'warsh')) {
    return riwayahFontMap.warsh || 'Warsh10';
  }
  if (fontSettings.family === 'auto') {
    return riwayahFontMap[currentRiwayah] || 'Hafs18';
  }
  return fontSettings.family;
}

function getRiwayahDisplayLabel(riwayah = currentRiwayah) {
  return riwayah === 'warsh' ? 'ورش عن نافع' : 'حفص عن عاصم';
}

function refreshFontFamilyOptions() {
  const select = document.getElementById('fontFamilySelect');
  if (!select) return;

  const officialFamily = riwayahFontMap[currentRiwayah] || 'Hafs18';
  const officialLabel = riwayahFontLabels[currentRiwayah] || 'KFGQPC — الخط الرسمي';
  const extras = riwayahAdditionalFonts[currentRiwayah] || [];

  // P2: خيار auto دائم — كان resetFontBtn يضبط value='auto' ثم يُحذف الخيار فينکسر.
  select.innerHTML = [
    `<option value="auto">تلقائي — خط الرواية الحالية (${officialFamily})</option>`,
    `<option value="${officialFamily}">${officialLabel}</option>`,
    ...extras.map(font => `<option value="${font.value}">${font.label}</option>`)
  ].join('');

  if (!['auto', officialFamily, ...extras.map(f => f.value)].includes(fontSettings.family)) {
    fontSettings.family = 'auto';
  }
  select.value = fontSettings.family;
  preloadActiveQuranFont();
}

// ============ إعدادات الخلفية والإطار ============
let currentBgIndex = 0;
let customBgType = null;
let customBgImage = null;
let customBgVideo = null;
let customBgObjectUrl = null;
let frameIndex = 0;
let frameColor = '#d4af37';
let frameOpacity = 1.0;

// ============ التسجيلات المحفوظة ============
let savedRecordings = [];
const RECORDINGS_DB_NAME = 'quranStudioRecordings';
const RECORDINGS_DB_VERSION = 1;
const RECORDINGS_STORE = 'recordings';

function openRecordingsDatabase() {
  return new Promise((resolve, reject) => {
    if (!('indexedDB' in window)) { reject(new Error('IndexedDB غير متاح')); return; }
    const request = indexedDB.open(RECORDINGS_DB_NAME, RECORDINGS_DB_VERSION);
    request.onupgradeneeded = () => {
      if (!request.result.objectStoreNames.contains(RECORDINGS_STORE)) request.result.createObjectStore(RECORDINGS_STORE, { keyPath:'id' });
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error || new Error('تعذر فتح قاعدة التسجيلات'));
  });
}

async function saveRecordingToDatabase(recording) {
  try {
    const db = await openRecordingsDatabase();
    await new Promise((resolve, reject) => {
      const transaction = db.transaction(RECORDINGS_STORE, 'readwrite');
      transaction.objectStore(RECORDINGS_STORE).put({ ...recording, url:undefined });
      transaction.oncomplete = resolve;
      transaction.onerror = () => reject(transaction.error);
    });
    db.close();
  } catch (error) { console.warn('تعذر حفظ التسجيل في IndexedDB:', error); }
}

async function loadRecordingsFromDatabase() {
  try {
    const db = await openRecordingsDatabase();
    const records = await new Promise((resolve, reject) => {
      const request = db.transaction(RECORDINGS_STORE, 'readonly').objectStore(RECORDINGS_STORE).getAll();
      request.onsuccess = () => resolve(request.result || []);
      request.onerror = () => reject(request.error);
    });
    db.close();
    savedRecordings.forEach(record => { if (record.url) URL.revokeObjectURL(record.url); });
    savedRecordings = records.sort((a, b) => b.id - a.id).map(record => ({ ...record, url:URL.createObjectURL(record.blob) }));
    renderRecordings();
    updateStats();
  } catch (error) { console.warn('تعذر استعادة التسجيلات من IndexedDB:', error); }
}

async function deleteRecordingFromDatabase(id) {
  try {
    const db = await openRecordingsDatabase();
    await new Promise((resolve, reject) => {
      const transaction = db.transaction(RECORDINGS_STORE, 'readwrite');
      transaction.objectStore(RECORDINGS_STORE).delete(id);
      transaction.oncomplete = resolve;
      transaction.onerror = () => reject(transaction.error);
    });
    db.close();
  } catch (error) { console.warn('تعذر حذف التسجيل من IndexedDB:', error); }
}

const exportProfiles = {
  default: { label:'تصدير عام', previewClass:'', aspect:'9:16', width:1080, height:1920, previewWidth:1080, previewHeight:1920, fps:30, videoMbps:8, audioKbps:192, mime:['video/webm;codecs=vp9,opus','video/webm;codecs=vp8,opus','video/webm','video/mp4'], info:'تصدير فيديو عمودي بجودة عالية.' }
};
const exportQualities = {
  medium: { label:'متوسطة', bitrateFactor:.75, dimensions:{square:[720,720], landscape:[1280,720], portrait:[720,1280]} },
  high: { label:'عالية', bitrateFactor:1, dimensions:{square:[1080,1080], landscape:[1920,1080], portrait:[1080,1920]} },
  '2k': { label:'2K', bitrateFactor:1.6, dimensions:{square:[1440,1440], landscape:[2560,1440], portrait:[1440,2560]} }
};

// ============ أنواع التصدير (تحل محل قوالب المنصات المحذوفة) ============
// المستخدم يختار المخرجات لا الهوية البصرية: الهوية الحالية (خط/خلفية/إطار) تُحترم كما هي.
const exportModes = {
  'full': { name:'فيديو كامل', icon:'🎬', needsVideo:true, needsAudio:true, hint:'🎬 فيديو كامل: يُصدَّر Canvas مع صوت المقرئ/الملف اليدوي.' },
  'video-only': { name:'فيديو بدون صوت', icon:'🎥', needsVideo:true, needsAudio:false, hint:'🎥 فيديو بدون صوت: يُصدَّر Canvas صامتاً. لا حاجة لتجهيز الصوت.' },
  'audio-only': { name:'صوتي فقط', icon:'🎧', needsVideo:false, needsAudio:true, hint:'🎧 صوتي فقط: يُصدَّر مسار التلاوة مسموعاً (WebM صوتي). المقاس والجودة المرئية غير مؤثرة.' }
};
// صيغ الصوت للتصدير الصوتي (مرتبة بالأفضلية).
const audioExportMimes = ['audio/webm;codecs=opus', 'audio/webm', 'audio/mp4'];
let currentExportProfile = 'default';
let currentExportMode = 'full';
const videoFormats = {
  square: { label:'1:1 — مربع', aspect:'1:1', width:1080, height:1080, previewClass:'format-square' },
  landscape: { label:'16:9 — أفقي', aspect:'16:9', width:1920, height:1080, previewClass:'format-landscape' },
  portrait: { label:'9:16 — عمودي', aspect:'9:16', width:1080, height:1920, previewClass:'format-portrait' }
};
let currentVideoFormat = 'portrait';
let currentExportQuality = 'high';
let exportCanvasRestoreState = null;
let finalExportInProgress = false;
// v24: متغيرات معاينة العينات حُذفت مع إفراغ قسم التأثيرات.
let exportStartedAt = 0;
let exportTelemetryTimer = null;
let exportStoppedByUser = false;
let exportExpectedDurationMs = 0;
let exportExpectedBytes = 0;

function getActiveExportSpec() {
  const profile = exportProfiles[currentExportProfile] || exportProfiles.default;
  const quality = exportQualities[currentExportQuality] || exportQualities.high;
  const format = videoFormats[currentVideoFormat] || videoFormats.portrait;
  const qualityDimensions = quality.dimensions?.[currentVideoFormat];
  const dims = qualityDimensions || [format.width, format.height];
  const baseBitrate = Number(profile.videoMbps) || 8;
  const mode = exportModes[currentExportMode] ? currentExportMode : 'full';
  return { profile, quality, format, mode, width:dims[0], height:dims[1], fps:profile.fps, videoMbps:Math.max(4, baseBitrate * quality.bitrateFactor), audioKbps:profile.audioKbps };
}

function updateFinalExportSpec() {
  const spec = getActiveExportSpec();
  const el = document.getElementById('finalExportSpec');
  if (!el) return;
  const modeLabel = (exportModes[spec.mode]?.icon || '') + ' ' + (exportModes[spec.mode]?.name || spec.mode);
  if (spec.mode === 'audio-only') {
    el.textContent = `${modeLabel} • صوت ${spec.audioKbps}kbps Opus • WebM صوتي • المدة حسب الآيات`;
  } else if (spec.mode === 'video-only') {
    el.textContent = `${modeLabel} • ${spec.format.label} • ${spec.width}×${spec.height} • ${spec.fps}fps • ${spec.videoMbps.toFixed(1)}Mbps • بدون مسار صوتي`;
  } else {
    el.textContent = `${modeLabel} • ${spec.format.label} • ${spec.width}×${spec.height} • ${spec.fps}fps • ${spec.videoMbps.toFixed(1)}Mbps • صوت ${spec.audioKbps}kbps • WebM/MP4 حسب دعم المتصفح`;
  }
}

function setExportCanvasResolution(width, height) {
  if (!canvas || canvas.width === width && canvas.height === height) return;
  if (!exportCanvasRestoreState) exportCanvasRestoreState = { width:canvas.width, height:canvas.height };
  canvas.width = width;
  canvas.height = height;
  ctx = canvas.getContext('2d');
  ensureVideoPostProcessCanvas();
}

function restoreExportCanvasResolution() {
  if (!exportCanvasRestoreState || !canvas) return;
  const {width,height} = exportCanvasRestoreState;
  exportCanvasRestoreState = null;
  canvas.width = width;
  canvas.height = height;
  ctx = canvas.getContext('2d');
  ensureVideoPostProcessCanvas();
}

function revokeCustomBgObjectUrl() {
  if (customBgObjectUrl) {
    try { URL.revokeObjectURL(customBgObjectUrl); } catch (e) {}
    customBgObjectUrl = null;
  }
}

function applyExportMode(key) {
  if (!exportModes[key] || finalExportInProgress) return;
  currentExportMode = key;
  const mode = exportModes[key];
  const select = document.getElementById('exportModeSelect');
  if (select) select.value = key;
  const hint = document.getElementById('exportModeHint');
  if (hint) hint.textContent = mode.hint;
  // الجودة المرئية لا معنى لها في الوضع الصوتي — نعطلها بصرياً لا وظيفياً.
  const qualitySelect = document.getElementById('finalExportQualitySelect');
  if (qualitySelect) {
    qualitySelect.disabled = (key === 'audio-only');
    qualitySelect.title = (key === 'audio-only') ? 'الجودة المرئية غير مؤثرة في التصدير الصوتي' : '';
  }
  updateFinalExportSpec();
}

function applyExportQuality(key, persist = true) {
  if (!exportQualities[key] || finalExportInProgress) return;
  currentExportQuality = key;
  updateFinalExportSpec();
  const quality = exportQualities[key];
  const spec = getActiveExportSpec();
  const status = document.getElementById('finalExportStatus');
  if (status) status.textContent = `الجودة المختارة: ${quality.label} — ${spec.width}×${spec.height}. سيتم تطبيقها على ملف الفيديو النهائي فقط.`;
  if (persist && typeof scheduleProjectAutosave === 'function') scheduleProjectAutosave();
}

function applyVideoFormat(key, persist = true) {
  if (!videoFormats[key] || finalExportInProgress) return;
  currentVideoFormat = key;
  const format = videoFormats[key];
  const select = document.getElementById('videoFormatSelect');
  if (select) select.value = key;
  updateExportPreview(currentExportProfile);
  updateFinalExportSpec();
  if (persist && typeof scheduleProjectAutosave === 'function') scheduleProjectAutosave();
}

function setPreviewCanvasResolution(width, height) {
  if (!canvas || finalExportInProgress) return;
  width = Math.max(1, Math.round(Number(width) || 1080));
  height = Math.max(1, Math.round(Number(height) || 1920));
  if (canvas.width === width && canvas.height === height) return;
  canvas.width = width;
  canvas.height = height;
  ctx = canvas.getContext('2d');
  ensureVideoPostProcessCanvas();
}

function updateExportPreview(key = currentExportProfile) {
  const screen = document.querySelector('.phone-screen');
  if (!screen) return;
  const profile = exportProfiles[key] || exportProfiles.default;
  const format = videoFormats[currentVideoFormat] || videoFormats.portrait;
  const previewWidth = format.width;
  const previewHeight = format.height;

  // مهم: شاشة المعاينة وCanvas يجب أن يتغيرا معاً.
  // سابقاً كان يتم تغيير إطار المعاينة فقط، بينما بقي Canvas داخلياً 1080×1920؛
  // لذلك كان Instagram/YouTube يظهران وكأنهما Zoom/Crop وكان رقم الآية واسم السورة يختفيان.
  setPreviewCanvasResolution(previewWidth, previewHeight);

  screen.classList.remove('export-instagram','export-youtube','export-tiktok','format-square','format-landscape','format-portrait');
  screen.classList.add(format.previewClass);
  // نربط أبعاد شاشة المعاينة بالقالب الفعلي: 1:1 / 16:9 / 9:16.
  const previewMaxW = 420;
  const previewMaxH = 570;
  const previewScale = Math.min(previewMaxW / previewWidth, previewMaxH / previewHeight);
  const previewWidthPx = Math.round(previewWidth * previewScale);
  const previewHeightPx = Math.round(previewHeight * previewScale);
  screen.style.aspectRatio = `${previewWidth} / ${previewHeight}`;
  screen.style.width = `${previewWidthPx}px`;
  screen.style.height = `${previewHeightPx}px`;
  const frame = screen.closest('.phone-frame');
  let frameWidthPx = previewWidthPx;
  if (frame) {
    const framePadding = parseFloat(getComputedStyle(frame).paddingLeft || '12') * 2;
    frameWidthPx = Math.min(460, previewWidthPx + framePadding);
    frame.style.width = `${frameWidthPx}px`;
  }
  // v6: مشغل الميديا يُزامَن عرضه مع عرض إطار المعاينة لنفس المقاس (مربع/أفقي/عمودي).
  const previewPanel = screen.closest('.preview-panel');
  if (previewPanel) previewPanel.style.setProperty('--preview-w', `${frameWidthPx}px`);
  const formatBadge = document.getElementById('playerFormatBadge');
  if (formatBadge) formatBadge.textContent = format.aspect || '';
  const mirror = document.getElementById('ayahsPreviewMirror');
  const mirrorDock = document.querySelector('.ayahs-preview-dock-canvas');
  if (mirror) {
    mirror.width = 360;
    mirror.height = Math.max(1, Math.round(360 * previewHeight / previewWidth));
  }
  if (mirrorDock) mirrorDock.style.aspectRatio = `${previewWidth} / ${previewHeight}`;
  const activeSpec = getActiveExportSpec();
  screen.dataset.exportWidth = String(activeSpec.width);
  screen.dataset.exportHeight = String(activeSpec.height);

  let overlay = screen.querySelector('.export-preview-overlay');
  if (!overlay) { overlay = document.createElement('div'); overlay.className = 'export-preview-overlay'; screen.appendChild(overlay); }
  overlay.dataset.label = `${format.label} • ${activeSpec.width}×${activeSpec.height}`;
  if (!screen.querySelector('.export-preview-safe')) {
    const safe = document.createElement('div');
    safe.className = 'export-preview-safe';
    screen.appendChild(safe);
  }
}


// ============ المرحلة 1: إدارة المشروع والحفظ التلقائي ============
const PROJECT_STORAGE_KEY = 'quranStudio.projects.v1';
const PROJECT_CURRENT_KEY = 'quranStudio.currentProject.v1';
const PROJECT_SCHEMA_VERSION = 3;
let currentProjectId = null;
let projectAutosaveTimer = null;
let projectRestoreInProgress = false;
let pendingProjectRestore = null;
let isResettingToDefaults = false;

// ============ إدارة العمليات غير المتزامنة ============
// كل طلب يحصل على token + AbortController لمنع Race Conditions والنتائج القديمة.
const asyncRequestState = {
  content: { token: 0, controller: null },
  translation: { token: 0, controller: null },
  tafsir: { token: 0, controller: null },
  audio: { token: 0, controller: null }
};

function createAbortController() {
  return typeof AbortController !== 'undefined' ? new AbortController() : null;
}

function beginAsyncRequest(kind) {
  const state = asyncRequestState[kind];
  if (!state) throw new Error(`نوع طلب غير معروف: ${kind}`);
  try { state.controller?.abort(); } catch (e) {}
  state.controller = createAbortController();
  state.token += 1;
  return { kind, token: state.token, signal: state.controller?.signal, controller: state.controller };
}

function invalidateAsyncRequest(kind) {
  const state = asyncRequestState[kind];
  if (!state) return;
  try { state.controller?.abort(); } catch (e) {}
  state.controller = null;
  state.token += 1;
}

function isAsyncRequestCurrent(kind, request) {
  const state = asyncRequestState[kind];
  return !!state && !!request && request.token === state.token;
}

function isAbortError(error) {
  return error?.name === 'AbortError' || /aborted|إلغاء|ملغ/i.test(String(error?.message || ''));
}


