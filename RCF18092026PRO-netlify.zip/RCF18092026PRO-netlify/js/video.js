function formatTime(seconds) {
  const total = Math.max(0, Math.floor(Number(seconds) || 0));
  const minutes = Math.floor(total / 60).toString().padStart(2, '0');
  const remainder = (total % 60).toString().padStart(2, '0');
  return `${minutes}:${remainder}`;
}

function formatFileSize(bytes) {
  const value = Number(bytes) || 0;
  if (value < 1024 * 1024) return `${Math.max(0, value / 1024).toFixed(0)} KB`;
  return `${(value / (1024 * 1024)).toFixed(1)} MB`;
}

function updateExportTelemetry() {
  const elapsedMs = exportStartedAt ? Math.max(0, Date.now() - exportStartedAt) : 0;
  const elapsed = Math.floor(elapsedMs / 1000);
  const remainingMs = exportExpectedDurationMs ? Math.max(0, exportExpectedDurationMs - elapsedMs) : 0;
  const progress = document.getElementById('finalExportProgress');
  const elapsedEl = document.getElementById('exportElapsed');
  const remainingEl = document.getElementById('exportRemaining');
  const currentSizeEl = document.getElementById('exportCurrentSize');
  const expectedSizeEl = document.getElementById('exportExpectedSize');
  if (elapsedEl) elapsedEl.textContent = formatTime(elapsed);
  if (remainingEl) remainingEl.textContent = exportExpectedDurationMs ? formatTime(Math.ceil(remainingMs / 1000)) : '—';
  if (currentSizeEl) currentSizeEl.textContent = formatFileSize(recordedChunks.reduce((sum, chunk) => sum + (chunk.size || 0), 0));
  if (expectedSizeEl) expectedSizeEl.textContent = exportExpectedBytes ? formatFileSize(exportExpectedBytes) : '—';
  if (progress && exportExpectedDurationMs) progress.value = Math.min(99, (elapsedMs / exportExpectedDurationMs) * 100);
}

function resetExportTelemetry() {
  clearInterval(exportTelemetryTimer);
  exportTelemetryTimer = null;
  exportStartedAt = 0;
  exportExpectedDurationMs = 0;
  exportExpectedBytes = 0;
  exportStoppedByUser = false;
  updateExportTelemetry();
}

function getExportCapabilityReport() {
  const mediaRecorder = typeof window.MediaRecorder !== 'undefined';
  const canvasCapture = Boolean(canvas && typeof canvas.captureStream === 'function');
  const audioContext = Boolean(window.AudioContext || window.webkitAudioContext);
  const mediaStream = typeof window.MediaStream !== 'undefined';
  const mimeTypes = mediaRecorder
    ? (exportProfiles.default.mime || []).filter(type => MediaRecorder.isTypeSupported(type))
    : [];
  const missing = [];
  if (!mediaRecorder) missing.push('MediaRecorder');
  if (!canvasCapture) missing.push('Canvas captureStream');
  if (!audioContext) missing.push('Web Audio');
  if (!mediaStream) missing.push('MediaStream');
  if (!mimeTypes.length) missing.push('صيغة فيديو مدعومة');
  return { supported: missing.length === 0, missing, mimeTypes };
}

// ============ P0-1b: اختبار CORS للصوت قبل التصدير ============
// captureStream / MediaElementSource يتطلبان CORS نظيفاً، وإلا خرج فيديو صامت.
// نفحص أول مقطع فقط (نفس المضيف لبقية النطاق) بطلب Range صغير ولا نعلق التصدير أكثر من 6s.
let lastAudioCorsCheck = { url: '', ok: true, checkedAt: 0, host: '' };

async function probeAudioCorsOk(url, timeoutMs = 6000) {
  if (!url || audioSourceMode === 'upload') return true;
  try {
    const controller = typeof AbortController !== 'undefined' ? new AbortController() : null;
    const timer = setTimeout(() => { try { controller?.abort(); } catch (e) {} }, Math.max(1000, timeoutMs));
    try {
      const res = await fetch(url, {
        method: 'GET',
        mode: 'cors',
        cache: 'no-store',
        credentials: 'omit',
        headers: { Range: 'bytes=0-0' },
        signal: controller?.signal
      });
      // أي استجابة (200/206/404/403) تعني أن الخادم رد مع CORS — المسار قابل للالتقاط.
      return true;
    } finally {
      clearTimeout(timer);
    }
  } catch (e) {
    // TypeError: Failed to fetch غالباً = حجب CORS أو شبكة. نعتبره خطر صمت ونحذر فقط.
    console.warn('فحص CORS للصوت فشل (سيتم التحذير لا المنع):', e?.message || e);
    return false;
  }
}

async function checkReciterAudioCorsBeforeExport() {
  if (audioSourceMode !== 'reciter' || !currentAyahs.length) return { ok: true, skipped: true };
  const sampleUrl = currentAyahs[0]?.audio || currentAyahs[0]?.audioCandidates?.[0] || '';
  if (!sampleUrl) return { ok: false, skipped: false, reason: 'no-url' };
  try {
    const host = new URL(sampleUrl, location.href).host;
    const now = Date.now();
    if (lastAudioCorsCheck.url === sampleUrl && (now - lastAudioCorsCheck.checkedAt) < 5 * 60 * 1000) {
      return { ok: lastAudioCorsCheck.ok, cached: true, host };
    }
    const statusEl = document.getElementById('finalExportStatus');
    if (statusEl) statusEl.textContent = '🔒 جاري فحص صلاحية الصوت للتصدير (CORS)...';
    const ok = await probeAudioCorsOk(sampleUrl, 6000);
    lastAudioCorsCheck = { url: sampleUrl, ok, checkedAt: now, host };
    return { ok, host };
  } catch (e) {
    return { ok: true, skipped: true };
  }
}

// ============ إدارة التوقيت ============
function clearAyahTimer() {
  if (ayahTimerHandle) {
    clearTimeout(ayahTimerHandle);
    ayahTimerHandle = null;
  }
}

function advanceToNextAyah() {
  clearAyahTimer();
  audioEnded = false;
  currentAyahIndex++;
  ayahTransitionStart = Date.now();
  ayahDisplayStart = Date.now();

  if (currentAyahIndex < currentAyahs.length) {
    playCurrentAyah();
  } else {
    if (mediaRecorder && mediaRecorder.state === 'recording') {
      stopRecording(false);
    } else {
      isPlaying = false;
      audio.pause();
      setStatus('✅ انتهت التلاوة', 'success');
      updatePlayPauseUI();
    }
  }
}

function updateAudioSourceUI() {
  const reciterBox = document.getElementById('reciterAudioOptions');
  const uploadBox = document.getElementById('uploadAudioOptions');
  const isUpload = audioSourceMode === 'upload';
  reciterBox.style.display = isUpload ? 'none' : 'block';
  uploadBox.style.display = isUpload ? 'block' : 'none';
}

function setAudioStatus(message, type = '') {
  const el = document.getElementById('audioStatus');
  if (!el) return;
  el.textContent = message;
  el.style.color = type === 'success' ? '#7ed6a5' : type === 'error' ? '#ff8d8d' : type === 'warning' ? '#f3c56b' : '';
}

function validateSelectedAyahAudio() {
  if (!currentAyahs.length) {
    setAudioStatus('⚠️ جلب الآيات أولاً، ثم سيُجهّز صوت النطاق المحدد تلقائيًا.', 'warning');
    return false;
  }
  const missing = currentAyahs.filter(a => !a.audioVerified || !a.audio);
  if (missing.length) {
    setAudioStatus(`⚠️ يجب فحص جميع آيات النطاق أولاً. المتبقي للتحقق: ${missing.length} آية.`, 'warning');
    return false;
  }
  setAudioStatus(`✅ تم التحقق من صوت ${currentAyahs.length} آية — من الآية ${currentAyahs[0].numberInSurah} إلى ${currentAyahs[currentAyahs.length - 1].numberInSurah}.`, 'success');
  return true;
}

function getManualAudioAyahDuration() {
  if (!manualAudioUrl || !currentAyahs.length) return ayahDisplayDuration;
  if (audio.duration && isFinite(audio.duration) && audio.duration > 0) {
    manualAudioAyahDurationMs = (audio.duration * 1000) / currentAyahs.length;
    return manualAudioAyahDurationMs;
  }
  return manualAudioAyahDurationMs || ayahDisplayDuration;
}

function handleManualAudioFile(file) {
  if (!file) return;
  if (!file.type || !file.type.startsWith('audio/')) {
    setAudioStatus('❌ الملف المحدد ليس ملفًا صوتيًا صالحًا.', 'error');
    return;
  }
  if (file.size > MAX_AUDIO_FILE_SIZE) {
    setAudioStatus(`❌ حجم الملف الصوتي أكبر من الحد المسموح (${Math.round(MAX_AUDIO_FILE_SIZE / (1024 * 1024))}MB).`, 'error');
    return;
  }
  if (manualAudioUrl) URL.revokeObjectURL(manualAudioUrl);
  manualAudioFile = file;
  manualAudioUrl = URL.createObjectURL(file);
  audioSourceMode = 'upload';
  audio.pause();
  audio.src = manualAudioUrl;
  audio.addEventListener('loadedmetadata', () => {
    getManualAudioAyahDuration();
    setAudioStatus(`✅ تم تحميل الملف اليدوي (${formatTime(audio.duration)}). سيتم توزيع الصوت على ${currentAyahs.length || 'النطاق المحدد'} آية عند التشغيل.`, 'success');
  }, { once: true });
  audio.load();
  document.getElementById('uploadedAudioInfo').textContent = `✅ ${file.name} — ${(file.size / (1024 * 1024)).toFixed(2)} MB`;
  document.getElementById('clearAudioBtn').style.display = 'block';
  setAudioStatus('✅ تم تحميل الملف اليدوي. سيُستخدم كمسار صوتي للفيديو.', 'success');
  updateAudioSourceUI();
}

function clearManualAudio() {
  audio.pause();
  if (manualAudioUrl) URL.revokeObjectURL(manualAudioUrl);
  manualAudioUrl = '';
  manualAudioFile = null;
  manualAudioAyahDurationMs = 0;
  document.getElementById('audioFileInput').value = '';
  document.getElementById('uploadedAudioInfo').textContent = 'اختر ملف MP3 أو WAV أو M4A ليُستخدم كمسار صوتي للفيديو.';
  document.getElementById('clearAudioBtn').style.display = 'none';
  audio.removeAttribute('src');
  audio.load();
  setAudioStatus('تمت إزالة الملف الصوتي اليدوي.', '');
}

// طول المقطع الصوتي الفعلي للآية (بعد سرعة التشغيل)، أو fallbackMs عند غيابه.
// يُستخدم لتوحيد التقدير مع التشغيل الحقيقي — راجع playCurrentAyah.
function getAyahAudioLengthMs(ayah, fallbackMs = 0) {
  const fallback = Math.max(0, Number(fallbackMs) || 0);
  if (typeof exportWithoutAudio !== 'undefined' && exportWithoutAudio) return fallback;
  const speed = Math.max(0.25, Number(playbackSpeed) || 1);
  if (audioSourceMode === 'upload') {
    if (!manualAudioUrl || !currentAyahs.length) return fallback;
    const seg = getManualAudioAyahDuration();
    return (Number.isFinite(seg) && seg > 0 ? seg : fallback) / speed;
  }
  const naturalMs = Number(ayah?.audioDurationMs);
  if (Number.isFinite(naturalMs) && naturalMs > 0) return naturalMs / speed;
  return fallback;
}

function getAyahSyncDurationMs(ayah) {
  if (!ayah) return Math.max(250, ayahDisplayDuration);
  const baseDuration = Math.max(1000, Number(ayahDisplayDuration) || 5000);
  const textLength = String(ayah.text || '').replace(/\s+/g, '').length;
  const adaptiveDuration = Math.max(1000, Math.min(120000,
    5000 * Math.max(.5, Math.min(2.5, textLength / 50)) * Math.max(.5, adaptiveFactor)
  ));
  // المؤقت حسب الوضع (الحد الأدنى للعرض).
  let timerDuration = baseDuration;
  if (timingMode === 'adaptive') timerDuration = adaptiveDuration;
  else if (timingMode === 'smart') timerDuration = (baseDuration + adaptiveDuration) / 2;
  else if (timingMode === 'audio') timerDuration = getAyahAudioLengthMs(ayah, baseDuration);
  // إصلاح فادح: التشغيل الفعلي ينتظر انتهاء الصوت دائماً (playCurrentAyah)،
  // فالتقدير القديم (المؤقت فقط) كان يعرض مدة أقصر بكثير من الفيديو الحقيقي
  // في الوضع اليدوي/المتكيف/الذكي مع تلاوة أطول من المؤقت.
  // ملاحظة: الترجمة والتفسير يُعرضان مع الآية نفسها (تزامن لا تعاقب)،
  // فلا يضيفان زمناً — إدخالهما سابقاً كان يضخم التقدير عكساً عند طولهما.
  const audioLen = getAyahAudioLengthMs(ayah, 0);
  return Math.max(250, timerDuration, audioLen);
}

function getTimelineTotalDurationMs() {
  if (!currentAyahs.length) return 0;
  return currentAyahs.reduce((sum, ayah) => sum + getAyahSyncDurationMs(ayah), 0);
}

function playCurrentAyah() {
  if (!isPlaying || isPaused) return;
  if (currentAyahIndex >= currentAyahs.length) { advanceToNextAyah(); return; }

  const ayah = currentAyahs[currentAyahIndex];
  let currentAyahDuration = getAyahSyncDurationMs(ayah);
  clearAyahTimer();
  audioEnded = false;
  ayahTransitionStart = Date.now();
  ayahDisplayStart = Date.now();
  audioStarted = false;

  const items = document.querySelectorAll('.ayah-item');
  items.forEach((el, i) => el.classList.toggle('selected', i === currentAyahIndex));
  updateAyahTimeline();

  const scheduleAdvance = () => {
    if (!isPlaying || isPaused) return;
    clearAyahTimer();
    ayahTimerHandle = setTimeout(() => {
      if (audioEnded) {
        advanceToNextAyah();
      } else {
        const audioEl = audio;
        if (audioEl.duration && isFinite(audioEl.duration)) {
          const remainingAudio = (audioEl.duration - audioEl.currentTime) * 1000 / playbackSpeed;
          if (remainingAudio > 0 && remainingAudio < 120000) {
            ayahTimerHandle = setTimeout(() => advanceToNextAyah(), remainingAudio + 200);
          } else {
            ayahTimerHandle = setTimeout(() => advanceToNextAyah(), 30000);
          }
        } else {
          ayahTimerHandle = setTimeout(() => advanceToNextAyah(), 30000);
        }
      }
    }, currentAyahDuration);
  };

  // وضع الفيديو الصامت (video-only): تقديم مؤقت فقط دون تشغيل أي صوت أو تسجيله.
  if (typeof exportWithoutAudio !== 'undefined' && exportWithoutAudio) {
    audioEnded = true;
    clearAyahTimer();
    ayahTimerHandle = setTimeout(() => { if (isPlaying && !isPaused) advanceToNextAyah(); }, Math.max(250, currentAyahDuration));
    return;
  }

  if (audioSourceMode === 'upload' && manualAudioUrl) {
    const manualSegmentDuration = getManualAudioAyahDuration();
    const manualDuration = currentAyahDuration;
    const targetTime = Math.max(0, (currentAyahIndex * manualSegmentDuration) / 1000);
    if (Math.abs((audio.currentTime || 0) - targetTime) > 0.35) {
      try { audio.currentTime = targetTime; } catch (e) {}
    }
    audio.playbackRate = playbackSpeed;
    audioStarted = true;

    let manualAudioStartGuard = setTimeout(() => {
      if (!audioStarted || audio.paused) {
        audioEnded = true;
        if (isPlaying && !isPaused) advanceToNextAyah();
      }
    }, 3000);

    audio.onended = () => {
      clearTimeout(manualAudioStartGuard);
      audioEnded = true;
      if (isPlaying && !isPaused) advanceToNextAyah();
    };
    audio.onerror = () => {
      clearTimeout(manualAudioStartGuard);
      audioEnded = true;
      if (isPlaying && !isPaused) {
        ayahTimerHandle = setTimeout(() => advanceToNextAyah(), Math.max(500, manualDuration));
      }
    };

    audio.play().then(() => {
      clearTimeout(manualAudioStartGuard);
      clearAyahTimer();
      // v13: تثبيت الساعة البصرية على بدء الصوت الفعلي — النص والترجمة يزامنان الصوت لا لحظة التحميل.
      if (currentAyahs[currentAyahIndex] === ayah && isPlaying && !isPaused) {
        ayahTransitionStart = Date.now();
        ayahDisplayStart = Date.now();
      }
      ayahTimerHandle = setTimeout(() => {
        if (isPlaying && !isPaused) advanceToNextAyah();
      }, Math.max(250, manualDuration));
    }).catch(() => {
      clearTimeout(manualAudioStartGuard);
      audioEnded = true;
      ayahTimerHandle = setTimeout(() => advanceToNextAyah(), Math.max(500, manualDuration));
    });
  } else if (ayah.audio || ayah.audioCandidates?.length) {
    audio.pause();
    audio.muted = false;
    audio.volume = 1;
    audio.preload = 'auto';

    const candidates = Array.isArray(ayah.audioCandidates) && ayah.audioCandidates.length
      ? ayah.audioCandidates
      : [ayah.audio].filter(Boolean);
    let candidateIndex = Number.isInteger(ayah.audioCandidateIndex) ? ayah.audioCandidateIndex : 0;
    let audioStartGuard = null;
    let fallbackInProgress = false;

    const finishWithError = (message) => {
      audioStarted = false;
      audioEnded = true;
      setAudioStatus(message, 'error');
      if (isPlaying && !isPaused) {
        const elapsed = Date.now() - ayahDisplayStart;
        const remaining = Math.max(500, currentAyahDuration - elapsed);
        ayahTimerHandle = setTimeout(() => advanceToNextAyah(), remaining);
      }
    };

    const tryNextAudioSource = (reason) => {
      if (fallbackInProgress) return false;
      fallbackInProgress = true;
      clearTimeout(audioStartGuard);

      if (candidateIndex + 1 < candidates.length) {
        candidateIndex++;
        ayah.audioCandidateIndex = candidateIndex;
        ayah.audio = candidates[candidateIndex];
        console.warn(`فشل مصدر الصوت للآية ${ayah.numberInSurah}، تجربة المصدر الاحتياطي ${candidateIndex + 1}/${candidates.length}`, reason || '');
        audio.pause();
        audio.removeAttribute('src');
        audio.load();
        fallbackInProgress = false;
        loadAndPlayAudioSource();
        return true;
      }

      finishWithError(`❌ تعذر تشغيل صوت الآية ${ayah.numberInSurah} بعد تجربة ${candidates.length} مصادر صوتية.`);
      return false;
    };

    const loadAndPlayAudioSource = () => {
      fallbackInProgress = false;
      audio.pause();
      audio.muted = false;
      audio.volume = 1;
      audio.preload = 'auto';
      audio.currentTime = 0;
      audio.src = candidates[candidateIndex];
      ayah.audio = candidates[candidateIndex];
      audio.playbackRate = playbackSpeed;
      audioStarted = false;

      audio.onloadedmetadata = () => {
        if (audio.duration && isFinite(audio.duration)) {
          ayah.audioDurationMs = audio.duration * 1000;
          currentAyahDuration = getAyahSyncDurationMs(ayah);
          updateAyahTimeline();
          updateStats();
          scheduleAdvance();
        }
      };

      audio.onended = () => {
        clearTimeout(audioStartGuard);
        audioEnded = true;
        if (!isPlaying || isPaused) return;
        const elapsed = Date.now() - ayahDisplayStart;
        if (elapsed >= currentAyahDuration) {
          advanceToNextAyah();
        } else {
          clearAyahTimer();
          const remaining = currentAyahDuration - elapsed;
          ayahTimerHandle = setTimeout(() => advanceToNextAyah(), remaining);
        }
      };

      audio.onerror = (e) => {
        const mediaError = audio.error;
        console.warn('فشل مصدر الصوت:', candidates[candidateIndex], mediaError || e);
        audioStarted = false;
        audioEnded = true;
        tryNextAudioSource(mediaError?.message || 'media error');
      };

      audioStartGuard = setTimeout(() => {
        if (!audioStarted || audio.paused) {
          tryNextAudioSource('لم يبدأ التشغيل خلال المهلة المحددة');
        }
      }, 3500);

      audio.play().then(() => {
        clearTimeout(audioStartGuard);
        audioStarted = true;
        audioEnded = false;
        // v13: تثبيت الساعة البصرية على بدء التلاوة الفعلي (بعد جلب المقطع) — يلغي انزلاق النص قبل الصوت.
        if (currentAyahs[currentAyahIndex] === ayah && isPlaying && !isPaused) {
          ayahTransitionStart = Date.now();
          ayahDisplayStart = Date.now();
        }
        if (audio.duration && isFinite(audio.duration)) {
          ayah.audioDurationMs = audio.duration * 1000;
          currentAyahDuration = getAyahSyncDurationMs(ayah);
        }
        updateAyahTimeline();
        updateStats();
        setAudioStatus(`🔊 يتم تشغيل الآية ${ayah.numberInSurah} الآن.`, 'success');
        scheduleAdvance();
      }).catch(err => {
        console.warn('فشل تشغيل المصدر الحالي:', candidates[candidateIndex], err);
        audioStarted = false;
        tryNextAudioSource(err?.message || 'play() failed');
      });
    };

    loadAndPlayAudioSource();
  } else {
    audioEnded = true;
    ayahTimerHandle = setTimeout(() => advanceToNextAyah(), currentAyahDuration);
  }
}

function startPreview() {
  if (currentAyahs.length === 0) {
    setStatus('⚠️ الرجاء جلب الآيات أولاً', 'error');
    return;
  }

  clearAyahTimer();
  audio.pause();
  try { audio.currentTime = 0; } catch (e) {}

  isPlaying = true;
  isPaused = false;
  pausedAt = 0;
  currentAyahIndex = 0;
  ayahTransitionStart = Date.now();
  ayahDisplayStart = Date.now();
  audioEnded = false;
  audioStarted = false;
  playbackSpeed = 1.0;
  audio.playbackRate = playbackSpeed;
  document.getElementById('speedDisplay').textContent = '1.0x';

  // إجبار رسم الإطار الأول فوراً
  const firstAyah = currentAyahs[0];
  const surahName = document.getElementById('captionText').value ||
                   (fullSurahData ? fullSurahData.surahName : '') || '';
  drawFrameContent(firstAyah.text, surahName, firstAyah.numberInSurah, currentAyahs.length);

  updatePlayPauseUI();
  startPreviewLoop();
  startPlayerUiTimer();

  // بدء أول آية مباشرة من حدث المستخدم لتفادي حظر التشغيل التلقائي في المتصفح.
  if (isPlaying && !isPaused) playCurrentAyah();
}

// ============ مشغل الفيديو ============
function startPlayerUiTimer() {
  if (playerUiTimer !== null) return;
  updatePlayerTime();
  playerUiTimer = setInterval(updatePlayerTime, 250);
}

function stopPlayerUiTimer() {
  if (playerUiTimer !== null) {
    clearInterval(playerUiTimer);
    playerUiTimer = null;
  }
}

function updatePlayPauseUI() {
  // v6: أيقونات SVG تُبدَّل عبر data-state (CSS) بدل الإيموجي — مع تحديث aria-label.
  const btn = document.getElementById('playPauseBtn');
  if (!btn) return;
  const state = isPaused ? 'paused' : isPlaying ? 'playing' : 'idle';
  btn.dataset.state = state;
  btn.setAttribute('aria-label', state === 'playing' ? 'إيقاف المعاينة مؤقتاً' : 'تشغيل المعاينة');
}

function updatePlayerTime() {
  let cur = 0, total = 0;
  if (currentAyahs.length > 0) {
    for (let i = 0; i < currentAyahs.length; i++) {
      const dur = getAyahSyncDurationMs(currentAyahs[i]) / 1000;
      total += dur;
      if (i < currentAyahIndex) cur += dur;
    }
    if (isPlaying && currentAyahIndex < currentAyahs.length) {
      const currentDur = getAyahSyncDurationMs(currentAyahs[currentAyahIndex]) / 1000;
      const currentElapsed = Math.max(0, (Date.now() - ayahDisplayStart) / 1000);
      cur += Math.min(currentDur, currentElapsed);
    }
  }
  document.getElementById('currentTime').textContent = formatTime(cur);
  document.getElementById('totalTime').textContent = formatTime(total);
  const pct = total > 0 ? Math.min(100, Math.max(0, (cur / total) * 100)) : 0;
  const progressFill = document.getElementById('playerProgressFill');
  const progress = document.getElementById('playerProgress');
  if (progressFill) progressFill.style.width = pct + '%';
  if (progress) {
    progress.setAttribute('aria-valuenow', pct.toFixed(1));
    progress.setAttribute('aria-valuetext', currentAyahs.length ? `الآية ${currentAyahIndex + 1} من ${currentAyahs.length}` : 'بداية المعاينة');
  }
  const ayahBadge = document.getElementById('playerAyahBadge');
  if (ayahBadge) {
    const shortRiwayah = (fullSurahData?.riwayah || currentRiwayah) === 'warsh' ? 'ورش' : (currentAyahs.length ? 'حفص' : '');
    ayahBadge.textContent = currentAyahs.length ? `الآية ${currentAyahIndex + 1} / ${currentAyahs.length} • ${shortRiwayah}` : 'لا توجد آيات';
  }
  const status = document.getElementById('playerStatus');
  const statusDot = document.getElementById('playerStatusDot');
  if (status && statusDot) {
    status.textContent = finalExportInProgress ? 'جاري التصدير' : isPlaying && !isPaused ? 'تعمل المعاينة' : currentAyahs.length ? 'متوقفة مؤقتًا' : 'جاهز للمعاينة';
    statusDot.className = `player-status-dot${finalExportInProgress ? ' loading' : isPlaying && !isPaused ? ' active' : ''}`;
  }
  const timelineCurrent = document.getElementById('ayahTimelineCurrent');
  if (timelineCurrent && currentAyahs.length) {
    timelineCurrent.textContent = `الآية ${currentAyahs[currentAyahIndex]?.numberInSurah || '—'} من ${currentAyahs.length} • ${formatTime(cur)} / ${formatTime(total)}`;
  }
  const timelineTrack = document.getElementById('ayahTimelineTrack');
  if (timelineTrack) {
    timelineTrack.querySelectorAll('.ayah-timeline-segment').forEach((el, i) => {
      el.classList.toggle('active', i === currentAyahIndex);
      el.classList.toggle('played', i < currentAyahIndex);
    });
  }
}

// ============ التسجيل (3 أوضاع: full / video-only / audio-only) ============
// عند التصدير الصامت يُضبط true فيُقدَّم playCurrentAyah مؤقتاً دون صوت. var لتفادي TDZ.
var exportWithoutAudio = false;
async function startRecording() {
  if (!currentAyahs || currentAyahs.length === 0) {
    setStatus('⚠️ الرجاء جلب الآيات أولاً', 'error');
    return;
  }
  const exportMode = exportModes[currentExportMode] ? currentExportMode : 'full';
  const needsVideo = exportModes[exportMode]?.needsVideo !== false;
  const needsAudio = exportModes[exportMode]?.needsAudio !== false;
  const modeIcon = exportModes[exportMode]?.icon || '🎬';
  const modeName = exportModes[exportMode]?.name || exportMode;
  let combinedStream = null;
  let exportSpec = null;
  let supportedMime = null;
  try {
    // P0-1a: خط KFGQPC لازم فقط عند وجود صورة (الفيديو). الصوتي يتجاوزه.
    if (needsVideo) {
      try {
        if (typeof ensureQuranFontsLoaded === 'function') {
          const fontsOk = await ensureQuranFontsLoaded();
          if (!fontsOk) console.warn('تحذير التصدير: خط القرآن قد لا يكون مكتمل التحميل.');
        }
      } catch (e) {}
    }
    // محرك الصوت لازم فقط لوضعي full و audio-only — الفيديو الصامت يتجاوزه كلياً.
    if (needsAudio) {
      const { audioCtx: ac, audioDestNode: dest } = getAudioGraph();
      if (!ac || !dest) throw new Error('تعذر إنشاء مسار الصوت للتصدير.');
      if (ac.state === 'suspended') await ac.resume();
      if (ac.state !== 'running') throw new Error('محرك الصوت غير نشط؛ تعذر بدء التصدير الصوتي.');
    }

    exportSpec = getActiveExportSpec();
    const exportProfile = exportSpec.profile;
    if (needsVideo) setExportCanvasResolution(exportSpec.width, exportSpec.height);

    if (needsAudio) {
      if (audioSourceMode === 'reciter') {
        if (activeReciterAudioPreparation) {
          const ready = await activeReciterAudioPreparation;
          if (!ready) throw new Error('فحص الصوت لم يكتمل لجميع آيات النطاق.');
        }
        const missing = currentAyahs.find(a => !a.audioVerified || !a.audio);
        if (missing) throw new Error(`صوت الآية ${missing.numberInSurah} غير جاهز للتصدير.`);
        // P0-1b: فحص CORS — تحذير فقط، لا منع، مع توجيه للملف اليدوي عند الخطر.
        try {
          const cors = await checkReciterAudioCorsBeforeExport();
          const warnEl = document.getElementById('finalExportStatus');
          if (cors && cors.ok === false) {
            const msg = `⚠️ تنبيه CORS: خادم الصوت (${cors.host || 'المصدر الحالي'}) قد لا يسمح بالتقاط الصوت، وقد يخرج الفيديو صامتاً. للأضمن ارفع ملفاً صوتياً يدوياً. سيستمر التصدير الآن.`;
            if (warnEl) warnEl.textContent = msg;
            setStatus(msg, 'error');
            console.warn(msg);
          }
        } catch (e) {}
      } else if (!manualAudioUrl) {
        throw new Error('يجب رفع ملف صوتي يدوي قبل بدء التصدير.');
      }
    }

    let videoTracks = [];
    if (needsVideo) {
      const canvasStream = canvas.captureStream(exportSpec.fps);
      videoTracks = canvasStream.getVideoTracks();
      if (videoTracks.length !== 1) throw new Error('تعذر إنشاء مسار الفيديو للتصدير.');
    }

    // المصدر الأساسي للتصدير هو نفس عنصر <audio> الذي يسمعه المستخدم.
    // captureStream يتبع تبديل الآيات تلقائياً، لذلك لا يعتمد التسجيل على
    // MediaStreamDestination الذي قد ينتج مساراً صامتاً في بعض بيئات Chromium.
    let audioTracks = [];
    if (needsAudio) {
      const { audioDestNode: dest } = getAudioGraph();
      let audioCaptureStream = null;
      if (typeof audio.captureStream === 'function') {
        audioCaptureStream = audio.captureStream();
      } else if (typeof audio.mozCaptureStream === 'function') {
        audioCaptureStream = audio.mozCaptureStream();
      }
      audioTracks = audioCaptureStream ? audioCaptureStream.getAudioTracks() : [];

      // احتياطي Web Audio للمتصفحات التي لا تدعم captureStream.
      if (audioTracks.length !== 1) {
        audioTracks = dest.stream.getAudioTracks();
      }
      if (audioTracks.length !== 1) throw new Error('لم يتم إنشاء مسار صوت صالح للتسجيل.');
    }
    if (!videoTracks.length && !audioTracks.length) throw new Error('لا يوجد مسار للتصدير.');
    combinedStream = new MediaStream([...videoTracks, ...audioTracks]);

    let mimeCandidates;
    if (!needsVideo && needsAudio) {
      mimeCandidates = audioExportMimes;
    } else {
      mimeCandidates = Array.isArray(exportProfile.mime) ? exportProfile.mime : [];
    }
    supportedMime = mimeCandidates.find(m => window.MediaRecorder && MediaRecorder.isTypeSupported(m));
    // احتياط أخير للصوتي: أي صيغة يدعمها المتصفح.
    if (!supportedMime && !needsVideo && window.MediaRecorder) {
      const fallback = ['audio/webm;codecs=opus', 'audio/webm', 'audio/mp4', 'video/webm'];
      supportedMime = fallback.find(m => { try { return MediaRecorder.isTypeSupported(m); } catch (e) { return false; } });
    }
    if (!window.MediaRecorder || !supportedMime) throw new Error('متصفحك لا يدعم صيغة التصدير المطلوبة لهذا النوع.');

    recordedChunks = [];
    exportExpectedDurationMs = getTimelineTotalDurationMs();
    const bytesPerSec = (needsVideo ? exportSpec.videoMbps * 1000000 : 0) + (needsAudio ? exportSpec.audioKbps * 1000 : 0);
    exportExpectedBytes = Math.ceil((exportExpectedDurationMs / 1000) * bytesPerSec / 8);
    const recorderOptions = { mimeType: supportedMime };
    if (needsVideo) recorderOptions.videoBitsPerSecond = exportSpec.videoMbps * 1000000;
    if (needsAudio) recorderOptions.audioBitsPerSecond = exportSpec.audioKbps * 1000;
    try { mediaRecorder = new MediaRecorder(combinedStream, recorderOptions); }
    catch (_) { mediaRecorder = new MediaRecorder(combinedStream); }

    mediaRecorder.ondataavailable = e => { if (e.data && e.data.size > 0) recordedChunks.push(e.data); updateExportTelemetry(); };
    mediaRecorder.onerror = e => setStatus('❌ خطأ أثناء التسجيل: ' + (e.error ? e.error.message : 'غير معروف'), 'error');
    mediaRecorder.onstop = async () => {
      try {
        audio.pause();
        try { audio.muted = false; } catch (e) {}
        exportWithoutAudio = false;
        combinedStream?.getTracks().forEach(t => t.stop());
        if (!recordedChunks.length) throw new Error('لم يتم تسجيل أي بيانات.');
        const outputType = supportedMime.split(';')[0];
        const blob = new Blob(recordedChunks, { type: outputType });
        if (blob.size < 1024) throw new Error('ملف التصدير الناتج فارغ أو غير صالح.');
        const url = URL.createObjectURL(blob);
        const surahName = (fullSurahData ? fullSurahData.englishName : null) || document.getElementById('surahSelect').selectedOptions[0]?.textContent.split('(')[0].trim() || 'quran';
        const kind = !needsVideo ? 'audio' : 'video';
        const recPrefix = kind === 'audio' ? 'quran-audio' : 'quran-reel';
        const recName = `${recPrefix}-${surahName}-${Date.now()}`;
        const recordingId = Date.now();
        const extension = getRecordingExtension(outputType);
        const recording = { id:recordingId, name:recName, url, blob, size:blob.size, mime:outputType, extension, kind, exportMode, date:new Date().toLocaleString('ar-EG'), duration:Math.round(getTimelineTotalDurationMs() / 1000) + 's' };
        savedRecordings.unshift(recording);
        await saveRecordingToDatabase(recording);
        renderRecordings(); updateStats();
        const a = document.createElement('a'); a.href = url; a.download = `${recName}.${extension}`; document.body.appendChild(a); a.click(); a.remove();
        restoreExportCanvasResolution();
        if (finalExportInProgress) {
          finalExportInProgress = false;
          const progress = document.getElementById('finalExportProgress'); if (progress) progress.value = 100;
          const status = document.getElementById('finalExportStatus');
          if (status) {
            if (exportMode === 'audio-only') status.textContent = `✅ تم تصدير الملف الصوتي (${formatFileSize(blob.size)}) وتحميله على الجهاز.`;
            else if (exportMode === 'video-only') status.textContent = `✅ تم تصدير فيديو صامت بجودة ${exportSpec.width}×${exportSpec.height} وتحميله على الجهاز.`;
            else status.textContent = `✅ تم تصدير ${exportSpec.quality.label} بجودة ${exportSpec.width}×${exportSpec.height} مع الصوت وتحميله على الجهاز.`;
          }
          const btn = document.getElementById('finalExportBtn'); if (btn) { btn.disabled = false; btn.textContent = '🚀 تصدير'; }
        }
        const wasStopped = exportStoppedByUser;
        const doneMsg = exportMode === 'audio-only' ? '✅ تم حفظ الملف الصوتي بنجاح!' : exportMode === 'video-only' ? '✅ تم حفظ الفيديو الصامت بنجاح!' : '✅ تم حفظ الفيديو بالصوت بنجاح!';
        setStatus(wasStopped ? '⏹️ تم إيقاف التصدير وحفظ الجزء المسجل.' : doneMsg, wasStopped ? 'warning' : 'success');
        const finalStatus = document.getElementById('finalExportStatus');
        if (finalStatus && wasStopped) finalStatus.textContent = `⏹️ أوقف المستخدم التصدير. تم حفظ ملف جزئي بحجم ${formatFileSize(blob.size)}.`;
        resetExportTelemetry();
      } catch (e) {
        try { audio.muted = false; } catch (err) {}
        exportWithoutAudio = false;
        restoreExportCanvasResolution(); finalExportInProgress = false;
        const progress = document.getElementById('finalExportProgress'); if (progress) progress.value = 0;
        const status = document.getElementById('finalExportStatus'); if (status) status.textContent = '❌ ' + (e.message || e);
        const btn = document.getElementById('finalExportBtn'); if (btn) { btn.disabled = false; btn.textContent = '🚀 تصدير'; }
        resetExportTelemetry();
        setStatus('❌ فشل إنشاء ملف التصدير: ' + (e.message || e), 'error');
      }
    };

    mediaRecorder.start(250);
    exportStartedAt = Date.now();
    clearInterval(exportTelemetryTimer);
    exportTelemetryTimer = setInterval(updateExportTelemetry, 250);
    const stopExportBtn = document.getElementById('stopExportBtn');
    if (stopExportBtn) stopExportBtn.hidden = false;
    updateExportTelemetry();
    document.getElementById('fetchAyahsBtn').disabled = true;
    // الفيديو الصامت: كتم عنصر الصوت قبل بدء المعاينة حتى لا يُسمَع ما لن يُسجَّل.
    exportWithoutAudio = !needsAudio;
    if (!needsAudio) { try { audio.pause(); audio.muted = true; } catch (e) {} }
    startPreview();
    if (exportMode === 'audio-only') setStatus('🔴 جاري تسجيل الملف الصوتي...', 'loading');
    else if (exportMode === 'video-only') setStatus('🔴 جاري تسجيل الفيديو الصامت...', 'loading');
    else setStatus('🔴 جاري التسجيل النهائي بالصوت...', 'loading');
  } catch (e) {
    try { audio.muted = false; } catch (err) {}
    exportWithoutAudio = false;
    combinedStream?.getTracks().forEach(t => t.stop()); restoreExportCanvasResolution();
    finalExportInProgress = false;
    const progress = document.getElementById('finalExportProgress'); if (progress) progress.value = 0;
    const btn = document.getElementById('finalExportBtn'); if (btn) { btn.disabled = false; btn.textContent = '🚀 تصدير'; }
    const status = document.getElementById('finalExportStatus'); if (status) status.textContent = '❌ تعذر بدء التصدير: ' + (e.message || e);
    resetExportTelemetry();
    setStatus('❌ فشل بدء التسجيل: ' + (e.message || e), 'error');
  }
}

function stopRecording(byUser = true) {
  const recorderWasActive = !!(mediaRecorder && mediaRecorder.state !== 'inactive');
  if (recorderWasActive) {
    exportStoppedByUser = byUser;
    try { mediaRecorder.requestData?.(); } catch (e) {}
    mediaRecorder.stop();
  }
  // لا نوقف عنصر الصوت قبل طلب stop؛ captureStream يحتاج بضع لحظات لتفريغ آخر البيانات.
  if (!recorderWasActive) {
    audio.pause();
    try { audio.muted = false; } catch (e) {}
    exportWithoutAudio = false;
  }
  isPlaying = false;
  isPaused = false;
  stopPlayerUiTimer();
  if (!autoPreviewEnabled) stopPreviewLoop();
  clearAyahTimer();
  document.getElementById('fetchAyahsBtn').disabled = false;
  const stopExportBtn = document.getElementById('stopExportBtn');
  if (stopExportBtn) stopExportBtn.hidden = true;
  updatePlayPauseUI();
}

