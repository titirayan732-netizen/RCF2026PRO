// ============ جلب الآيات ============
async function fetchFullSurah() {
  const surahNum=document.getElementById('surahSelect').value;
  if(!surahNum){setStatus('⚠️ الرجاء اختيار سورة أولاً','error');return;}
  invalidateAsyncRequest('content'); invalidateAsyncRequest('audio');
  const request=beginAsyncRequest('content');
  const btn=document.getElementById('fetchAyahsBtn'),originalLabel=btn.textContent;
  const requestedRiwayah=document.getElementById('riwayahSelect').value||'hafs';
  const quranTextSource=getQuranTextSource(requestedRiwayah);
  if(!quranTextSource){setStatus(`❌ مصدر نص الرواية غير متوفر: ${requestedRiwayah}`,'error');return;}
  btn.disabled=true;btn.innerHTML='<span class="loader"></span> جاري جلب النص والرواية...';
  setStatus(`جاري جلب نص ${quranTextSource.label} بشكل مستقل عن المقرئ الصوتي...`,'loading');
  document.getElementById('fetchStatus').textContent=''; audio.pause(); try{audio.currentTime=0;}catch(e){} if(audioSourceMode==='reciter')audio.removeAttribute('src');
  fullSurahData=null;currentAyahs=[];currentRiwayah=requestedRiwayah;clearRiwayahTextCache(surahNum);
  try{
    if(!isAsyncRequestCurrent('content',request))throw new DOMException('تم إلغاء طلب قديم','AbortError');
    const res=await fetchWithTimeout(`https://api.alquran.cloud/v1/surah/${surahNum}/quran-uthmani`,{method:'GET',cache:'no-store',headers:{Accept:'application/json'},signal:request.signal});
    if(!res.ok)throw new Error('تعذر الاتصال بمصدر بيانات السورة ('+res.status+')');
    const data=await res.json(); if(!isAsyncRequestCurrent('content',request))throw new DOMException('تم إلغاء طلب قديم','AbortError');
    if(data.code!==200||!data.data||!Array.isArray(data.data.ayahs)||!data.data.ayahs.length)throw new Error('لم يتم العثور على بيانات السورة');
    fullSurahData={ayahs:data.data.ayahs,surahName:data.data.name,englishName:data.data.englishName,numberOfAyahs:data.data.numberOfAyahs||data.data.ayahs.length,textSource:quranTextSource.provider,textEdition:quranTextSource.edition};
    surahNumberCurrent=surahNum;translationKey=document.getElementById('translationSelect').value;tafsirEnabled=document.getElementById('tafsirToggle').checked;
    const tasks=[];
    if(translationKey)tasks.push(fetchTranslations(surahNum,translationKey,request));else{translationsData={};document.getElementById('translationStatus').textContent='';}
    if(tafsirEnabled)tasks.push(fetchTafsirMukhtasar(surahNum,request));else{tafsirData={};document.getElementById('tafsirStatus').textContent='';}
    tasks.push(fetchRiwayahText(surahNum,currentRiwayah,request)); await Promise.all(tasks);
    if(!isAsyncRequestCurrent('content',request))throw new DOMException('تم إلغاء طلب قديم','AbortError');
    const riwayahTexts=riwayahAyahsData[surahNum]; if(!riwayahTexts)throw new Error(`لم يتم تحميل نص رواية ${quranTextSource.label}، وتم إيقاف العملية منعاً لخلط الروايات.`);
    const mergedAyahs=fullSurahData.ayahs.map(ayah=>{const riwayahText=riwayahTexts[Number(ayah.numberInSurah)];if(!riwayahText)throw new Error(`نص الآية ${ayah.numberInSurah} غير موجود في رواية ${quranTextSource.label}.`);return {...ayah,text:riwayahText,riwayah:currentRiwayah};});
    if(mergedAyahs.length!==Number(fullSurahData.numberOfAyahs))throw new Error(`عدد الآيات بعد دمج الرواية غير مطابق: ${mergedAyahs.length} بدل ${fullSurahData.numberOfAyahs}`);
    fullSurahData.ayahs=mergedAyahs;fullSurahData.textProvider=quranTextSource.provider;fullSurahData.textEdition=quranTextSource.edition;fullSurahData.riwayah=currentRiwayah;
    const requestedRange=getRequestedAyahRange(),startInput=document.getElementById('startAyah'),endInput=document.getElementById('endAyah');
    startInput.min=1;startInput.max=fullSurahData.numberOfAyahs;endInput.min=1;endInput.max=fullSurahData.numberOfAyahs;
    if(requestedRange.enabled){startInput.value=requestedRange.start;endInput.value=requestedRange.end;}else{startInput.value=1;endInput.value=fullSurahData.numberOfAyahs;}
    startInput.disabled=!requestedRange.enabled;endInput.disabled=!requestedRange.enabled;if(!document.getElementById('captionText').value)document.getElementById('captionText').placeholder=fullSurahData.surahName;
    currentAyahs=requestedRange.enabled?fullSurahData.ayahs.slice(requestedRange.start-1,requestedRange.end):fullSurahData.ayahs.slice();
    document.getElementById('fetchStatus').textContent=requestedRange.enabled?`تم تحميل وعرض ${currentAyahs.length} آية فقط (من ${requestedRange.start} إلى ${requestedRange.end}) من "${fullSurahData.surahName}" — الكتابة برواية ${quranTextSource.label} ✅`:`تم تحميل ${currentAyahs.length} آية من "${fullSurahData.surahName}" — الكتابة برواية ${quranTextSource.label} ✅`;
    // شارة الرواية الثابتة: تبقى ظاهرة بجانب اختيار الرواية حتى يتحقق المستخدم من رسم الكتابة.
    const riwayahBadge = document.getElementById('riwayahStatus');
    if (riwayahBadge) { riwayahBadge.textContent = `📖 الكتابة المعروضة الآن: ${quranTextSource.label} — بخط ${getActiveQuranFontFamily()}`; riwayahBadge.style.color = '#7ed6a5'; }
    currentAyahIndex=0;ayahTransitionStart=Date.now();ayahDisplayStart=Date.now();renderAyahsList();updateStats();
    const audioReady = audioSourceMode === 'reciter' ? await prepareReciterAudio(false) : Boolean(manualAudioUrl);
    if(!isAsyncRequestCurrent('content',request))throw new DOMException('تم إلغاء طلب قديم','AbortError');
    if(audioSourceMode === 'upload' && !manualAudioUrl){
      setAudioStatus('⚠️ تم تحميل الآيات. ارفع ملفًا صوتيًا يدويًا قبل المعاينة أو التصدير.','warning');
      setStatus(`✅ تم تحميل نص ${quranTextSource.label} بنجاح. الصوت اليدوي مطلوب للمتابعة.`,'warning');
      return;
    }
    if(!audioReady){setStatus(`⚠️ تم تحميل نص ${quranTextSource.label} بنجاح، لكن لم يتم العثور على مصدر صوت مطابق. جرّب قارئًا آخر أو ارفع ملفًا صوتيًا يدويًا.`,'warning');return;}
    setStatus(`✅ جاهز! ${currentAyahs.length} آية من ${requestedRiwayah} — النص والصوت منفصلان ومتحقق منهما.`,'success');
  }catch(e){if(isAbortError(e)||!isAsyncRequestCurrent('content',request))return;fullSurahData=null;currentAyahs=[];clearRiwayahTextCache(surahNum);document.getElementById('fetchStatus').textContent='';setStatus('❌ تم إيقاف الجلب حفاظاً على سلامة الرواية: '+e.message,'error');}
  finally{if(isAsyncRequestCurrent('content',request)){asyncRequestState.content.controller=null;btn.disabled=false;btn.textContent=originalLabel;}}
}

function renderAyahsList() {
  const fontPanel = document.getElementById('fontControlsPanel');
  const transFontPanel = document.getElementById('transFontControlsPanel');
  const emptyState = document.getElementById('ayahsEmptyState');

  if (!currentAyahs || currentAyahs.length === 0) {
    if (fontPanel) fontPanel.style.display = 'none';
    if (transFontPanel) transFontPanel.style.display = 'none';
    if (emptyState) emptyState.style.display = 'block';
    return;
  }

  if (fontPanel) fontPanel.style.display = 'block';
  if (transFontPanel) transFontPanel.style.display = 'block';
  if (emptyState) emptyState.style.display = 'none';

  setTimeout(async () => {
    applyFontSettings();
    applyTransFontSettings();
    renderAyahTimeline();
    // P0-1a: انتظار خط KFGQPC قبل أول رسم حتى لا يُخبز fallback داخل Canvas.
    try {
      if (typeof ensureQuranFontsLoaded === 'function') await ensureQuranFontsLoaded();
    } catch (e) {}
    // رسم الإطار الأول عند تحميل الآيات
    if (currentAyahs.length > 0) {
      const firstAyah = currentAyahs[0];
      const surahName = document.getElementById('captionText').value || (fullSurahData ? fullSurahData.surahName : '') || '';
      drawFrameContent(firstAyah.text, surahName, firstAyah.numberInSurah, currentAyahs.length);
    }
  }, 30);
}

// ============ المرحلة 4: إدارة الخط الزمني للآيات ============
function formatAyahTimelineDuration(ms) {
  const seconds = Math.max(0, ms / 1000);
  return seconds < 60 ? `${seconds.toFixed(1)}ث` : `${Math.floor(seconds / 60)}:${String(Math.floor(seconds % 60)).padStart(2, '0')}`;
}

function selectAyahFromTimeline(index, autoPlay = false) {
  if (!currentAyahs.length || index < 0 || index >= currentAyahs.length) return;
  currentAyahIndex = index;
  ayahTransitionStart = Date.now();
  ayahDisplayStart = Date.now();
  audioEnded = false;
  updateAyahTimeline();
  const ayah = currentAyahs[currentAyahIndex];
  const surahName = document.getElementById('captionText').value || (fullSurahData ? fullSurahData.surahName : '') || '';
  drawFrameContent(ayah.text, surahName, ayah.numberInSurah, currentAyahs.length);
  
  // إذا كانت المعاينة التلقائية معطلة، نتأكد من رسم الإطار
  if (!previewLoopRunning) {
    setTimeout(() => drawCurrentFrame(), 50);
  }
  
  if (autoPlay || isPlaying) playCurrentAyah();
}

function updateAyahTimeline() {
  const list = document.getElementById('ayahTimelineList');
  const track = document.getElementById('ayahTimelineTrack');
  const current = document.getElementById('ayahTimelineCurrent');
  if (!list || !track || !current || !currentAyahs.length) return;
  const duration = getAyahSyncDurationMs(currentAyahs[currentAyahIndex]);
  list.querySelectorAll('.ayah-timeline-card').forEach((el, i) => el.classList.toggle('active', i === currentAyahIndex));
  track.querySelectorAll('.ayah-timeline-segment').forEach((el, i) => {
    el.classList.toggle('active', i === currentAyahIndex);
    el.classList.toggle('played', i < currentAyahIndex);
  });
  current.textContent = `الآية ${currentAyahIndex >= 0 ? currentAyahs[currentAyahIndex]?.numberInSurah || '—' : '—'} من ${currentAyahs.length}`;
  const active = list.querySelector('.ayah-timeline-card.active');
  if (active && active.scrollIntoView) active.scrollIntoView({behavior:'smooth', block:'nearest', inline:'center'});
}

function renderAyahTimeline() {
  const panel = document.getElementById('ayahTimelinePanel');
  const list = document.getElementById('ayahTimelineList');
  const track = document.getElementById('ayahTimelineTrack');
  const meta = document.getElementById('ayahTimelineMeta');
  if (!panel || !list || !track || !meta) return;
  if (!currentAyahs.length) {
    panel.style.display = 'none';
    list.innerHTML = ''; track.innerHTML = '';
    return;
  }
  panel.style.display = 'block';
  const totalDuration = getTimelineTotalDurationMs();
  const riwayahLabel = typeof getRiwayahDisplayLabel === 'function' ? getRiwayahDisplayLabel(fullSurahData?.riwayah || currentRiwayah) : (fullSurahData?.riwayah || currentRiwayah);
  meta.textContent = `${currentAyahs.length} آية • 📖 ${riwayahLabel} • ${formatAyahTimelineDuration(totalDuration)}`;
  list.innerHTML = currentAyahs.map((ayah, i) => {
    const audioOk = audioSourceMode === 'upload' ? Boolean(manualAudioUrl) : Boolean(ayah.audioVerified && ayah.audio);
    const label = audioOk ? '🔊' : (audioSourceMode === 'reciter' ? '⏳' : '🔇');
    // P2: تعقيم كامل عبر escapeHtml (كان يستبدل < > فقط ويترك & " ').
    const text = escapeHtml(ayah.text || '');
    return `<div class="ayah-timeline-card${i === currentAyahIndex ? ' active' : ''}" data-timeline-index="${i}" role="button" tabindex="0" aria-label="الانتقال إلى الآية ${ayah.numberInSurah}">
      <div class="ayah-timeline-card-top"><span class="ayah-timeline-number">آية ${ayah.numberInSurah}</span><span class="ayah-timeline-duration">${formatAyahTimelineDuration(getAyahSyncDurationMs(ayah))}</span></div>
      <div class="ayah-timeline-audio${audioOk ? '' : ' missing'}">${label} ${audioOk ? 'الصوت جاهز' : 'الصوت قيد التحقق'}</div>
      <div class="ayah-timeline-text">${text}</div>
    </div>`;
  }).join('');
  track.innerHTML = currentAyahs.map((ayah, i) => `<button class="ayah-timeline-segment${i === currentAyahIndex ? ' active' : ''}${i < currentAyahIndex ? ' played' : ''}" type="button" data-timeline-index="${i}" title="الآية ${ayah.numberInSurah}"></button>`).join('');
  list.querySelectorAll('[data-timeline-index]').forEach(el => {
    const go = () => selectAyahFromTimeline(Number(el.dataset.timelineIndex), false);
    el.addEventListener('click', go);
    el.addEventListener('keydown', e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); go(); } });
  });
  track.querySelectorAll('[data-timeline-index]').forEach(el => el.addEventListener('click', () => selectAyahFromTimeline(Number(el.dataset.timelineIndex), false)));
  updateAyahTimeline();
}

function initializeAyahTimeline() {
  document.getElementById('timelinePrevBtn')?.addEventListener('click', () => {
    if (currentAyahIndex > 0) selectAyahFromTimeline(currentAyahIndex - 1, isPlaying);
  });
  document.getElementById('timelineNextBtn')?.addEventListener('click', () => {
    if (currentAyahIndex < currentAyahs.length - 1) selectAyahFromTimeline(currentAyahIndex + 1, isPlaying);
  });
}

// ============ إحصائيات ============
function updateStats() {
  document.getElementById('statSurah').textContent = fullSurahData ? (fullSurahData.englishName || '—') : '—';
  document.getElementById('statAyahs').textContent = currentAyahs.length;
  // عرض ذكي: ثوانٍ للمدد القصيرة وmm:ss للطويلة (كانت تعرض "300s" المبهمة).
  const totalSec = getTimelineTotalDurationMs() / 1000;
  document.getElementById('statDuration').textContent = totalSec < 60 ? Math.round(totalSec) + 's' : formatTime(totalSec);
  document.getElementById('statRecordings').textContent = savedRecordings.length;
}

// ============ تجهيز النطاق ============
function prepareRange() {
  if (!fullSurahData) {
    setStatus('⚠️ الرجاء الضغط على "جلب الآيات" أولاً', 'error');
    return false;
  }

  const range = getRequestedAyahRange();
  const start = range.start;
  const end = range.end;

  // fullSurahData يحتفظ بكل السورة، وcurrentAyahs هو النطاق الذي سيظهر ويُسجّل فقط.
  // نحافظ على نتائج الفحص الصوتي الموجودة بدل إلغائها عند الضغط على التصدير.
  const previousAudioByAyah = new Map(
    (currentAyahs || []).map(a => [Number(a.numberInSurah), a]).filter(([n, a]) => Number.isInteger(n) && a)
  );
  currentAyahs = fullSurahData.ayahs.slice(start - 1, end).map(a => {
    const prev = previousAudioByAyah.get(Number(a.numberInSurah));
    if (prev?.audioVerified && prev?.audio) {
      return { ...a, audio: prev.audio, audioCandidates: prev.audioCandidates || [prev.audio], audioCandidateIndex: prev.audioCandidateIndex || 0, audioVerified: true, audioDurationMs: Number(prev.audioDurationMs) || 0 };
    }
    return { ...a, audioVerified: false, audio: null, audioCandidates: [], audioCandidateIndex: 0, audioDurationMs: 0 };
  });

  if (currentAyahs.length === 0) {
    setStatus('⚠️ نطاق الآيات غير صحيح', 'error');
    return false;
  }

  currentAyahIndex = 0;
  ayahTransitionStart = Date.now();
  ayahDisplayStart = Date.now();

  // لا نمسح نتائج التحقق الصوتي هنا.
  // fetchFullSurah() وprepareReciterAudio() يجهزان الصوت مسبقاً،
  // ومسح هذه النتائج عند تجهيز النطاق كان سبباً في ظهور:
  // "صوت الآية غير جاهز للتصدير" رغم نجاح الفحص السابق.
  // إذا تغيّر النطاق، prepareReciterAudio() سيعيد فحص الآيات المطلوبة فعلياً.

  renderAyahsList();
  updateStats();

  if (audioSourceMode === 'upload' && manualAudioUrl) {
    getManualAudioAyahDuration();
  }

  const firstAyah = currentAyahs[0];
  const surahName = document.getElementById('captionText').value ||
                   (fullSurahData ? fullSurahData.surahName : '') || '';
  drawFrameContent(firstAyah.text, surahName, firstAyah.numberInSurah, currentAyahs.length);
  
  // إذا كانت المعاينة التلقائية معطلة، نقوم برسم الإطار لضمان ظهور المحتوى
  if (!previewLoopRunning) {
    setTimeout(() => drawCurrentFrame(), 100);
  }

  setStatus(
    range.enabled
      ? `✅ جاهز لعرض ${currentAyahs.length} آية فقط (من ${start} إلى ${end})`
      : `✅ جاهز لعرض ${currentAyahs.length} آية`,
    'success'
  );
  return true;
}

