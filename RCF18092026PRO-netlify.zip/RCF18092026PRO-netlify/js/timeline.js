// ============ عرض التسجيلات (يدعم فيديو + صوتي) ============
let recordingsFilter = 'all';

function getRecordingKind(rec) {
  if (rec && rec.kind === 'audio') return 'audio';
  if (rec && rec.kind === 'video') return 'video';
  const mime = String(rec?.mime || '').toLowerCase();
  if (mime.startsWith('audio/')) return 'audio';
  return 'video';
}

function getRecordingKindLabel(rec) {
  const kind = getRecordingKind(rec);
  if (kind === 'audio') return '🎧 صوتي';
  const mode = rec?.exportMode;
  if (mode === 'video-only') return '🎥 فيديو صامت';
  return '🎬 فيديو كامل';
}

function getRecordingExtension(mime = '') {
  const type = String(mime).toLowerCase();
  if (type.includes('audio/mpeg') || type.includes('audio/mp3')) return 'mp3';
  if (type.includes('audio/mp4') || type.includes('audio/m4a')) return 'm4a';
  if (type.includes('audio/ogg') || type.includes('audio/opus')) return 'ogg';
  if (type.includes('audio/')) return 'webm';
  if (type.includes('mp4')) return 'mp4';
  if (type.includes('quicktime')) return 'mov';
  if (type.includes('ogg')) return 'ogv';
  return 'webm';
}

function formatRecordingsTotal(list) {
  if (!list.length) return 'لا توجد تسجيلات';
  const bytes = list.reduce((s, r) => s + (Number(r.size) || 0), 0);
  const mb = bytes < 1024 * 1024
    ? `${Math.max(0, bytes / 1024).toFixed(0)} KB`
    : `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  return `${list.length} تسجيل • ${mb}`;
}

function updateRecordingsToolbar() {
  const all = savedRecordings.length;
  const audio = savedRecordings.filter(r => getRecordingKind(r) === 'audio').length;
  const video = all - audio;
  const set = (id, v) => { const el = document.getElementById(id); if (el) el.textContent = String(v); };
  set('recCountAll', all);
  set('recCountVideo', video);
  set('recCountAudio', audio);
  const info = document.getElementById('recordingsTotalInfo');
  if (info) info.textContent = formatRecordingsTotal(savedRecordings);
  document.querySelectorAll('[data-rec-filter]').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.recFilter === recordingsFilter);
  });
  const clearBtn = document.getElementById('clearAllRecordingsBtn');
  if (clearBtn) clearBtn.disabled = all === 0;
}

function renderRecordings() {
  updateRecordingsToolbar();
  const container = document.getElementById('recordingsContainer');
  if (!container) return;
  const visible = recordingsFilter === 'all'
    ? savedRecordings
    : savedRecordings.filter(r => getRecordingKind(r) === recordingsFilter);
  if (savedRecordings.length === 0) {
    container.innerHTML = `
      <div class="empty-state">
        <div class="empty-icon">🎬</div>
        <div>لا توجد تسجيلات بعد</div>
        <div style="font-size: 0.8rem; margin-top: 5px;">اختر نوع التصدير ثم اضغط «تصدير» ليظهر هنا</div>
      </div>`;
    return;
  }
  if (visible.length === 0) {
    container.innerHTML = `
      <div class="empty-state">
        <div class="empty-icon">🔍</div>
        <div>لا توجد تسجيلات من هذا النوع</div>
        <div style="font-size: 0.8rem; margin-top: 5px;">جرّب فلتراً آخر</div>
      </div>`;
    return;
  }
  let html = '<div class="recordings-grid">';
  visible.forEach(rec => {
    const sizeMB = ((Number(rec.size) || 0) / (1024 * 1024)).toFixed(1);
    const safeName = escapeHtml(rec.name);
    const kind = getRecordingKind(rec);
    const kindLabel = getRecordingKindLabel(rec);
    const player = kind === 'audio'
      ? `<audio src="${rec.url}" controls preload="metadata" style="width:100%;margin-bottom:8px;"></audio>`
      : `<video src="${rec.url}" controls preload="metadata" playsinline webkit-playsinline></video>`;
    html += `
      <div class="recording-card recording-kind-${kind}">
        ${player}
        <div class="rec-kind-badge">${kindLabel}</div>
        <div class="rec-name" title="${safeName}">${safeName}</div>
        <div class="rec-meta">${escapeHtml(rec.duration || '')} • ${sizeMB}MB</div>
        <div class="recording-actions">
          <button class="rec-download" data-id="${rec.id}">⬇️ تحميل</button>
          <button class="rec-delete" data-id="${rec.id}">🗑️ حذف</button>
        </div>
      </div>`;
  });
  html += '</div>';
  container.innerHTML = html;

  // قراءة المدة الفعلية من الوسم نفسه (فيديو أو صوت).
  container.querySelectorAll('video, audio').forEach((media) => {
    media.addEventListener('loadedmetadata', () => {
      const card = media.closest('.recording-card');
      const id = Number(card?.querySelector('.rec-download')?.dataset.id);
      const rec = savedRecordings.find(r => r.id === id);
      if (rec && media.duration && isFinite(media.duration)) {
        const actualDur = formatTime(media.duration);
        const metaEl = card?.querySelector('.rec-meta');
        if (metaEl && actualDur !== '00:00') {
          const sizeMB = ((Number(rec.size) || 0) / (1024 * 1024)).toFixed(1);
          metaEl.textContent = `${actualDur} • ${sizeMB}MB`;
        }
      }
    });
    media.addEventListener('error', (e) => {
      console.warn('خطأ في تحميل التسجيل:', e);
    });
  });

  container.querySelectorAll('.rec-download').forEach(btn => {
    btn.addEventListener('click', () => {
      const rec = savedRecordings.find(r => r.id === parseInt(btn.dataset.id));
      if (rec) {
        const a = document.createElement('a');
        a.href = rec.url;
        a.download = `${rec.name}.${rec.extension || getRecordingExtension(rec.mime)}`;
        document.body.appendChild(a);
        a.click();
        a.remove();
      }
    });
  });

  container.querySelectorAll('.rec-delete').forEach(btn => {
    btn.addEventListener('click', () => {
      const id = parseInt(btn.dataset.id);
      const rec = savedRecordings.find(r => r.id === id);
      if (rec) URL.revokeObjectURL(rec.url);
      savedRecordings = savedRecordings.filter(r => r.id !== id);
      deleteRecordingFromDatabase(id);
      renderRecordings();
      updateStats();
    });
  });
}

function initializeRecordingsToolbar() {
  document.querySelectorAll('[data-rec-filter]').forEach(btn => {
    btn.addEventListener('click', () => {
      recordingsFilter = btn.dataset.recFilter || 'all';
      renderRecordings();
    });
  });
  document.getElementById('clearAllRecordingsBtn')?.addEventListener('click', async () => {
    if (!savedRecordings.length) return;
    if (!confirm(`هل تريد حذف جميع التسجيلات (${savedRecordings.length}) نهائياً من هذا الجهاز؟`)) return;
    const ids = savedRecordings.map(r => r.id);
    savedRecordings.forEach(rec => { try { if (rec.url) URL.revokeObjectURL(rec.url); } catch (e) {} });
    savedRecordings = [];
    for (const id of ids) {
      try { await deleteRecordingFromDatabase(id); } catch (e) {}
    }
    renderRecordings();
    updateStats();
    setStatus('🗑️ تم حذف جميع التسجيلات.', 'success');
  });
}
