// ============ البدء ============
// فحص سلامة الإقلاع: يكشف خلط نسخ قديمة/جديدة من الكاش (ملف ميت = دوال ناقصة)
// ويعرض رسالة عربية واضحة بدل أخطاء TDZ الغامضة، مع محاولة تحديث الـ SW.
const __bootIssues = [];
function __bootStep(label, fn) {
  try {
    if (typeof fn === 'function') { fn(); return true; }
    __bootIssues.push(label);
  } catch (e) {
    console.error('Boot step failed:', label, e);
    __bootIssues.push(label);
  }
  return false;
}
function __reportBootIssues() {
  if (!__bootIssues.length) return;
  const bar = document.getElementById('statusBar');
  const msg = '⚠️ تم تحميل نسخة غير مكتملة (ملفات قديمة مخزنة). حدّث الصفحة بقوة Ctrl+Shift+R، أو امسح بيانات الموقع وأعد الفتح.';
  if (bar) { bar.textContent = msg; bar.className = 'status-bar error'; }
  console.warn('Missing/broken modules:', __bootIssues);
  try {
    if ('serviceWorker' in navigator) navigator.serviceWorker.getRegistrations().then(rs => rs.forEach(r => { try { r.update(); } catch (e) {} })).catch(() => {});
  } catch (e) {}
}
function __needFn(name) {
  try { return typeof globalThis[name] === 'function'; } catch (e) { return false; }
}
const finalExportQualitySelect = document.getElementById('finalExportQualitySelect');
if (finalExportQualitySelect) finalExportQualitySelect.addEventListener('change', e => { try { applyExportQuality(e.target.value); } catch (err) { __bootIssues.push('applyExportQuality'); __reportBootIssues(); } });
const videoFormatSelect = document.getElementById('videoFormatSelect');
if (videoFormatSelect) {
	__bootStep('videoFormatSelect.init', () => { videoFormatSelect.value = currentVideoFormat; });
	videoFormatSelect.addEventListener('change', e => { try { applyVideoFormat(e.target.value); } catch (err) { __bootIssues.push('applyVideoFormat'); __reportBootIssues(); } });
}
const finalExportBtn = document.getElementById('finalExportBtn');
if (finalExportBtn) finalExportBtn.addEventListener('click', () => {
  if (__needFn('startFinalExport')) startFinalExport();
  else { __bootIssues.push('startFinalExport'); __reportBootIssues(); }
});
let exportCapability = { supported: true, missing: [] };
__bootStep('getExportCapabilityReport', () => {
  if (!__needFn('getExportCapabilityReport')) throw new Error('missing module');
  exportCapability = getExportCapabilityReport();
});
if (!exportCapability.supported && finalExportBtn) {
	finalExportBtn.disabled = true;
	finalExportBtn.title = `التصدير غير متاح: ${exportCapability.missing.join('، ')}`;
	const exportStatus = document.getElementById('finalExportStatus');
	if (exportStatus) exportStatus.textContent = `⚠️ التصدير غير متاح في هذا المتصفح. المكونات الناقصة: ${exportCapability.missing.join('، ')}`;
}
__bootStep('updateExportPreview', () => updateExportPreview(currentExportProfile));
__bootStep('updateFinalExportSpec', () => updateFinalExportSpec());

__bootStep('initParticles', () => initParticles());
__bootStep('refreshReciterOptions', () => refreshReciterOptions());
__bootStep('refreshFontFamilyOptions', () => refreshFontFamilyOptions());
// P0-1a: تحميل مبكر لخط المصحف في الخلفية حتى يكون جاهزاً قبل أول رسم/تصدير.
__bootStep('preloadActiveQuranFont', () => { if (typeof preloadActiveQuranFont === 'function') preloadActiveQuranFont(); });
__bootStep('ensureQuranFontsLoaded', () => { if (typeof ensureQuranFontsLoaded === 'function') ensureQuranFontsLoaded().catch(() => {}); });
__bootStep('buildPresets', () => buildPresets());
__bootStep('initializePresetEvents', () => initializePresetEvents());
// مزامنة واجهة نوع التصدير مع الحالة (تحل محل قالب المنصة المحذوف).
__bootStep('applyExportMode', () => {
  const modeSelect = document.getElementById('exportModeSelect');
  if (modeSelect && typeof applyExportMode === 'function') applyExportMode(currentExportMode);
  else if (modeSelect) modeSelect.value = currentExportMode;
});
__bootStep('initializeRecordingsToolbar', () => { if (typeof initializeRecordingsToolbar === 'function') initializeRecordingsToolbar(); });
__bootStep('renderRecordings', () => renderRecordings());
__bootStep('updateStats', () => updateStats());
__bootStep('loadRecordingsFromDatabase', () => loadRecordingsFromDatabase());
// لا نشغّل حلقة Canvas عند تحميل الصفحة؛ الإطار الثابت يُرسم عند الحاجة فقط.
__bootStep('syncAyahRangeControls', () => syncAyahRangeControls());
__bootStep('loadSurahs', () => loadSurahs());
__reportBootIssues();

// P3: تسجيل Service Worker (خارجي CSP-safe) لتشغيل App Shell دون اتصال مع صفحة offline.
try {
  if ('serviceWorker' in navigator && (location.protocol === 'https:' || location.hostname === 'localhost' || location.hostname === '127.0.0.1')) {
    window.addEventListener('load', () => {
      navigator.serviceWorker.register('./sw.js').catch(err => console.warn('تعذر تسجيل SW:', err?.message || err));
    });
  }
} catch (e) {}
