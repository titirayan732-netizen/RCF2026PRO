// ============ Canvas rendering ============
const animatedBGs = Array.from({ length: 8 }, (_, index) => ({
	name: `خلفية ${index + 1}`,
	draw: time => drawAnimatedBackground(index, time)
}));

const islamicFrames = [null, ...Array.from({ length: 7 }, (_, index) => ({
	name: `إطار ${index + 1}`,
	draw: (context, width, height) => drawFrameBorder(context, width, height, index + 1)
}))];

const presetBackgroundThemes = {
	'classic-gold': { colors:['#050b13','#1a3a52','#d4af37'], motion:'orbits', depth:1 },
	'emerald-mihrab': { colors:['#00241f','#00695c','#ffd700'], motion:'rays', depth:2 },
	'arabesque-night': { colors:['#2b0d22','#8e2f67','#ff7eb6'], motion:'nebula', depth:3 },
	'minimal-white': { colors:['#17202a','#52616b','#ffffff'], motion:'soft', depth:4 },
	'soft-dawn': { colors:['#301d1a','#8d6e63','#f4e5a1'], motion:'horizon', depth:5 },
	'cinema': { colors:['#050509','#25254a','#d4af37'], motion:'cinema', depth:6 },
	'teal-water': { colors:['#3b0d05','#c2410c','#ff9f43'], motion:'fire', depth:7 },
	'cosmic-modern': { colors:['#100522','#4a148c','#d4af37'], motion:'nebula', depth:8 },
	'royal-fire': { colors:['#240505','#7a2610','#ffcc80'], motion:'embers', depth:9 },
	'modern-ocean': { colors:['#002d3a','#00acc1','#9ad8ff'], motion:'waves', depth:10 }
};
const textLayoutCache = new Map();
const TEXT_LAYOUT_CACHE_LIMIT = 240;
if (document.fonts?.ready) document.fonts.ready.then(() => textLayoutCache.clear());

function initParticles() {
	particles = Array.from({ length: 50 }, () => ({
		x: Math.random(),
		y: Math.random(),
		r: Math.random() * 2 + 1,
		vx: (Math.random() - 0.5) * 0.3,
		vy: (Math.random() - 0.5) * 0.3,
		alpha: Math.random() * 0.5 + 0.2
	}));
}

// P2: حُذفت easeOutCubic الميتة (لا استخدام لها في أي تأثير حالي).
function drawAnimatedBackground(index, time) {
	const palettes = [
		['#0a1929', '#1a3a52'], ['#160d2d', '#4a148c'], ['#003b36', '#00695c'],
		['#3e2723', '#8d6e63'], ['#080816', '#25254a'], ['#001a1a', '#003333'],
		['#004d5e', '#00acc1'], ['#260808', '#7a2610']
	];
	const palette = palettes[index % palettes.length];
	const gradient = ctx.createLinearGradient(0, 0, canvas.width, canvas.height);
	gradient.addColorStop(0, palette[0]);
	gradient.addColorStop(0.5, palette[1]);
	gradient.addColorStop(1, palette[0]);
	ctx.fillStyle = gradient;
	ctx.fillRect(0, 0, canvas.width, canvas.height);
	const glow = ctx.createRadialGradient(
		canvas.width * (0.25 + Math.sin(time * 0.2) * 0.08),
		canvas.height * (0.28 + Math.cos(time * 0.18) * 0.08), 0,
		canvas.width * 0.35, canvas.height * 0.35, canvas.width * 0.7
	);
	glow.addColorStop(0, 'rgba(212,175,55,.18)');
	glow.addColorStop(1, 'rgba(212,175,55,0)');
	ctx.fillStyle = glow;
	ctx.fillRect(0, 0, canvas.width, canvas.height);
}

function drawPresetDynamicBackground(theme, time) {
	time *= Math.max(0.1, Math.min(3, Number(dynamicBackgroundSpeed) || 1));
	const [first, second, accent] = theme.colors;
	const width = canvas.width;
	const height = canvas.height;
	const gradient = ctx.createLinearGradient(0, 0, width, height);
	gradient.addColorStop(0, first); gradient.addColorStop(.55, second); gradient.addColorStop(1, first);
	ctx.fillStyle = gradient;
	ctx.fillRect(0, 0, width, height);
	drawPresetDepthLayer(theme, time);
	ctx.save();
	ctx.globalCompositeOperation = 'screen';
	const orbitCount = theme.motion === 'fire' ? 4 : 2;
	for (let index = 0; index < orbitCount; index++) {
		const phase = time * (.18 + index * .05) + index * 2.1;
		const x = width * (.5 + Math.sin(phase) * (.22 + index * .06));
		const y = height * (.38 + Math.cos(phase * .8) * (.2 + index * .04));
		const radius = Math.min(width, height) * (.22 + index * .035);
		const glow = ctx.createRadialGradient(x, y, 0, x, y, radius);
		glow.addColorStop(0, `${accent}55`);
		glow.addColorStop(1, `${accent}00`);
		ctx.fillStyle = glow;
		ctx.fillRect(0, 0, width, height);
	}
	if (theme.motion === 'waves' || theme.motion === 'rays') {
		ctx.strokeStyle = `${accent}55`;
		ctx.lineWidth = Math.max(2, width / 420);
		for (let line = 0; line < 7; line++) {
			ctx.beginPath();
			for (let x = -20; x <= width + 20; x += Math.max(16, width / 32)) {
				const y = height * (.2 + line * .12) + Math.sin(x / width * 8 + time * (theme.motion === 'rays' ? .7 : .35) + line) * height * .025;
				if (x === -20) ctx.moveTo(x, y); else ctx.lineTo(x, y);
			}
			ctx.stroke();
		}
	}
	if (theme.motion === 'stars' || theme.motion === 'nebula') {
		ctx.fillStyle = `${accent}aa`;
		for (let star = 0; star < 16; star++) {
			const x = (Math.sin(star * 41.7 + time * .08) * .5 + .5) * width;
			const y = (Math.cos(star * 17.3 + time * .06) * .5 + .5) * height;
			const radius = 1 + (star % 3);
			ctx.beginPath(); ctx.arc(x, y, radius, 0, Math.PI * 2); ctx.fill();
		}
	}
	if (theme.motion === 'arrows') {
		ctx.strokeStyle = `${accent}cc`;
		ctx.fillStyle = `${accent}cc`;
		ctx.lineWidth = Math.max(2, width / 360);
		for (let arrow = 0; arrow < 9; arrow++) {
			const progress = (time * (.18 + arrow * .012) + arrow / 9) % 1;
			const x = width * (-.12 + progress * 1.24);
			const y = height * (.16 + ((arrow * .097) % .7)) + Math.sin(time * .8 + arrow) * height * .025;
			const length = width * (.12 + (arrow % 3) * .025);
			ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x + length, y - length * .08); ctx.stroke();
			ctx.beginPath(); ctx.moveTo(x + length, y - length * .08); ctx.lineTo(x + length - length * .045, y - length * .16); ctx.lineTo(x + length - length * .035, y); ctx.closePath(); ctx.fill();
		}
	}
	if (theme.motion === 'fire' || theme.motion === 'cinema') {
		const vignette = ctx.createRadialGradient(width / 2, height * .35, 0, width / 2, height * .35, height * .72);
		vignette.addColorStop(0, `${accent}33`); vignette.addColorStop(1, `${accent}00`);
		ctx.fillStyle = vignette; ctx.fillRect(0, 0, width, height);
	}
	ctx.restore();
}

function drawPresetDepthLayer(theme, time) {
	const width = canvas.width;
	const height = canvas.height;
	const [first, second, accent] = theme.colors;
	const scale = Math.min(width, height);
	ctx.save();
	ctx.globalCompositeOperation = 'screen';
	ctx.lineWidth = Math.max(1.5, scale / 520);

	if (theme.motion === 'orbits') {
		for (let sphere = 0; sphere < 4; sphere++) {
			const phase = time * (.22 + sphere * .04) + sphere * 1.7;
			const x = width * (.5 + Math.cos(phase) * (.18 + sphere * .035));
			const y = height * (.34 + Math.sin(phase * .8) * (.15 + sphere * .025));
			const radius = scale * (.08 + sphere * .018);
			const glow = ctx.createRadialGradient(x - radius * .35, y - radius * .4, radius * .08, x, y, radius);
			glow.addColorStop(0, `${accent}cc`); glow.addColorStop(.45, `${accent}44`); glow.addColorStop(1, `${accent}00`);
			ctx.fillStyle = glow; ctx.beginPath(); ctx.arc(x, y, radius, 0, Math.PI * 2); ctx.fill();
			ctx.strokeStyle = `${accent}66`; ctx.beginPath(); ctx.ellipse(x, y, radius * 1.8, radius * .55, phase, 0, Math.PI * 2); ctx.stroke();
		}
	} else if (theme.motion === 'rays') {
		const vanishingX = width * .5;
		const vanishingY = height * .28;
		ctx.strokeStyle = `${accent}55`;
		for (let ray = -8; ray <= 8; ray++) { ctx.beginPath(); ctx.moveTo(vanishingX, vanishingY); ctx.lineTo(width * (.5 + ray * .12), height); ctx.stroke(); }
		for (let row = 0; row < 8; row++) {
			const depth = ((row / 8 + time * .035) % 1);
			const y = vanishingY + Math.pow(depth, 1.8) * (height - vanishingY);
			ctx.globalAlpha = .2 + depth * .45; ctx.beginPath(); ctx.ellipse(vanishingX, y, width * depth * .68, height * depth * .035, 0, 0, Math.PI * 2); ctx.stroke();
		}
	} else if (theme.motion === 'arrows') {
		ctx.strokeStyle = `${accent}88`; ctx.fillStyle = `${accent}66`;
		for (let item = 0; item < 12; item++) {
			const depth = (item / 12 + time * (.045 + item * .002)) % 1;
			const size = scale * (.018 + depth * .07);
			const x = width * (.5 + Math.sin(item * 2.4 + time * .22) * (.12 + depth * .3));
			const y = height * (.22 + depth * .7);
			ctx.globalAlpha = .18 + depth * .55; ctx.beginPath(); ctx.moveTo(x, y - size); ctx.lineTo(x + size, y); ctx.lineTo(x, y + size); ctx.lineTo(x - size, y); ctx.closePath(); ctx.stroke(); ctx.fill();
		}
	} else if (theme.motion === 'soft') {
		for (let plane = 0; plane < 5; plane++) {
			const phase = time * (.12 + plane * .02) + plane;
			const x = width * (.5 + Math.sin(phase) * .32);
			const y = height * (.25 + plane * .13 + Math.cos(phase * .7) * .04);
			const glow = ctx.createRadialGradient(x, y, 0, x, y, scale * (.18 + plane * .02));
			glow.addColorStop(0, `${accent}28`); glow.addColorStop(1, `${accent}00`); ctx.fillStyle = glow; ctx.fillRect(0, 0, width, height);
		}
	} else if (theme.motion === 'horizon') {
		const horizon = height * .58;
		const sunX = width * (.5 + Math.sin(time * .08) * .18);
		const sunY = horizon - height * (.16 + Math.sin(time * .12) * .015);
		const sun = ctx.createRadialGradient(sunX, sunY, 0, sunX, sunY, scale * .2);
		sun.addColorStop(0, `${accent}bb`); sun.addColorStop(1, `${accent}00`); ctx.fillStyle = sun; ctx.fillRect(0, 0, width, height);
		ctx.strokeStyle = `${accent}66`;
		for (let wave = 0; wave < 8; wave++) { ctx.beginPath(); for (let x = 0; x <= width; x += Math.max(14, width / 34)) { const y = horizon + wave * height * .045 + Math.sin(x / width * 9 + time * .35 + wave) * height * .018; x ? ctx.lineTo(x, y) : ctx.moveTo(x, y); } ctx.stroke(); }
	} else if (theme.motion === 'cinema') {
		ctx.strokeStyle = `${accent}2e`;
		for (let line = -2; line < 12; line++) { const y = ((line * height * .11 + time * height * .025) % (height * 1.2)) - height * .1; ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(width, y + width * .18); ctx.stroke(); }
		ctx.fillStyle = `${accent}18`; ctx.fillRect(0, height * .43, width, height * .16);
	} else if (theme.motion === 'fire') {
		for (let flame = 0; flame < 38; flame++) { const progress = (flame / 38 + time * (.05 + (flame % 4) * .008)) % 1; const x = width * (.12 + ((flame * 37) % 76) / 100) + Math.sin(time * 1.4 + flame) * width * .025; const y = height * (1.05 - progress * .9); const radius = scale * (.006 + progress * .018); ctx.globalAlpha = .1 + progress * .45; ctx.fillStyle = flame % 3 ? `${accent}aa` : `${first}aa`; ctx.beginPath(); ctx.arc(x, y, radius, 0, Math.PI * 2); ctx.fill(); }
	} else if (theme.motion === 'embers') {
		ctx.strokeStyle = `${accent}77`;
		for (let ember = 0; ember < 18; ember++) {
			const phase = time * (.16 + ember * .006) + ember;
			const radius = scale * (.12 + (ember % 5) * .055);
			const x = width * .5 + Math.cos(phase) * radius;
			const y = height * (.72 - ((time * (.025 + ember * .001) + ember / 18) % 1) * .58);
			const size = scale * (.004 + (ember % 4) * .002);
			ctx.globalAlpha = .18 + (ember % 5) * .1;
			ctx.beginPath(); ctx.arc(x, y, size, 0, Math.PI * 2); ctx.stroke();
			ctx.beginPath(); ctx.moveTo(x - size * 4, y); ctx.lineTo(x + size * 7, y - size * 2); ctx.stroke();
		}
	} else if (theme.motion === 'nebula') {
		for (let star = 0; star < 30; star++) { const depth = (star / 30 + time * .018) % 1; const angle = star * 2.7 + time * (.08 + depth * .12); const radius = scale * (.06 + depth * .48); const x = width * .5 + Math.cos(angle) * radius; const y = height * .42 + Math.sin(angle) * radius; ctx.globalAlpha = .12 + depth * .7; ctx.fillStyle = `${accent}cc`; ctx.beginPath(); ctx.arc(x, y, scale * (.002 + depth * .006), 0, Math.PI * 2); ctx.fill(); }
	} else if (theme.motion === 'waves') {
		const horizon = height * .34;
		ctx.strokeStyle = `${accent}66`;
		for (let row = 0; row < 12; row++) { const depth = row / 12; const y = horizon + Math.pow(depth, 1.45) * height * .72 + Math.sin(time * .3 + row) * height * .006; ctx.globalAlpha = .18 + depth * .42; ctx.beginPath(); for (let x = 0; x <= width; x += Math.max(14, width / 30)) { const waveY = y + Math.sin(x / width * 10 + time * .55 + row * .7) * height * (.008 + depth * .018); x ? ctx.lineTo(x, waveY) : ctx.moveTo(x, waveY); } ctx.stroke(); }
	}
	ctx.restore();
}

function drawFrameBorder(context, width, height, variant) {
	context.save();
	context.strokeStyle = frameColor;
	context.globalAlpha = Math.max(0.2, frameOpacity);
	context.lineWidth = Math.max(2, variant * 0.8 + 1);
	const inset = 18 + variant * 4;
	context.strokeRect(inset, inset, width - inset * 2, height - inset * 2);
	context.restore();
}

function drawRoundedRect(context, x, y, width, height, radius) {
	const r = Math.min(radius, width / 2, height / 2);
	context.beginPath();
	context.moveTo(x + r, y);
	context.arcTo(x + width, y, x + width, y + height, r);
	context.arcTo(x + width, y + height, x, y + height, r);
	context.arcTo(x, y + height, x, y, r);
	context.arcTo(x, y, x + width, y, r);
	context.closePath();
}

function getWrappedLines(context, text, maxWidth) {
	const words = String(text || '').split(/\s+/);
	const lines = [];
	let line = '';
	words.forEach(word => {
		const candidate = line ? `${line} ${word}` : word;
		if (line && context.measureText(candidate).width > maxWidth) {
			lines.push(line);
			line = word;
		} else line = candidate;
	});
	if (line) lines.push(line);
	return lines.length ? lines : [''];
}

function applyQuranTextEffect(effect, intensity = 1) {
	ctx.shadowColor = 'transparent';
	ctx.shadowBlur = 0;
	ctx.shadowOffsetX = 0;
	ctx.shadowOffsetY = 0;
	if (glowEnabled && (effect === 'glow' || effect === 'neon')) {
		ctx.shadowColor = `rgba(212,175,55,${Math.min(1, 0.7 * intensity)})`;
		ctx.shadowBlur = 14 * intensity;
	} else if (effect === 'shadow') {
		ctx.shadowColor = 'rgba(0,0,0,.75)';
		ctx.shadowBlur = 8 * intensity;
		ctx.shadowOffsetY = 3 * intensity;
	}
}

function clamp01(value) { return Math.max(0, Math.min(1, Number(value) || 0)); }

function getEffectProgress(start = ayahTransitionStart, duration = effectAnimationDuration, now = Date.now()) {
	if (duration <= 0) return 1;
	return clamp01((now - start) / duration);
}

function renderEffect(context, { target = 'ayah', effect = 'fade', intensity = 1, progress = 1, text = '' } = {}) {
	const p = clamp01(progress);
	const strength = Math.max(.1, Number(intensity) || 1);
	const result = { text, alpha:1, x:0, y:0, scale:1, scaleX:1, scaleY:1, rotation:0, filter:'none' };
	const distance = Math.min(80, 28 * strength);
	// v17: الزمن المنقضي منذ بداية الآية — يحرك التأثيرات المستمرة (فيديو حي) بعد اكتمال الدخول.
	let elapsed = 0;
	try { elapsed = Math.max(0, (Date.now() - ayahTransitionStart) / 1000); } catch (e) { elapsed = 0; }
	// v17: احترام تقليل الحركة — تُجمَّد الحركات المستمرة ويبقى تلاشي هادئ.
	let reduceMotion = false;
	try { reduceMotion = Boolean(document?.body?.classList?.contains('reduce-motion')); } catch (e) {}
	if (effect === 'fade') result.alpha = p;
	if (effect === 'slideUp' || effect === 'slideFade') { result.y = (1 - p) * distance; if (effect === 'slideFade') result.alpha = p; }
	if (effect === 'slideSide') { result.x = (1 - p) * distance; result.alpha = p; }
	if (effect === 'zoom' || effect === 'scaleIn') { result.scale = effect === 'zoom' ? .86 + p * .14 : .72 + p * .28; result.alpha = p; }
	if (effect === 'rotate') { result.rotation = (1 - p) * .12 * strength; result.alpha = p; }
	if (effect === 'bounce') { result.y = Math.sin((1 - p) * Math.PI * 2.5) * distance * (1 - p); result.alpha = p; }
	if (effect === 'blurIn') { result.alpha = p; result.filter = `blur(${Math.round((1 - p) * 8 * strength)}px)`; }
	if (effect === 'typewriter') {
		const units = splitGraphemes(text);
		result.text = units.slice(0, Math.max(1, Math.ceil(units.length * p))).join('');
	}
	if (effect === 'shake') { result.x = (Math.random() - .5) * 5 * strength; result.y = (Math.random() - .5) * 5 * strength; }
	// v13: ثلاثة تأثيرات جديدة — صعود سينمائي، تقليب بطاقي، تأرجح دخول (حتمية، آمنة للتصدير).
	if (effect === 'rise') {
		const e = 1 - Math.pow(1 - p, 3);
		result.y = (1 - e) * distance * 1.6;
		result.alpha = p;
		result.scale = .96 + .04 * e;
	}
	if (effect === 'flip') {
		result.scaleX = Math.max(.05, Math.sin(p * Math.PI / 2));
		result.alpha = Math.min(1, p * 1.6);
	}
	if (effect === 'swing') {
		result.rotation = Math.sin((1 - p) * Math.PI * 2) * (1 - p) * .09 * strength;
		result.alpha = p;
	}
	// v17: تسعة تأثيرات جديدة — دخول (نبض/سقوط/دوران/ضباب/ارتجاج) + مستمرة بإحساس الفيديو (موجة/تنفس/عدسة/طفو).
	if (effect === 'pulse') {
		// v20: صيغة سابقة كانت تستقر على 0.9 (خطأ) — الآن 0.9 ← 1.06 ← 1.0 بدقة.
		result.scale = p < .6 ? .9 + .16 * (p / .6) : 1.06 - .06 * ((p - .6) / .4);
		result.alpha = p;
	}
	if (effect === 'drop') {
		result.y = -(1 - p) * (1 - p) * 160;
		if (p > .72) result.y -= Math.abs(Math.sin((p - .72) / .28 * Math.PI)) * 10 * strength * (1 - p);
		result.alpha = Math.min(1, p * 1.5);
	}
	if (effect === 'spin') {
		result.rotation = (1 - p) * .14 * strength;
		result.scale = .85 + .15 * p;
		result.alpha = p;
	}
	if (effect === 'mist') {
		result.alpha = p * p;
		result.filter = `blur(${Math.round((1 - p) * 14 * strength)}px) brightness(${(.72 + .28 * p).toFixed(2)})`;
	}
	if (effect === 'impact') {
		const amp = (1 - p) * (1 - p);
		result.x = Math.sin(p * 43) * 11 * amp * strength;
		result.y = Math.cos(p * 37) * 9 * amp * strength;
		result.alpha = Math.min(1, p * 2);
	}
	if (!reduceMotion) {
		if (effect === 'wave') {
			result.y = Math.sin(elapsed * 2.4) * 5 * strength;
			result.rotation = Math.sin(elapsed * 1.7) * .008 * strength;
			result.alpha = Math.min(1, p * 2);
		}
		if (effect === 'breathe') {
			result.scale = 1 + Math.sin(elapsed * 1.5) * .02 * strength;
			result.alpha = Math.min(1, p * 2);
		}
		if (effect === 'kenburns') {
			const s = 1 + Math.min(.06, elapsed * .006);
			result.scale = s;
			result.alpha = Math.min(1, p * 2);
		}
		if (effect === 'float') {
			result.y = Math.sin(elapsed * 1.1) * 6 * strength;
			result.alpha = Math.min(1, p * 2);
		}
	} else if (effect === 'wave' || effect === 'breathe' || effect === 'kenburns' || effect === 'float') {
		result.alpha = p;
	}
	return result;
}

function applyVisualTextEffect(context, effect, intensity, accent, allowGlow = true) {
	const strength = Math.max(.1, Number(intensity) || 1);
	let reduceMotion = false;
	try { reduceMotion = Boolean(document?.body?.classList?.contains('reduce-motion')); } catch (e) {}
	if (allowGlow && effect === 'glow') {
		context.shadowColor = accent;
		context.shadowBlur = 14 * strength;
	}
	// v19: "ظل عميق" كان خياراً ميتاً — ظل applyQuranTextEffect يُكتب فوقه لاحقاً بنمط الخط. هذا الفرع هو الفعّال.
	if (effect === 'shadow') {
		context.shadowColor = 'rgba(0,0,0,.82)';
		context.shadowBlur = 10 * strength;
		context.shadowOffsetX = 0;
		context.shadowOffsetY = 4 * strength;
	}
	// v12: النيون كان نسخة طبق الأصل من التوهج — الآن هالة أوسع + تمريرة ثانية في الرسم.
	if (allowGlow && effect === 'neon') {
		context.shadowColor = accent;
		context.shadowBlur = 26 * strength;
	}
	if (effect === 'outline') {
		context.strokeStyle = accent;
		context.lineWidth = Math.max(1, 1.5 * strength);
		context.lineJoin = 'round';
	}
	if (effect === 'gradient') {
		const gradient = context.createLinearGradient(0, 0, 0, canvas.height);
		gradient.addColorStop(0, accent); gradient.addColorStop(.5, '#ffffff'); gradient.addColorStop(1, accent);
		context.fillStyle = gradient;
	}
	// v17: لمعة عابرة — بريق يمر على النص دورياً (يُحترم تقليل الحركة بثبات اللون الأصلي).
	if (effect === 'shine') {
		if (!reduceMotion) {
			const pos = ((Date.now() / 1000) % 4) / 4 * 1.4 - .2;
			const shine = context.createLinearGradient(0, 0, canvas.width, 0);
			shine.addColorStop(0, accent);
			shine.addColorStop(Math.max(0, Math.min(1, pos - .15)), accent);
			shine.addColorStop(Math.max(0, Math.min(1, pos)), '#ffffff');
			shine.addColorStop(Math.max(0, Math.min(1, pos + .15)), accent);
			shine.addColorStop(1, accent);
			context.fillStyle = shine;
		}
	}
	// v18: أربعة أنماط مستمرة — توهج نابض، تدرج متحرك، ظل حي، حدود نابضة (تتجمد مع تقليل الحركة).
	if (!reduceMotion) {
		const t = Date.now() / 1000;
		if (effect === 'pulseglow') {
			context.shadowColor = accent;
			context.shadowBlur = (14 + 8 * Math.sin(t * 3)) * strength;
		}
		if (effect === 'flowgradient') {
			const pos = (((t % 5) / 5) * 1.5 - .25);
			const flow = context.createLinearGradient(0, 0, canvas.width, 0);
			flow.addColorStop(0, accent);
			flow.addColorStop(Math.max(0, Math.min(1, pos - .22)), accent);
			flow.addColorStop(Math.max(0, Math.min(1, pos)), '#ffffff');
			flow.addColorStop(Math.max(0, Math.min(1, pos + .22)), accent);
			flow.addColorStop(1, accent);
			context.fillStyle = flow;
		}
		if (effect === 'livingshadow') {
			context.shadowColor = 'rgba(0,0,0,.72)';
			context.shadowBlur = 10 * strength;
			context.shadowOffsetX = Math.cos(t * .9) * 8 * strength;
			context.shadowOffsetY = Math.sin(t * .9) * 8 * strength;
		}
		if (effect === 'outlinepulse') {
			context.strokeStyle = accent;
			context.lineWidth = (1.5 + (0.5 + 0.5 * Math.sin(t * 2.5)) * 1.8) * strength;
			context.lineJoin = 'round';
		}
		if (effect === 'neonflicker') {
			context.shadowColor = accent;
			context.shadowBlur = 16 * strength;
		}
	}
	if (effect === 'shake') context.translate((Math.random() - .5) * 4 * strength, (Math.random() - .5) * 4 * strength);
}

function getSmartLayout(width, height, { hasTranslation = false, hasTafsir = false } = {}) {
	const margin = Math.min(width * .09, 96);
	const headerY = height * .13;
	const footerY = height * .91;
	const contentTop = height * .22;
	const contentBottom = height * (hasTafsir ? .82 : hasTranslation ? .78 : .84);
	const available = Math.max(120, contentBottom - contentTop);
	const ayahRatio = hasTranslation || hasTafsir ? .56 : .78;
	const ayahHeight = available * ayahRatio;
	let nextTop = contentTop + ayahHeight + height * .025;
	const translationHeight = hasTranslation ? available * (hasTafsir ? .22 : .35) : 0;
	const tafsirTop = nextTop + translationHeight + height * .02;
	return {
		margin, centerX:width / 2, headerY, footerY, contentTop, contentBottom,
		ayahTop:contentTop, ayahHeight, translationTop:nextTop,
		translationHeight, tafsirTop, tafsirHeight:Math.max(0, contentBottom - tafsirTop)
	};
}

// P2: حُذفت applyTranslationTextEffect الميتة — الترجمة تستخدم applyVisualTextEffect الموحد.
function applyBackgroundMotionEffect(time) {
	const phase = time * bgMotionSpeed;
	if (bgMotionEffect === 'pulse') ctx.globalAlpha = 0.94 + Math.sin(phase) * 0.06;
	if (bgMotionEffect === 'wave') ctx.translate(Math.sin(phase * .8) * canvas.width * .018, Math.cos(phase) * canvas.height * .012);
	if (bgMotionEffect === 'spiral') { ctx.translate(canvas.width / 2, canvas.height / 2); ctx.rotate(Math.sin(phase * .35) * .035); ctx.translate(-canvas.width / 2, -canvas.height / 2); }
	if (bgMotionEffect === 'zoomEffect') { const scale = 1 + Math.sin(phase * .7) * .025; ctx.translate(canvas.width / 2, canvas.height / 2); ctx.scale(scale, scale); ctx.translate(-canvas.width / 2, -canvas.height / 2); }
	if (bgMotionEffect === 'rotateEffect') { ctx.translate(canvas.width / 2, canvas.height / 2); ctx.rotate(Math.sin(phase * .25) * .02); ctx.translate(-canvas.width / 2, -canvas.height / 2); }
}

function applyGradientEffect() {
	const gradients = {
		golden: ['rgba(212,175,55,.18)', 'rgba(244,229,161,0)'],
		ocean: ['rgba(0,172,193,.18)', 'rgba(74,144,217,0)'],
		sunset: ['rgba(255,112,67,.18)', 'rgba(255,193,7,0)'],
		forest: ['rgba(46,125,50,.2)', 'rgba(129,199,132,0)'],
		neon: ['rgba(37,244,238,.16)', 'rgba(254,44,85,0)']
	};
	const colors = gradients[gradientEffect];
	if (!colors) return;
	const gradient = ctx.createLinearGradient(0, 0, canvas.width, canvas.height);
	gradient.addColorStop(0, colors[0]);
	gradient.addColorStop(1, colors[1]);
	ctx.save();
	ctx.fillStyle = gradient;
	ctx.fillRect(0, 0, canvas.width, canvas.height);
	ctx.restore();
}

function applyParticleEffect(time) {
	if (!particleEffectEnabled) return;
	ctx.save();
	particles.forEach(particle => {
		const x = (particle.x * canvas.width + time * particle.vx * 20) % canvas.width;
		const y = (particle.y * canvas.height + time * particle.vy * 20) % canvas.height;
		ctx.globalAlpha = particle.alpha;
		ctx.fillStyle = '#d4af37';
		ctx.beginPath();
		ctx.arc(x < 0 ? x + canvas.width : x, y < 0 ? y + canvas.height : y, particle.r, 0, Math.PI * 2);
		ctx.fill();
	});
	ctx.restore();
}

function applyVignetteEffect() {
	if (!vignetteEffectEnabled) return;
	const gradient = ctx.createRadialGradient(canvas.width / 2, canvas.height / 2, canvas.height * 0.25, canvas.width / 2, canvas.height / 2, canvas.height * 0.75);
	gradient.addColorStop(0, 'rgba(0,0,0,0)');
	gradient.addColorStop(1, 'rgba(0,0,0,.55)');
	ctx.fillStyle = gradient;
	ctx.fillRect(0, 0, canvas.width, canvas.height);
}

function applyFontSettings() {
	const family = getActiveQuranFontFamily();
	const size = document.getElementById('fontSizeRange');
	if (size) fontSettings.size = Number(size.value) || fontSettings.size;
	ctx.font = `${fontSettings.weight} ${fontSettings.size}px "${family}", Amiri, serif`;
	// رسم الإطار فوراً عند تغيير الخط
	if (currentAyahs.length > 0 && !previewLoopRunning) {
		drawCurrentFrame();
	}
}

function applyTransFontSettings() {
	const size = document.getElementById('transFontSizeRange');
	if (size) transFontSettings.size = Number(size.value) || transFontSettings.size;
}

function getTextShadow(shadow, accent = frameColor) {
	const shadows = {
		none: { color:'transparent', blur:0, x:0, y:0 },
		soft: { color:'rgba(0,0,0,.55)', blur:4, x:0, y:2 },
		medium: { color:'rgba(0,0,0,.72)', blur:8, x:0, y:3 },
		strong: { color:'rgba(0,0,0,.9)', blur:13, x:1, y:4 },
		glow: { color:accent, blur:18, x:0, y:0 }
	};
	return shadows[shadow] || shadows.none;
}

function normalizeCanvasText(value) {
	if (value && typeof value === 'object') return String(value.text || value.translation || value.tafsir || '').trim();
	return String(value || '').trim();
}

// v12: تقسيم آمن للحروف (Grapheme) — القصّ بالـ UTF-16 كان يشطر الحركات عن حروفها في تأثير الآلة الكاتبة.
function splitGraphemes(text) {
	const str = String(text || '');
	try {
		if (typeof Intl !== 'undefined' && Intl.Segmenter) {
			return Array.from(new Intl.Segmenter('ar', { granularity: 'grapheme' }).segment(str), s => s.segment);
		}
	} catch (e) {}
	return Array.from(str);
}

// اتجاه الترجمة حسب اللغة — الأردية RTL وبقية الترجمات LTR (كانت ثابتة ltr للجميع خطأً).
function getTranslationDirection() {
	try { if (String(translationKey || '').toLowerCase().startsWith('urdu')) return 'rtl'; } catch (e) {}
	return 'ltr';
}

// v10: أرقام الآيات مشرقية دائماً (٠١٢٣٤٥٦٧٨٩) في الطبعتين — مطابقة للمصحفين المدني والمغربي.
const ARABIC_INDIC_DIGITS = '٠١٢٣٤٥٦٧٨٩';
function toArabicIndicDigits(value) {
	return String(value ?? '').replace(/[0-9]/g, d => ARABIC_INDIC_DIGITS[Number(d)]);
}

// علامة نهاية الآية حسب الرواية — تُرسم بخط الرواية النشط نفسه:
// حفص: ۝ + الرقم (المصحف المدني) / ورش: الرقم بين قوسين مزخرفين ﴿﴾ (الطبعات المغربية).
function formatAyahEndMarker(ayahNumber, riwayah) {
	const digits = toArabicIndicDigits(ayahNumber);
	if (!digits) return '';
	return riwayah === 'warsh' ? ` \uFD3E${digits}\uFD3F` : ` \u06DD${digits}`;
}

function fitTextLines(context, text, maxWidth, fontFamily, weight, requestedSize, lineHeightMultiplier, minSize = 14) {
	const cacheKey = [text, maxWidth, fontFamily, weight, requestedSize, lineHeightMultiplier, minSize].join('|');
	const cached = textLayoutCache.get(cacheKey);
	if (cached) return cached;
	let size = Math.max(minSize, Number(requestedSize) || minSize);
	let lines = [];
	while (size >= minSize) {
		context.font = `${weight} ${size}px "${fontFamily}", Cairo, sans-serif`;
		lines = getWrappedLines(context, text, maxWidth);
		const widest = Math.max(...lines.map(line => context.measureText(line).width), 0);
		if (widest <= maxWidth || size === minSize) break;
		size -= 1;
	}
	const result = { lines, size, lineHeight: size * Math.max(1, Number(lineHeightMultiplier) || 1.2) };
	textLayoutCache.set(cacheKey, result);
	if (textLayoutCache.size > TEXT_LAYOUT_CACHE_LIMIT) {
		const oldestKey = textLayoutCache.keys().next().value;
		textLayoutCache.delete(oldestKey);
	}
	return result;
}

// v18: الحركات المستمرة — تعمل بعد اكتمال الدخول طوال مدة الآية (إحساس الفيديو)،
// وتُجمع مع تأثير الدخول (يمكن تلاشي + تأرجح معاً). حتمية تماماً (لا عشوائية) لثبات التصدير.
// v28: تُغذَّى من motionEffect المنفصل (لا visualEffect) — مع wave/breathe/float الدائمة.
// v20: الومضة السابقة (شرط .93 على حاصل جيبين) كانت تحدث ~6 مرات/دقيقة فبدا التأثير ميتاً.
// الآن خفقة مضمونة كل ~3 ثوانٍ.
function applyPersistentMotion(motionEffect, intensity) {
	const out = { x:0, y:0, scale:1, rotation:0, alpha:1 };
	const strength = Math.max(.1, Number(intensity) || 1);
	try { if (document?.body?.classList?.contains('reduce-motion')) return out; } catch (e) { return out; }
	const t = Date.now() / 1000;
	if (motionEffect === 'tremor') {
		out.x = Math.sin(t * 31) * 1.1 * strength;
		out.y = Math.cos(t * 37) * 1.1 * strength;
	}
	if (motionEffect === 'sway') {
		out.rotation = Math.sin(t * .9) * .011 * strength;
		out.y = Math.sin(t * .9 + .6) * 4 * strength;
	}
	if (motionEffect === 'heartbeat') {
		const c = t % 1.2;
		const thump = c < .12 ? Math.sin(c / .12 * Math.PI) : (c >= .2 && c < .32 ? Math.sin((c - .2) / .12 * Math.PI) * .7 : 0);
		out.scale = 1 + thump * .025 * strength;
	}
	if (motionEffect === 'opacitybreathe') {
		out.alpha = .88 + .12 * (.5 + .5 * Math.sin(t * .8));
	}
	if (motionEffect === 'neonflicker') {
		const cyc = t % 3.1;
		out.alpha = (cyc > 2.8 && cyc < 3.0) ? 0.55 + 0.45 * Math.abs(Math.sin((cyc - 2.8) / 0.2 * Math.PI)) : 1;
	}
	if (motionEffect === 'wave') {
		out.y = Math.sin(t * 2.4) * 5 * strength;
		out.rotation = Math.sin(t * 1.7) * .008 * strength;
	}
	if (motionEffect === 'breathe') {
		out.scale = 1 + Math.sin(t * 1.5) * .02 * strength;
	}
	if (motionEffect === 'float') {
		out.y = Math.sin(t * 1.1) * 6 * strength;
	}
	return out;
}

function drawStyledTextBlock(context, options) {
	const {
		text, x, top, maxWidth, maxHeight, settings, direction = 'rtl', accent = frameColor,
		fontFamily = 'Cairo', minSize = 12, background = true, effect = 'none',
		intensity = 1, progress = 1, visualEffect = 'none', allowGlow = true, extraAlpha = 1,
		motionEffect = 'none', motionIntensity = 1
	} = options;
	const rawValue = normalizeCanvasText(text);
	const rendered = renderEffect(context, { target:direction === 'rtl' ? 'ayah' : 'translation', effect, intensity, progress, text:rawValue });
	const value = rendered.text;
	if (!value) return { height:0, lines:[] };
	const fitted = fitTextLines(context, value, maxWidth, fontFamily, settings.weight, settings.size, settings.lineHeight, minSize);
	const lineCount = fitted.lines.length;
	const contentHeight = lineCount * fitted.lineHeight;
	const paddingX = background && (settings.bgOpacity > 0 || settings.borderWidth > 0) ? 22 : 0;
	const paddingY = background && (settings.bgOpacity > 0 || settings.borderWidth > 0) ? 16 : 0;
	const blockWidth = Math.min(maxWidth + paddingX, canvas.width * .92);
	const blockHeight = Math.min(contentHeight + paddingY, maxHeight || contentHeight + paddingY);
	const blockX = x - blockWidth / 2;
	const blockY = top;
	const shadow = getTextShadow(settings.shadow, accent);

	context.save();
	const ea = Number(extraAlpha);
	const motion = applyPersistentMotion(motionEffect, motionIntensity);
	context.globalAlpha *= rendered.alpha * (Number.isFinite(ea) ? Math.max(0, Math.min(1, ea)) : 1) * motion.alpha;
	context.translate(x + rendered.x + motion.x, blockY + blockHeight / 2 + rendered.y + motion.y);
	context.rotate(rendered.rotation + motion.rotation);
	context.scale(rendered.scale * motion.scale * (rendered.scaleX ?? 1), rendered.scale * motion.scale * (rendered.scaleY ?? 1));
	context.translate(-x, -(blockY + blockHeight / 2));
	context.filter = rendered.filter;
	context.direction = direction;
	context.textAlign = 'center';
	context.textBaseline = 'middle';
	if (background && settings.bgOpacity > 0) {
		context.fillStyle = hexToRgba(settings.bgColor, settings.bgOpacity / 100);
		drawRoundedRect(context, blockX, blockY, blockWidth, blockHeight, settings.borderRadius);
		context.fill();
	}
	if (background && settings.borderWidth > 0) {
		context.strokeStyle = settings.borderColor;
		context.lineWidth = settings.borderWidth;
		drawRoundedRect(context, blockX, blockY, blockWidth, blockHeight, settings.borderRadius);
		context.stroke();
	}
	context.font = `${settings.weight} ${fitted.size}px "${fontFamily}", Cairo, sans-serif`;
	context.fillStyle = settings.color;
	context.shadowColor = shadow.color;
	context.shadowBlur = shadow.blur;
	context.shadowOffsetX = shadow.x;
	context.shadowOffsetY = shadow.y;
	applyVisualTextEffect(context, visualEffect, intensity, accent, allowGlow);
	const textStart = blockY + blockHeight / 2 - (lineCount - 1) * fitted.lineHeight / 2;
	// v18: موجة الأسطر — كل سطر بطور مستقل (يُحترم تقليل الحركة). v28: تُغذَّى من الحركة المنفصلة.
	let lineWaveOn = motionEffect === 'linewave';
	try { if (document?.body?.classList?.contains('reduce-motion')) lineWaveOn = false; } catch (e) {}
	const lineWaveT = Date.now() / 1000;
	const lineWaveAmp = 7 * Math.max(.1, Number(motionIntensity) || 1);
	fitted.lines.forEach((line, index) => {
		const ly = textStart + index * fitted.lineHeight + (lineWaveOn ? Math.sin(lineWaveT * 2.2 + index * .9) * lineWaveAmp : 0);
		if (visualEffect === 'outline' || visualEffect === 'outlinepulse') context.strokeText(line, x, ly);
		context.fillText(line, x, ly);
		// v12: تمريرة النيون الثانية تُبرز قلب الحرف فوق الهالة.
		if (visualEffect === 'neon') context.fillText(line, x, ly);
	});
	context.restore();
	return { height:blockHeight, lines:fitted.lines, size:fitted.size };
}

// P2: حُذفت مغلفات drawAyah/Translation/Tafsir/TransTafsirBlock الميتة — الرسم يتم مباشرة عبر drawStyledTextBlock.
function ensureVideoPostProcessCanvas() {
	if (!videoPostProcessCanvas) {
		videoPostProcessCanvas = document.createElement('canvas');
		videoPostProcessCtx = videoPostProcessCanvas.getContext('2d');
	}
	videoPostProcessCanvas.width = canvas.width;
	videoPostProcessCanvas.height = canvas.height;
	return videoPostProcessCanvas;
}

// v23: بانية نص فلتر الخلفية فقط (بلا آثار جانبية).
// الدالة السابقة applyVideoPostProcess كانت تضبط ctx.filter مباشرة فيتسرب
// الفلتر (سطوع/تباين/تشبع/دفء/تدوير/ضبابية) إلى الآية والترجمة والترويسة فيبهتها.
// extraContrast: تباين الخلفية الديناميكي (قوالب) أو null — يُدمج بدل أن يكتب فوق الفلتر.
function buildVideoPostFilter(extraContrast = null) {
	const adjustment = videoAdjustments || {};
	const brightness = Math.max(0, Number(adjustment.brightness) || 100);
	const exposure = Number(adjustment.exposure) || 0;
	const effectiveBrightness = Math.max(0, brightness * Math.pow(2, exposure / 100));
	const warmth = Math.max(0, Number(adjustment.warmth) || 0);
	const contrast = Math.max(0, Number(adjustment.contrast) || 100);
	const saturation = Math.max(0, Number(adjustment.saturation) || 100);
	const hue = Number(adjustment.hue) || 0;
	const blur = Math.max(0, Number(adjustment.blur) || 0);
	const hasExtra = extraContrast != null && Number.isFinite(Number(extraContrast));
	const isDefault = brightness === 100 && contrast === 100 && saturation === 100 &&
		warmth === 0 && hue === 0 && blur === 0 && exposure === 0 && !hasExtra;
	if (isDefault) return 'none';
	const parts = [`brightness(${effectiveBrightness}%)`, `contrast(${contrast}%)`, `saturate(${saturation}%)`, `sepia(${warmth}%)`, `saturate(${100 + warmth * .35}%)`, `hue-rotate(${hue}deg)`, `blur(${blur}px)`];
	if (hasExtra) parts.push(`contrast(${Number(extraContrast)}%)`);
	return parts.join(' ');
}

function applyVideoPostProcessOverlay() {
	if (!ctx || !canvas) return;
	const adjustment = videoAdjustments;
	const blackPoint = Number(adjustment.blackPoint) || 0;
	const vignette = Math.max(0, Number(adjustment.vignette) || 0);
	if (blackPoint !== 0) {
		ctx.save();
		ctx.fillStyle = blackPoint > 0
			? `rgba(0,0,0,${Math.min(.5, blackPoint / 160)})`
			: `rgba(255,255,255,${Math.min(.25, Math.abs(blackPoint) / 240)})`;
		ctx.fillRect(0, 0, canvas.width, canvas.height);
		ctx.restore();
	}
	if (vignette > 0) {
		ctx.save();
		const radius = Math.max(canvas.width, canvas.height) * .72;
		const gradient = ctx.createRadialGradient(canvas.width / 2, canvas.height / 2, radius * .22, canvas.width / 2, canvas.height / 2, radius);
		gradient.addColorStop(0, 'rgba(0,0,0,0)');
		gradient.addColorStop(1, `rgba(0,0,0,${Math.min(.75, vignette / 125)})`);
		ctx.fillStyle = gradient;
		ctx.fillRect(0, 0, canvas.width, canvas.height);
		ctx.restore();
	}
}

function drawCanvasBackground(time) {
	const source = customBgType === 'video' ? customBgVideo : customBgType === 'image' ? customBgImage : null;
	const sourceWidth = source?.videoWidth || source?.naturalWidth || 0;
	const sourceHeight = source?.videoHeight || source?.naturalHeight || 0;
	const presetTheme = typeof activePresetId === 'string' ? presetBackgroundThemes[activePresetId] : null;
	// v23: الفلتر (تعديلات الفيديو + تباين الخلفية الديناميكي) يُفعَّل قبل بكسلات الخلفية
	// مباشرة ويُطفأ في finally حتى مع return مبكر — فلا يصبغ النصوص أبداً.
	let presetContrast = null;
	if (presetTheme) {
		const contrast = Math.max(0, Math.min(100, Number(dynamicBackgroundContrast) || 50));
		presetContrast = 70 + contrast * .6;
	}
	ctx.filter = buildVideoPostFilter(presetContrast);
	try {
		if (source && sourceWidth > 0 && sourceHeight > 0 && (customBgType !== 'video' || source.readyState >= 2)) {
			const scale = Math.max(canvas.width / sourceWidth, canvas.height / sourceHeight);
			const drawWidth = sourceWidth * scale;
			const drawHeight = sourceHeight * scale;
			ctx.drawImage(source, (canvas.width - drawWidth) / 2, (canvas.height - drawHeight) / 2, drawWidth, drawHeight);
			return;
		}
		if (presetTheme) drawPresetDynamicBackground(presetTheme, time);
		else animatedBGs[currentBgIndex % animatedBGs.length].draw(time);
	} finally {
		ctx.filter = 'none';
	}
}

// v30: شارة الشعار — دائرة تُقصّ Cover فتحافظ على شكلها في أي مقاس/موقع،
 // واسم ملازم لها. تُرسم في المعاينة والتصدير والخمول.
 // v31: دخول/بصري/حركي للشعار (نفس قوائم الآيات). linewave أحادي السطر يُعامل كموجة.
function drawLogoBadge(width, height) {
	const hasImg = Boolean(logoImage && (logoImage.naturalWidth || logoImage.width));
	const name = String(logoName || '').trim();
	if (!hasImg && !name) return;
	const sc = Math.min(width, height) / 1080;
	const mx = width * 0.07, my = height * 0.07;
	const pct = Math.max(4, Math.min(25, Number(logoSizePct) || 12));
	const r = hasImg ? (pct / 100 * width) / 2 : 0;
	let cx = width - mx - r, cy = height - my - r;
	if (logoPosition === 'bottom-left') { cx = mx + r; cy = height - my - r; }
	else if (logoPosition === 'top-right') { cx = width - mx - r; cy = my + r; }
	else if (logoPosition === 'top-left') { cx = mx + r; cy = my + r; }
	else if (logoPosition === 'bottom-center') { cx = width / 2; cy = height - my - r; }
	const lp = getEffectProgress();
	const lr = renderEffect(ctx, { effect: logoTransitionEffect, intensity: 1, progress: lp, text: name || '•' });
	const lm = applyPersistentMotion(logoMotionEffect === 'linewave' ? 'wave' : logoMotionEffect, 1);
	ctx.save();
	ctx.globalAlpha = lr.alpha * lm.alpha;
	ctx.translate(cx + lr.x + lm.x, cy + lr.y + lm.y);
	ctx.rotate(lr.rotation + lm.rotation);
	const lsc = lr.scale * lm.scale * (lr.scaleX ?? 1);
	ctx.scale(lsc, lr.scale * lm.scale);
	ctx.translate(-cx, -cy);
	ctx.filter = lr.filter;
	const lw = hasImg ? Math.max(0, Number(logoBorderWidth) || 0) * sc : 0;
	if (hasImg) {
		// v32: القصّ داخل حفظ/استعادة خاصة به — كان يبتلع اسم الشعار تحته.
		ctx.save();
		ctx.globalAlpha *= Math.max(0, Math.min(1, (Number(logoOpacity) || 0) / 100));
		if (lw > 0) {
			ctx.beginPath();
			ctx.arc(cx, cy, r + lw / 2, 0, Math.PI * 2);
			ctx.strokeStyle = logoBorderColor || '#d4af37';
			ctx.lineWidth = lw;
			ctx.stroke();
		}
		ctx.beginPath();
		ctx.arc(cx, cy, Math.max(1, r - 1), 0, Math.PI * 2);
		ctx.clip();
		const iw = logoImage.naturalWidth || logoImage.width || 1;
		const ih = logoImage.naturalHeight || logoImage.height || 1;
		const s = Math.max((2 * r) / iw, (2 * r) / ih);
		ctx.drawImage(logoImage, cx - (iw * s) / 2, cy - (ih * s) / 2, iw * s, ih * s);
		ctx.restore();
	}
	if (name) {
		// v32: الاسم أسفل الدائرة دائماً (خط أساس صريح) + مسافة قابلة للضبط.
		const ns = Math.max(8, Math.round((Number(logoNameSize) || 28) * sc));
		const gap = Math.max(0, Math.min(60, Number(logoNameGap) || 0)) * sc;
		const ny = Math.min(cy + r + lw + gap + ns, height - height * 0.02);
		ctx.globalAlpha = lr.alpha * lm.alpha * Math.max(0, Math.min(1, (Number(logoNameOpacity) || 0) / 100));
		ctx.font = `700 ${ns}px "${logoNameFont}", Cairo, sans-serif`;
		ctx.textAlign = 'center';
		ctx.textBaseline = 'alphabetic';
		ctx.direction = /[\u0600-\u06FF]/.test(name) ? 'rtl' : 'ltr';
		ctx.fillStyle = logoNameColor || '#f4e5a1';
		applyVisualTextEffect(ctx, logoTextEffect, 1, logoNameColor || '#f4e5a1', true);
		if (logoTextEffect === 'outline') ctx.strokeText(name, cx, ny);
		ctx.fillText(name, cx, ny);
		if (logoTextEffect === 'neon') ctx.fillText(name, cx, ny);
	}
	ctx.filter = 'none';
	ctx.restore();
}

function drawFrameContentBase(ayahText, surahName, ayahNumber, totalAyahs) {
	const width = canvas.width;
	const height = canvas.height;
	const centerX = width / 2;
	const time = (Date.now() - startTime) / 1000;
	const hasTranslation = Boolean(translationsData[ayahNumber]);
	const hasTafsir = Boolean(tafsirEnabled && tafsirData[ayahNumber]);
	const layout = getSmartLayout(width, height, { hasTranslation, hasTafsir });
	const effectProgress = getEffectProgress();
	ctx.save();
	applyBackgroundMotionEffect(time);
	drawCanvasBackground(time);
	applyGradientEffect();
	ctx.restore();
	ctx.save();
	if (contrastLevel > 0) {
		ctx.fillStyle = `rgba(0,0,0,${Math.min(0.75, contrastLevel / 150)})`;
		ctx.fillRect(0, 0, width, height);
	}
	if (frameIndex > 0) islamicFrames[frameIndex]?.draw(ctx, width, height, time);
	ctx.textAlign = 'center';
	ctx.direction = 'rtl';
	ctx.fillStyle = frameColor;
	// v10: اسم السورة أعلى الشاشة بخط قرآني (Amiri Quran) وحجم مضاعف ×2 نسبي لارتفاع اللوحة
	// (84px عند 1920 — النسبة للارتفاع حتى لا تتضخم الترويسة في المقاس الأفقي 16:9).
	const headerSize = Math.max(26, Math.round(height * 0.044));
	ctx.font = `bold ${headerSize}px "Amiri Quran", Amiri, serif`;
	ctx.fillText(surahName || 'القرآن الكريم', centerX, layout.headerY);
	applyQuranTextEffect(quranTextEffect, quranTextEffectIntensity);
	const activeRiwayah = (typeof fullSurahData !== 'undefined' && fullSurahData?.riwayah) || (typeof currentRiwayah !== 'undefined' ? currentRiwayah : 'hafs');
	const ayahBlock = drawStyledTextBlock(ctx, {
		text:String(ayahText || '') + formatAyahEndMarker(ayahNumber, activeRiwayah), x:centerX, top:layout.ayahTop, maxWidth:width - layout.margin * 2,
		maxHeight:layout.ayahHeight, settings:fontSettings, fontFamily:getActiveQuranFontFamily(),
		minSize:16, accent:frameColor, effect:transitionEffect, intensity:quranTextEffectIntensity,
		progress:effectProgress, visualEffect:quranTextEffect, allowGlow:glowEnabled,
		motionEffect:quranMotionEffect, motionIntensity:quranMotionIntensity
	});
	ctx.shadowColor = 'transparent';
	let nextBlockTop = layout.translationTop;
	// v14: قفل تام — الترجمة والتفسير يدخلان ويخرجان مع الآية في نفس اللحظة (extraAlpha ثابت).
	// نافذة البقاء السابقة حُذفت لأنها كانت تُخفي الترجمة قبل انتهاء التلاوة.
	const transDirection = getTranslationDirection();
	const translation = translationsData[ayahNumber];
	if (translation) {
		drawStyledTextBlock(ctx, {
			text:translation, x:centerX, top:nextBlockTop, maxWidth:width - layout.margin * 2,
			maxHeight:layout.translationHeight, settings:transFontSettings, fontFamily:transFontSettings.family,
			direction:transDirection, minSize:12, accent:'#4a90d9', effect:translationTransitionEffect,
			intensity:translationTextEffectIntensity, progress:getEffectProgress(ayahTransitionStart, translationAnimationDuration), visualEffect:translationTextEffect, extraAlpha:1,
			motionEffect:translationMotionEffect, motionIntensity:translationMotionIntensity
		});
		nextBlockTop += layout.translationHeight + height * .02;
	}
	const tafsir = tafsirEnabled ? tafsirData[ayahNumber] : null;
	if (tafsir && nextBlockTop < layout.contentBottom) {
		drawStyledTextBlock(ctx, {
			text:tafsir, x:centerX, top:nextBlockTop, maxWidth:width - layout.margin * 2,
			maxHeight:layout.tafsirHeight, settings:transFontSettings, fontFamily:transFontSettings.family,
			direction:'rtl', minSize:11, accent:'#2ecc71', effect:translationTransitionEffect,
			intensity:translationTextEffectIntensity, progress:getEffectProgress(ayahTransitionStart, translationAnimationDuration), visualEffect:translationTextEffect, extraAlpha:1,
			motionEffect:translationMotionEffect, motionIntensity:translationMotionIntensity
		});
	}
	ctx.fillStyle = frameColor;
	// v10: أسفل الشاشة = نطاق الآيات المطلوبة للريل. v30: خط/حجم/تباين/لون قابلة للتخصيص
	// (نص فارغ = النطاق التلقائي). الأحجام نسبية لأصغر بُعد (مرجع 1080) لتعمل على كل المقاسات.
	const rangeStart = (typeof currentAyahs !== 'undefined' && currentAyahs.length) ? Number(currentAyahs[0].numberInSurah) : Number(ayahNumber);
	const rangeEnd = (typeof currentAyahs !== 'undefined' && currentAyahs.length) ? Number(currentAyahs[currentAyahs.length - 1].numberInSurah) : Number(totalAyahs);
	const footerScale = Math.min(width, height) / 1080;
	const footerPx = Math.max(10, Math.round((Number(footerSize) || 44) * footerScale));
	const footerStr = String(footerText || '').trim()
		? String(footerText).trim()
		: `الآية ${toArabicIndicDigits(ayahNumber)} • الآيات ${toArabicIndicDigits(rangeStart)} – ${toArabicIndicDigits(rangeEnd)}`;
	// v31: دخول/بصري/حركي للتذييل (نفس قوائم الآيات). linewave أحادي السطر يُعامل كموجة.
	const fp = getEffectProgress();
	const fr = renderEffect(ctx, { effect: footerTransitionEffect, intensity: 1, progress: fp, text: footerStr });
	const fm = applyPersistentMotion(footerMotionEffect === 'linewave' ? 'wave' : footerMotionEffect, 1);
	ctx.save();
	ctx.globalAlpha = Math.max(0, Math.min(1, (Number(footerOpacity) || 0) / 100)) * fr.alpha * fm.alpha;
	ctx.translate(centerX + fr.x + fm.x, layout.footerY + fr.y + fm.y);
	ctx.rotate(fr.rotation + fm.rotation);
	const fsc = fr.scale * fm.scale * (fr.scaleX ?? 1);
	ctx.scale(fsc, fr.scale * fm.scale);
	ctx.translate(-centerX, -layout.footerY);
	ctx.filter = fr.filter;
	ctx.font = `bold ${footerPx}px "${footerFont}", Cairo, sans-serif`;
	ctx.textAlign = 'center';
	ctx.direction = /[\u0600-\u06FF]/.test(footerStr) ? 'rtl' : 'ltr';
	ctx.fillStyle = footerColor || frameColor;
	applyVisualTextEffect(ctx, footerTextEffect, 1, footerColor || frameColor, true);
	if (footerTextEffect === 'outline') ctx.strokeText(footerStr, centerX, layout.footerY);
	ctx.fillText(footerStr, centerX, layout.footerY);
	if (footerTextEffect === 'neon') ctx.fillText(footerStr, centerX, layout.footerY);
	ctx.filter = 'none';
	ctx.restore();
	drawLogoBadge(width, height);
	ctx.restore();
	applyParticleEffect(time);
	applyVignetteEffect();
}

function drawFrameContent(ayahText, surahName, ayahNumber, totalAyahs) {
	updateCanvasAccessibleText(ayahText, surahName, ayahNumber, totalAyahs);
	// v23: لا applyVideoPostProcess هنا — الفلتر داخل drawCanvasBackground فقط (خلفية حصراً).
	drawFrameContentBase(ayahText, surahName, ayahNumber, totalAyahs);
	applyVideoPostProcessOverlay();
	drawPreviewMirror();
	ctx.filter = 'none';
}

function drawPreviewMirror() {
	const mirror = document.getElementById('ayahsPreviewMirror');
	if (!mirror || !canvas || mirror.offsetParent === null) return;
	const mirrorContext = mirror.getContext('2d');
	if (!mirrorContext) return;
	mirrorContext.clearRect(0, 0, mirror.width, mirror.height);
	const scale = Math.min(mirror.width / canvas.width, mirror.height / canvas.height);
	const width = canvas.width * scale;
	const height = canvas.height * scale;
	try { mirrorContext.drawImage(canvas, (mirror.width - width) / 2, (mirror.height - height) / 2, width, height); } catch (error) { console.warn('تعذر تحديث معاينة الآيات:', error); }
}

function drawCurrentFrame() {
	if (!currentAyahs.length) return;
	const ayah = currentAyahs[currentAyahIndex] || currentAyahs[0];
	drawFrameContent(ayah.text, document.getElementById('captionText').value || fullSurahData?.surahName || '', ayah.numberInSurah, currentAyahs.length);
}

function updateCanvasAccessibleText(ayahText = '', surahName = '', ayahNumber = '', totalAyahs = '') {
	const output = document.getElementById('canvasAccessibleText');
	if (!output) return;
	const translation = ayahNumber ? normalizeCanvasText(translationsData[ayahNumber]) : '';
	const tafsir = ayahNumber && tafsirEnabled ? normalizeCanvasText(tafsirData[ayahNumber]) : '';
	output.textContent = [
		surahName || 'القرآن الكريم',
		ayahText,
		translation,
		tafsir,
		ayahNumber ? `الآية ${toArabicIndicDigits(ayahNumber)}` : ''
	].filter(Boolean).join(' — ');
}

function drawIdlePreviewFrame() {
	if (!canvas || !ctx) return;
	const time = (Date.now() - startTime) / 1000;
	updateCanvasAccessibleText('بسم الله الرحمن الرحيم');
	ctx.save();
	drawCanvasBackground(time);
	applyGradientEffect();
	ctx.fillStyle = frameColor;
	ctx.font = 'bold 48px Amiri, serif';
	ctx.textAlign = 'center';
	ctx.direction = 'rtl';
	ctx.fillText('بسم الله الرحمن الرحيم', canvas.width / 2, canvas.height / 2);
	ctx.restore();
	drawLogoBadge(canvas.width, canvas.height);
	applyParticleEffect(time);
	applyVignetteEffect();
	applyVideoPostProcessOverlay();
	ctx.filter = 'none';
	drawPreviewMirror();
}

function redrawPreviewFrame() {
	if (currentAyahs.length) drawCurrentFrame();
	else drawIdlePreviewFrame();
}

// v24: معاينة عينات التأثيرات حُذفت مع إفراغ القسم.

function syncVideoAdjustmentUI() {
	const controls = {
		videoBrightnessRange:['brightness', v=>`${Math.round(v)}%`, 'videoBrightnessValue'],
		videoContrastRange:['contrast', v=>`${Math.round(v)}%`, 'videoContrastValue'],
		videoSaturationRange:['saturation', v=>`${Math.round(v)}%`, 'videoSaturationValue'],
		videoWarmthRange:['warmth', v=>`${Math.round(v)}%`, 'videoWarmthValue'],
		videoHueRange:['hue', v=>`${Math.round(v)}°`, 'videoHueValue'],
		videoBlurRange:['blur', v=>`${Number(v).toFixed(1)}px`, 'videoBlurValue'],
		videoVignetteRange:['vignette', v=>`${Math.round(v)}%`, 'videoVignetteValue'],
		videoExposureRange:['exposure', v=>`${Math.round(v)}`, 'videoExposureValue'],
		videoBlackPointRange:['blackPoint', v=>`${Math.round(v)}`, 'videoBlackPointValue']
	};
	Object.entries(controls).forEach(([id, [key, format, outputId]]) => {
		const value = Number(videoAdjustments[key]) || 0;
		const element = document.getElementById(id);
		const output = document.getElementById(outputId);
		if (element) element.value = value;
		if (output) output.textContent = format(value);
	});
}

function previewNeedsAnimation() {
	const presetsPaneVisible = document.getElementById('pane-presets')?.classList.contains('active');
	return Boolean(finalExportInProgress || isPlaying || autoPreviewEnabled || customBgType === 'video' || (activePresetId && presetsPaneVisible));
}

function startPreviewLoop() {
	if (previewLoopRunning || !previewNeedsAnimation()) return;
	previewLoopRunning = true;
	lastPreviewFrameTime = 0;
	animationId = requestAnimationFrame(animate);
}

function stopPreviewLoop() {
	previewLoopRunning = false;
	if (animationId !== null) {
		cancelAnimationFrame(animationId);
		animationId = null;
	}
}

function animate(timestamp = 0) {
	if (!previewLoopRunning) return;
	if (!previewNeedsAnimation()) { stopPreviewLoop(); return; }
	// الخلفية الديناميكية لا تحتاج معدل فيديو كامل أثناء التصفح؛ نرفع المعدل عند التشغيل والتصدير.
	const targetFps = finalExportInProgress || isPlaying ? 24 : currentAyahs.length ? 12 : 8;
	if (timestamp - lastPreviewFrameTime < 1000 / targetFps) {
		animationId = requestAnimationFrame(animate);
		return;
	}
	lastPreviewFrameTime = timestamp;
	redrawPreviewFrame();
	animationId = requestAnimationFrame(animate);
}

document.addEventListener('visibilitychange', () => {
	if (document.hidden && !finalExportInProgress) stopPreviewLoop();
	else if (previewNeedsAnimation()) startPreviewLoop();
});














































