// ============ واجهة ============
function setStatus(msg, type = '') {
  const bar = document.getElementById('statusBar');
  bar.textContent = msg;
  bar.className = 'status-bar ' + type;
}

function resetFetchedData(promptMsg) {
  invalidateAsyncRequest('content'); invalidateAsyncRequest('translation'); invalidateAsyncRequest('tafsir'); invalidateAsyncRequest('audio');
  try { activeReciterAudioPreparation = null; } catch (e) { /* api.js غير مهيأ (نسخة قديمة مخزنة) — فحص الإقلاع يبلغ المستخدم */ }
  fullSurahData = null;
  currentAyahs = [];
  isPlaying = false;
  isPaused = false;
  clearAyahTimer();
  translationsData = {};
  tafsirData = {};
  riwayahAyahsData = {};
  document.getElementById('translationStatus').textContent = '';
  document.getElementById('tafsirStatus').textContent = '';
  document.getElementById('riwayahStatus').textContent = '';
  document.getElementById('startAyah').disabled = true;
  document.getElementById('endAyah').disabled = true;
  document.getElementById('ayahRangeToggle').checked = false;
  document.getElementById('rangeStatus').textContent = 'فعّل الاختيار لتحديد الآيات التي ستظهر في شاشة الريل.';
  document.getElementById('rangeStatus').style.color = '#7a8a99';
  document.getElementById('fetchStatus').textContent = '';
  audio.pause();
  try { audio.currentTime = 0; } catch (e) {}
  setAudioStatus(audioSourceMode === 'upload' && manualAudioUrl ? '✅ الملف اليدوي محفوظ وجاهز، لكن نطاق الآيات سيُعاد تحميله.' : 'سيتم استخدام نفس نطاق الآيات الذي اخترته أعلاه.');
  renderAyahsList();
  updateStats();
  if (promptMsg) setStatus(promptMsg, 'error');
}

// ============ رفع خلفية ============
document.getElementById('bgUpload').addEventListener('change', (e) => {
  const file = e.target.files[0];
  if (!file) return;
  // P2: تقييد الأنواع + حظر SVG (قد يحمل foreignObject يلوث Canvas ويمنع التصدير).
  const ALLOWED_BG_TYPES = ['image/jpeg', 'image/png', 'image/webp', 'video/mp4', 'video/webm'];
  const ext = String(file.name || '').toLowerCase().split('.').pop();
  const ALLOWED_BG_EXTS = ['jpg', 'jpeg', 'png', 'webp', 'mp4', 'webm'];
  if (file.type === 'image/svg+xml' || /\.svg$/i.test(file.name || '')) {
    setStatus('❌ ملفات SVG غير مسموحة للخلفية (خطر أمني وتلويث Canvas). استخدم JPG/PNG/WebP.', 'error');
    e.target.value = '';
    return;
  }
  if (!ALLOWED_BG_TYPES.includes(file.type) && !ALLOWED_BG_EXTS.includes(ext)) {
    setStatus('❌ الصيغة غير مدعومة. المسموح: JPG, PNG, WebP, MP4, WebM.', 'error');
    e.target.value = '';
    return;
  }
  if (!file.type.startsWith('video/') && !file.type.startsWith('image/')) {
    setStatus('❌ الملف المحدد ليس صورة أو فيديو صالحًا.', 'error');
    e.target.value = '';
    return;
  }
  if (file.size > MAX_BACKGROUND_FILE_SIZE) {
    setStatus(`❌ حجم الخلفية أكبر من الحد المسموح (${Math.round(MAX_BACKGROUND_FILE_SIZE / (1024 * 1024))}MB).`, 'error');
    e.target.value = '';
    return;
  }
  revokeCustomBgObjectUrl();
  const url = URL.createObjectURL(file);
  customBgObjectUrl = url;
  if (file.type.startsWith('video/')) {
    customBgType = 'video';
    bgVideo.src = url;
    bgVideo.loop = true;
    bgVideo.muted = true;
    bgVideo.play().catch(() => {});
    customBgVideo = bgVideo;
    customBgImage = null;
    document.getElementById('clearCustomBg').style.display = 'block';
    setStatus('✅ تم رفع فيديو الخلفية', 'success');
  } else if (file.type.startsWith('image/')) {
    customBgType = 'image';
    const img = new Image();
    img.onload = () => {
      customBgImage = img;
      customBgVideo = null;
      document.getElementById('clearCustomBg').style.display = 'block';
      setStatus('✅ تم رفع صورة الخلفية', 'success');
    };
    img.src = url;
  }
});

document.getElementById('clearCustomBg').addEventListener('click', () => {
  revokeCustomBgObjectUrl();
  customBgType = null;
  customBgImage = null;
  customBgVideo = null;
  bgVideo.src = '';
  document.getElementById('bgUpload').value = '';
  document.getElementById('clearCustomBg').style.display = 'none';
  setStatus('تم إزالة الخلفية المخصصة', '');
});

// ============ التبويبات ============
function activateMainTab(tab) {
    document.querySelectorAll('.main-tab').forEach(t => t.classList.remove('active'));
    document.querySelectorAll('.tab-pane').forEach(p => p.classList.remove('active'));
    tab.classList.add('active');
    document.querySelectorAll('.main-tab').forEach(t => {
      const selected = t === tab;
      t.setAttribute('aria-selected', String(selected));
      t.tabIndex = selected ? 0 : -1;
    });
    const pane = document.getElementById('pane-' + tab.dataset.pane);
    if (pane) pane.classList.add('active');
    if (tab.dataset.pane === 'presets' && activePresetId) {
      startPreviewLoop();
    } else if (tab.dataset.pane !== 'presets' && !finalExportInProgress && !isPlaying && !autoPreviewEnabled && customBgType !== 'video') {
      stopPreviewLoop();
    }
    if (tab.dataset.pane === 'ayahs' && currentAyahs.length > 0) {
      setTimeout(applyFontSettings, 50);
    }
}

document.querySelectorAll('.main-tab').forEach(tab => {
  tab.addEventListener('click', () => activateMainTab(tab));
  tab.addEventListener('keydown', event => {
    if (!['ArrowLeft', 'ArrowRight', 'Home', 'End'].includes(event.key)) return;
    const tabs = [...document.querySelectorAll('.main-tab')];
    const currentIndex = tabs.indexOf(tab);
    const direction = event.key === 'ArrowLeft' ? -1 : event.key === 'ArrowRight' ? 1 : 0;
    const nextIndex = event.key === 'Home' ? 0 : event.key === 'End' ? tabs.length - 1 : (currentIndex + direction + tabs.length) % tabs.length;
    event.preventDefault();
    tabs[nextIndex].focus();
    activateMainTab(tabs[nextIndex]);
  });
});

document.querySelectorAll('.recordings-subtab').forEach(tab => {
  tab.addEventListener('click', () => {
    const view = tab.dataset.recordingsView;
    document.querySelectorAll('.recordings-subtab').forEach(item => {
      const selected = item === tab;
      item.classList.toggle('active', selected);
      item.setAttribute('aria-selected', String(selected));
    });
    document.querySelectorAll('[data-recordings-panel]').forEach(panel => {
      panel.classList.toggle('active', panel.dataset.recordingsPanel === view);
    });
  });
});

document.getElementById('showPreviewFromAyahsBtn')?.addEventListener('click', () => {
  const previewPanel = document.querySelector('.preview-panel');
  if (previewPanel) previewPanel.scrollIntoView({ behavior:'smooth', block:'start' });
});

document.getElementById('stopExportBtn')?.addEventListener('click', () => {
  if (!mediaRecorder || mediaRecorder.state === 'inactive') return;
  const status = document.getElementById('finalExportStatus');
  if (status) status.textContent = '⏳ جارٍ إنهاء الجزء المسجل وحفظه...';
  stopRecording(true);
});

// ============ الأحداث ============
// P1-1: مستمع واحد مدمج لاختيار السورة (كان مستمعان منفصلان) — تصفير البيانات ثم مزامنة النطاق.
document.getElementById('surahSelect').addEventListener('change', (e) => {
  resetFetchedData(e.target.value ? '⚠️ الرجاء الضغط على "جلب الآيات" لتحميل السورة' : '');
  syncAyahRangeControls();
});

document.getElementById('reciterSelect').addEventListener('change', () => {
  invalidateAsyncRequest('audio');
  try { activeReciterAudioPreparation = null; } catch (e) { /* api.js غير مهيأ (نسخة قديمة مخزنة) — فحص الإقلاع يبلغ المستخدم */ }
  audioSourceMode = 'reciter';
  document.getElementById('audioModeReciter').checked = true;
  updateAudioSourceUI();
  audio.pause();
  audio.removeAttribute('src');
  audio.load();
  if (fullSurahData && currentAyahs.length) {
    setAudioStatus('⚠️ تم تغيير القارئ. اضغط "تجهيز صوت الآيات المحددة" لتحميل صوت القارئ الجديد دون إعادة جلب النص.', 'warning');
  } else {
    setAudioStatus('اختر السورة والنطاق ثم اضغط "جلب الآيات".');
  }
});

document.getElementById('riwayahSelect').addEventListener('change', (e) => {
  currentRiwayah = e.target.value;
  refreshReciterOptions();
  enforceRiwayahFont();
  refreshFontFamilyOptions();
  const label = typeof getRiwayahDisplayLabel === 'function' ? getRiwayahDisplayLabel(currentRiwayah) : currentRiwayah;
  resetFetchedData(`⚠️ تم تغيير الرواية إلى ${label} — الكتابة والقارئ والخط أصبحت كلها برواية ${label}. أعد الضغط على "جلب الآيات"`);
});

// ============ أحداث نطاق الآيات ============
document.getElementById('ayahRangeToggle').addEventListener('change', () => {
  syncAyahRangeControls();
  if (fullSurahData && document.getElementById('ayahRangeToggle').checked) {
    prepareRange();
  }
});

['startAyah', 'endAyah'].forEach(id => {
  document.getElementById(id).addEventListener('input', () => {
    syncAyahRangeControls();
  });
});

document.getElementById('captionText').addEventListener('input', () => {
  redrawPreviewFrame();
  scheduleProjectAutosave();
});

document.getElementById('exportModeSelect')?.addEventListener('change', (event) => {
  applyExportMode(event.target.value);
  redrawPreviewFrame();
  scheduleProjectAutosave();
  const mode = exportModes[event.target.value];
  setStatus(mode ? `✅ نوع التصدير: ${mode.icon} ${mode.name}` : '✅ تم تحديث نوع التصدير', 'success');
});

document.querySelectorAll('input[name="audioSourceMode"]').forEach(radio => {
  radio.addEventListener('change', () => {
    audioSourceMode = radio.value;
    audio.pause();
    clearAyahTimer();
    updateAudioSourceUI();
    if (audioSourceMode === 'reciter') {
      audio.removeAttribute('src');
      audio.load();
      setAudioStatus(currentAyahs.length ? 'اضغط "تجهيز صوت الآيات المحددة" للتحقق من صوت النطاق الحالي.' : 'سيتم استخدام نفس نطاق الآيات الذي اخترته أعلاه.');
    } else if (manualAudioUrl) {
      audio.src = manualAudioUrl;
      audio.load();
      setAudioStatus('✅ الملف اليدوي جاهز للاستخدام.', 'success');
    } else {
      setAudioStatus('⚠️ الوضع اليدوي مفعّل. ارفع ملفًا صوتيًا قبل التشغيل أو التصدير.', 'warning');
    }
  });
});

document.getElementById('prepareAudioBtn').addEventListener('click', () => {
  if (typeof prepareReciterAudio !== 'function') {
    setStatus('⚠️ تم تحميل نسخة قديمة مخزنة تمنع تجهيز الصوت. حدّث الصفحة بقوة Ctrl+Shift+R ثم أعد المحاولة.', 'error');
    return;
  }
  audioSourceMode = 'reciter';
  prepareReciterAudio(true);
});

document.getElementById('audioFileInput').addEventListener('change', (e) => {
  handleManualAudioFile(e.target.files && e.target.files[0]);
});

document.getElementById('clearAudioBtn').addEventListener('click', () => {
  if (typeof clearManualAudio !== 'function') return;
  clearManualAudio();
});

document.getElementById('fetchAyahsBtn').addEventListener('click', () => {
  if (typeof fetchFullSurah !== 'function') {
    setStatus('⚠️ تم تحميل نسخة قديمة مخزنة تمنع الجلب. حدّث الصفحة بقوة Ctrl+Shift+R ثم أعد المحاولة.', 'error');
    return;
  }
  fetchFullSurah();
});

document.getElementById('testTranslationsBtn').addEventListener('click', async () => {
  const btn = document.getElementById('testTranslationsBtn');
  btn.disabled = true;
  const oldText = btn.textContent;
  btn.textContent = '⏳ جاري الاختبار...';
  const list = await discoverTranslations();
  const keys = Object.keys(list);
  const el = document.getElementById('translationStatus');
  if (keys.length > 0) {
    el.textContent = `✅ تم اكتشاف ${keys.length} مفتاح ترجمة`;
    el.style.color = '#7ed6a5';
    const select = document.getElementById('translationSelect');
    const currentVal = select.value;
    select.innerHTML = '<option value="">-- بدون ترجمة --</option>';
    keys.forEach(k => {
      const opt = document.createElement('option');
      opt.value = k;
      opt.textContent = `${list[k].title} (${list[k].lang})`;
      select.appendChild(opt);
    });
    if (currentVal && keys.includes(currentVal)) select.value = currentVal;
  } else {
    el.textContent = '⚠️ لم يتم اكتشاف مفاتيح';
    el.style.color = '#f39c12';
  }
  btn.disabled = false;
  btn.textContent = oldText;
});

// v25: قسم التأثيرات المعاد بناؤه (خطوة بخطوة) — معالجاته أدناه.

// ============ التعديلات الاحترافية للفيديو ============
[
  ['videoBrightnessRange','brightness','videoBrightnessValue',v=>`${Math.round(v)}%`],
  ['videoContrastRange','contrast','videoContrastValue',v=>`${Math.round(v)}%`],
  ['videoSaturationRange','saturation','videoSaturationValue',v=>`${Math.round(v)}%`],
  ['videoWarmthRange','warmth','videoWarmthValue',v=>`${Math.round(v)}%`],
  ['videoHueRange','hue','videoHueValue',v=>`${Math.round(v)}°`],
  ['videoBlurRange','blur','videoBlurValue',v=>`${Number(v).toFixed(1)}px`],
  ['videoVignetteRange','vignette','videoVignetteValue',v=>`${Math.round(v)}%`],
  ['videoExposureRange','exposure','videoExposureValue',v=>`${Math.round(v)}`],
  ['videoBlackPointRange','blackPoint','videoBlackPointValue',v=>`${Math.round(v)}`]
].forEach(([id,key,out,fmt])=>{
  const el=document.getElementById(id);
  if(!el) return;
  el.addEventListener('input',e=>{
    const v=parseFloat(e.target.value);
    videoAdjustments[key]=Number.isFinite(v)?v:0;
    const label=document.getElementById(out); if(label) label.textContent=fmt(videoAdjustments[key]);
    const status=document.getElementById('videoAdjustmentsStatus'); if(status) status.textContent='🎨 تعديلات الفيديو مفعّلة وتظهر مباشرة في المعاينة والتسجيل';
    redrawPreviewFrame();
    scheduleProjectAutosave();
  });
});

document.getElementById('resetVideoAdjustmentsBtn')?.addEventListener('click',()=>{
  videoAdjustments={brightness:100,contrast:100,saturation:100,warmth:0,hue:0,blur:0,vignette:0,exposure:0,blackPoint:0};
  syncVideoAdjustmentUI();
  scheduleProjectAutosave();
  redrawPreviewFrame();
});



function redrawDynamicBackgroundPreview() {
  if (currentAyahs.length > 0) drawCurrentFrame();
  else {
    ctx.save();
    drawCanvasBackground((Date.now() - startTime) / 1000);
    ctx.restore();
  }
  if (previewNeedsAnimation()) startPreviewLoop();
}

document.getElementById('presetBackgroundContrastRange').addEventListener('input', (e) => {
  dynamicBackgroundContrast = parseFloat(e.target.value);
  document.getElementById('presetBackgroundContrastValue').textContent = Math.round(dynamicBackgroundContrast);
  redrawDynamicBackgroundPreview();
  scheduleProjectAutosave();
});

document.getElementById('presetBackgroundSpeedRange').addEventListener('input', (e) => {
  dynamicBackgroundSpeed = parseFloat(e.target.value);
  document.getElementById('presetBackgroundSpeedValue').textContent = dynamicBackgroundSpeed.toFixed(1);
  redrawDynamicBackgroundPreview();
  scheduleProjectAutosave();
});


// v27: قسم التأثيرات فارغ — تُضاف المعالجات هنا خطوة بخطوة بموافقة المستخدم.
// v28: الخطوة 1 — الدخول (7) + البصري (7) + الحركي (7) للآيات والترجمة.
function snapFxClock() {
  ayahTransitionStart = Date.now();
  try {
    if (!previewLoopRunning && currentAyahs.length) {
      ayahTransitionStart = Date.now() - Math.max(Number(effectAnimationDuration) || 0, Number(translationAnimationDuration) || 0) - 60;
    }
  } catch (e) {}
}

document.getElementById('effectSelect').addEventListener('change', (e) => {
  transitionEffect = e.target.value;
  ctx.setTransform(1, 0, 0, 1, 0, 0);
  ctx.filter = 'none';
  ctx.globalAlpha = 1;
  ctx.globalCompositeOperation = 'source-over';
  snapFxClock();
  if (!previewLoopRunning && currentAyahs.length > 0) setTimeout(() => drawCurrentFrame(), 50);
});

document.getElementById('effectSpeedRange').addEventListener('input', (e) => {
  effectAnimationDuration = parseInt(e.target.value);
  document.getElementById('effectSpeedValue').textContent = effectAnimationDuration;
  snapFxClock();
  redrawPreviewFrame();
});

document.getElementById('quranTextEffectSelect').addEventListener('change', (e) => {
  quranTextEffect = e.target.value;
  redrawPreviewFrame();
});

document.getElementById('quranTextEffectIntensityRange').addEventListener('input', (e) => {
  quranTextEffectIntensity = parseFloat(e.target.value);
  document.getElementById('quranTextEffectIntensityValue').textContent = quranTextEffectIntensity.toFixed(1);
  redrawPreviewFrame();
});

document.getElementById('quranMotionEffectSelect').addEventListener('change', (e) => {
  quranMotionEffect = e.target.value;
  redrawPreviewFrame();
});

document.getElementById('quranMotionIntensityRange').addEventListener('input', (e) => {
  quranMotionIntensity = parseFloat(e.target.value);
  document.getElementById('quranMotionIntensityValue').textContent = quranMotionIntensity.toFixed(1);
  redrawPreviewFrame();
});

document.getElementById('translationTransitionSelect').addEventListener('change', (e) => {
  translationTransitionEffect = e.target.value;
  snapFxClock();
  redrawPreviewFrame();
});

document.getElementById('translationEffectSpeedRange').addEventListener('input', (e) => {
  translationAnimationDuration = parseInt(e.target.value);
  document.getElementById('translationEffectSpeedValue').textContent = translationAnimationDuration;
  snapFxClock();
  redrawPreviewFrame();
});

document.getElementById('translationTextEffectSelect').addEventListener('change', (e) => {
  translationTextEffect = e.target.value;
  redrawPreviewFrame();
});

document.getElementById('translationTextEffectIntensityRange').addEventListener('input', (e) => {
  translationTextEffectIntensity = parseFloat(e.target.value);
  document.getElementById('translationTextEffectIntensityValue').textContent = translationTextEffectIntensity.toFixed(1);
  redrawPreviewFrame();
});

document.getElementById('translationMotionEffectSelect').addEventListener('change', (e) => {
  translationMotionEffect = e.target.value;
  redrawPreviewFrame();
});

document.getElementById('translationMotionIntensityRange').addEventListener('input', (e) => {
  translationMotionIntensity = parseFloat(e.target.value);
  document.getElementById('translationMotionIntensityValue').textContent = translationMotionIntensity.toFixed(1);
  redrawPreviewFrame();
});

// ============ الشعار والتذييل (v30) ============
function ensureDisplayFont(family) {
  const name = String(family || 'Cairo').trim() || 'Cairo';
  try { if (typeof ensureGoogleFont === 'function') ensureGoogleFont(name); } catch (e) {}
  try {
    if (document.fonts && typeof document.fonts.load === 'function') {
      document.fonts.load(`700 40px "${name}"`).catch(() => {}).then(() => {
        try { redrawPreviewFrame(); } catch (err) {}
      });
    }
  } catch (e) {}
}

function syncLogoPreviewUI() {
  const dot = document.getElementById('logoPreviewDot');
  const nameEl = document.getElementById('logoPreviewName');
  const clearBtn = document.getElementById('clearLogoBtn');
  const hasImg = Boolean(logoImage && (logoImage.naturalWidth || logoImage.width));
  if (dot) {
    dot.style.backgroundImage = hasImg && logoObjectUrl ? `url("${logoObjectUrl}")` : '';
    if (!hasImg) dot.textContent = '🕌';
    else dot.textContent = '';
  }
  if (nameEl) nameEl.textContent = hasImg ? 'تم رفع الشعار ✅' : 'بدون شعار';
  if (clearBtn) clearBtn.style.display = hasImg ? 'block' : 'none';
}

function revokeLogoObjectUrl() {
  if (logoObjectUrl) { try { URL.revokeObjectURL(logoObjectUrl); } catch (e) {} logoObjectUrl = null; }
}

document.getElementById('logoUpload').addEventListener('change', (e) => {
  const file = e.target.files ? e.target.files[0] : null;
  if (!file) return;
  if (!file.type || !file.type.startsWith('image/')) { setStatus('❌ ملف الشعار يجب أن يكون صورة.', 'error'); e.target.value = ''; return; }
  if (file.size > 10 * 1024 * 1024) { setStatus('❌ حجم الشعار أكبر من 10MB.', 'error'); e.target.value = ''; return; }
  revokeLogoObjectUrl();
  logoObjectUrl = URL.createObjectURL(file);
  const img = new Image();
  img.onload = () => { logoImage = img; syncLogoPreviewUI(); redrawPreviewFrame(); };
  img.onerror = () => { setStatus('❌ تعذر قراءة صورة الشعار.', 'error'); revokeLogoObjectUrl(); e.target.value = ''; };
  img.src = logoObjectUrl;
});

document.getElementById('clearLogoBtn').addEventListener('click', () => {
  logoImage = null;
  revokeLogoObjectUrl();
  document.getElementById('logoUpload').value = '';
  syncLogoPreviewUI();
  redrawPreviewFrame();
});

document.getElementById('logoSizeRange').addEventListener('input', (e) => {
  logoSizePct = Math.max(4, Math.min(25, Number(e.target.value) || 12));
  document.getElementById('logoSizeValue').textContent = Math.round(logoSizePct);
  redrawPreviewFrame();
});

document.getElementById('logoPositionSelect').addEventListener('change', (e) => {
  logoPosition = e.target.value || 'bottom-right';
  redrawPreviewFrame();
});

document.getElementById('logoOpacityRange').addEventListener('input', (e) => {
  logoOpacity = Math.max(0, Math.min(100, Number(e.target.value) || 0));
  document.getElementById('logoOpacityValue').textContent = Math.round(logoOpacity);
  redrawPreviewFrame();
});

document.getElementById('logoBorderWidthRange').addEventListener('input', (e) => {
  logoBorderWidth = Math.max(0, Math.min(10, Number(e.target.value) || 0));
  document.getElementById('logoBorderWidthValue').textContent = Number(logoBorderWidth);
  redrawPreviewFrame();
});

document.getElementById('logoBorderColorPicker').addEventListener('input', (e) => {
  logoBorderColor = e.target.value;
  redrawPreviewFrame();
});

document.getElementById('logoNameInput').addEventListener('input', (e) => {
  logoName = e.target.value;
  redrawPreviewFrame();
});

document.getElementById('logoNameFontSelect').addEventListener('change', (e) => {
  logoNameFont = e.target.value || 'Cairo';
  ensureDisplayFont(logoNameFont);
  redrawPreviewFrame();
});

document.getElementById('logoNameSizeRange').addEventListener('input', (e) => {
  logoNameSize = Math.max(10, Math.min(60, Number(e.target.value) || 28));
  document.getElementById('logoNameSizeValue').textContent = Math.round(logoNameSize);
  redrawPreviewFrame();
});

document.getElementById('logoNameGapRange').addEventListener('input', (e) => {
  logoNameGap = Math.max(0, Math.min(60, Number(e.target.value) || 0));
  document.getElementById('logoNameGapValue').textContent = Math.round(logoNameGap);
  redrawPreviewFrame();
});

document.getElementById('logoNameOpacityRange').addEventListener('input', (e) => {
  logoNameOpacity = Math.max(0, Math.min(100, Number(e.target.value) || 0));
  document.getElementById('logoNameOpacityValue').textContent = Math.round(logoNameOpacity);
  redrawPreviewFrame();
});

document.getElementById('logoNameColorPicker').addEventListener('input', (e) => {
  logoNameColor = e.target.value;
  redrawPreviewFrame();
});

document.getElementById('footerTextInput').addEventListener('input', (e) => {
  footerText = e.target.value;
  redrawPreviewFrame();
});

document.getElementById('footerFontSelect').addEventListener('change', (e) => {
  footerFont = e.target.value || 'Cairo';
  ensureDisplayFont(footerFont);
  redrawPreviewFrame();
});

document.getElementById('footerSizeRange').addEventListener('input', (e) => {
  footerSize = Math.max(10, Math.min(80, Number(e.target.value) || 44));
  document.getElementById('footerSizeValue').textContent = Math.round(footerSize);
  redrawPreviewFrame();
});

document.getElementById('footerOpacityRange').addEventListener('input', (e) => {
  footerOpacity = Math.max(0, Math.min(100, Number(e.target.value) || 0));
  document.getElementById('footerOpacityValue').textContent = Math.round(footerOpacity);
  redrawPreviewFrame();
});

document.getElementById('footerColorPicker').addEventListener('input', (e) => {
  footerColor = e.target.value;
  redrawPreviewFrame();
});

// ============ تأثيرات دخول/بصري/حركي للشعار والتذييل (v31 — نفس قوائم الآيات) ============
document.getElementById('logoTransitionSelect').addEventListener('change', (e) => {
  logoTransitionEffect = e.target.value;
  redrawPreviewFrame();
});

document.getElementById('logoTextEffectSelect').addEventListener('change', (e) => {
  logoTextEffect = e.target.value;
  redrawPreviewFrame();
});

document.getElementById('logoMotionEffectSelect').addEventListener('change', (e) => {
  logoMotionEffect = e.target.value;
  redrawPreviewFrame();
});

document.getElementById('footerTransitionSelect').addEventListener('change', (e) => {
  footerTransitionEffect = e.target.value;
  redrawPreviewFrame();
});

document.getElementById('footerTextEffectSelect').addEventListener('change', (e) => {
  footerTextEffect = e.target.value;
  redrawPreviewFrame();
});

document.getElementById('footerMotionEffectSelect').addEventListener('change', (e) => {
  footerMotionEffect = e.target.value;
  redrawPreviewFrame();
});

// ============ أحداث التأثيرات الإضافية ============
document.getElementById('gradientEffectSelect').addEventListener('change', (e) => {
  gradientEffect = e.target.value;
  redrawPreviewFrame();
  scheduleProjectAutosave();
});

document.getElementById('particleEffectToggle').addEventListener('change', (e) => {
  particleEffectEnabled = e.target.checked;
  redrawPreviewFrame();
  scheduleProjectAutosave();
});

document.getElementById('vignetteEffectToggle').addEventListener('change', (e) => {
  vignetteEffectEnabled = e.target.checked;
  redrawPreviewFrame();
  scheduleProjectAutosave();
});


// ============ دالة تحديث التوقيت الذكي ============
function updateAyahTiming() {
  const sample = currentAyahs[currentAyahIndex] || currentAyahs[0];
  const duration = sample && typeof getAyahSyncDurationMs === 'function'
    ? getAyahSyncDurationMs(sample)
    : Math.max(1000, (Number(ayahDisplayDuration) || 5000) * Math.max(.5, adaptiveFactor));
  const seconds = Math.max(1, Math.min(30, duration / 1000));
  const range = document.getElementById('durationRange');
  const value = document.getElementById('durationValue');
  if (range) range.value = seconds;
  if (value) value.textContent = seconds.toFixed(1);
}

document.getElementById('translationSelect').addEventListener('change', (e) => {
  const newKey = e.target.value;
  if (fullSurahData && surahNumberCurrent) {
    translationKey = newKey;
    if (newKey) {
      invalidateAsyncRequest('translation');
      const translationRequest = beginAsyncRequest('translation');
      fetchTranslations(surahNumberCurrent, newKey, translationRequest).then(() => renderAyahsList());
    } else {
      translationsData = {};
      document.getElementById('translationStatus').textContent = '';
      renderAyahsList();
    }
  }
});

document.getElementById('tafsirToggle').addEventListener('change', (e) => {
  tafsirEnabled = e.target.checked;
  if (fullSurahData && surahNumberCurrent) {
    if (tafsirEnabled) {
      invalidateAsyncRequest('tafsir');
      const tafsirRequest = beginAsyncRequest('tafsir');
      fetchTafsirMukhtasar(surahNumberCurrent, tafsirRequest).then(() => renderAyahsList());
    } else {
      tafsirData = {};
      document.getElementById('tafsirStatus').textContent = '';
      renderAyahsList();
    }
  }
});

// ============ أحداث لوحة الخطوط ============
function updateFontSettingsFromUI() {
  let chosenFamily = document.getElementById('fontFamilySelect').value;
  // حارس رواية ورش: منع اختيار خط برسم حفص يدوياً (قد يأتي من مشروع قديم مستعاد).
  if (typeof isFontAllowedForRiwayah === 'function' && !isFontAllowedForRiwayah(chosenFamily, currentRiwayah)) {
    chosenFamily = 'auto';
    document.getElementById('fontFamilySelect').value = 'auto';
    setStatus('⚠️ هذا الخط برسم حفص ولا يصلح لرواية ورش — تمت العودة لخط ورش الرسمي (Warsh10).', 'error');
  }
  fontSettings.family = chosenFamily;
  ensureGoogleFont(fontSettings.family);
  fontSettings.size = parseInt(document.getElementById('fontSizeRange').value);
  fontSettings.color = document.getElementById('fontColorPicker').value;
  textColor = fontSettings.color;
  const textColorEl = document.getElementById('textColorPicker');
  if (textColorEl) textColorEl.value = textColor;
  fontSettings.weight = parseInt(document.getElementById('fontWeightSelect').value);
  fontSettings.lineHeight = parseFloat(document.getElementById('lineHeightRange').value);
  fontSettings.bgColor = document.getElementById('fontBgColorPicker').value;
  fontSettings.bgOpacity = parseInt(document.getElementById('fontBgOpacityRange').value);
  fontSettings.borderColor = document.getElementById('fontBorderColorPicker').value;
  fontSettings.borderWidth = parseFloat(document.getElementById('fontBorderWidthRange').value);
  fontSettings.borderRadius = parseInt(document.getElementById('fontBorderRadiusRange').value);
  fontSettings.shadow = document.getElementById('fontShadowSelect').value;
  applyFontSettings();
  // رسم الإطار عند تغيير إعدادات الخط حتى لو كانت المعاينة معطلة
  if (!previewLoopRunning && currentAyahs.length > 0) {
    setTimeout(() => drawCurrentFrame(), 50);
  }
}

const fontControlIds = [
  'fontFamilySelect', 'fontSizeRange', 'fontColorPicker', 'fontWeightSelect',
  'lineHeightRange', 'fontBgColorPicker', 'fontBgOpacityRange',
  'fontBorderColorPicker', 'fontBorderWidthRange', 'fontBorderRadiusRange', 'fontShadowSelect'
];
fontControlIds.forEach(id => {
  const el = document.getElementById(id);
  if (el) {
    el.addEventListener('input', updateFontSettingsFromUI);
    el.addEventListener('change', updateFontSettingsFromUI);
  }
});

document.getElementById('fontSizeRange').addEventListener('input', (e) => {
  document.getElementById('fontSizeValue').textContent = e.target.value;
});
document.getElementById('lineHeightRange').addEventListener('input', (e) => {
  document.getElementById('lineHeightValue').textContent = e.target.value;
});
document.getElementById('fontBgOpacityRange').addEventListener('input', (e) => {
  document.getElementById('fontBgOpacityValue').textContent = e.target.value;
});
document.getElementById('fontBorderWidthRange').addEventListener('input', (e) => {
  document.getElementById('fontBorderWidthValue').textContent = e.target.value;
});
document.getElementById('fontBorderRadiusRange').addEventListener('input', (e) => {
  document.getElementById('fontBorderRadiusValue').textContent = e.target.value;
});

document.getElementById('resetFontBtn').addEventListener('click', () => {
  fontSettings = {
    family: 'auto', size: 68, color: '#ffffff', weight: 400, lineHeight: 2.2,
    bgColor: '#000000', bgOpacity: 0, borderColor: '#d4af37', borderWidth: 0,
    borderRadius: 8, shadow: 'medium'
  };
  document.getElementById('fontFamilySelect').value = 'auto';
  document.getElementById('fontSizeRange').value = 68;
  document.getElementById('fontSizeValue').textContent = '68';
  document.getElementById('fontColorPicker').value = '#ffffff';
  const deadTextColorEl = document.getElementById('textColorPicker');
  if (deadTextColorEl) deadTextColorEl.value = '#ffffff'; // v24: العنصر أُزيل مع القسم — حماية.
  textColor = '#ffffff';
  document.getElementById('fontWeightSelect').value = '400';
  document.getElementById('lineHeightRange').value = 2.2;
  document.getElementById('lineHeightValue').textContent = '2.2';
  document.getElementById('fontBgColorPicker').value = '#000000';
  document.getElementById('fontBgOpacityRange').value = 0;
  document.getElementById('fontBgOpacityValue').textContent = '0';
  document.getElementById('fontBorderColorPicker').value = '#d4af37';
  document.getElementById('fontBorderWidthRange').value = 0;
  document.getElementById('fontBorderWidthValue').textContent = '0';
  document.getElementById('fontBorderRadiusRange').value = 8;
  document.getElementById('fontBorderRadiusValue').textContent = '8';
  document.getElementById('fontShadowSelect').value = 'medium';
  refreshFontFamilyOptions();
  applyFontSettings();
  setStatus('↺ تم إعادة تعيين إعدادات الخط', 'success');
});

// ============ أحداث لوحة خطوط الترجمة والتفسير ============
function updateTransFontSettingsFromUI() {
  transFontSettings.family = document.getElementById('transFontFamilySelect').value;
  ensureGoogleFont(transFontSettings.family);
  transFontSettings.size = parseInt(document.getElementById('transFontSizeRange').value);
  transFontSettings.color = document.getElementById('transFontColorPicker').value;
  transFontSettings.weight = parseInt(document.getElementById('transFontWeightSelect').value);
  transFontSettings.lineHeight = parseFloat(document.getElementById('transLineHeightRange').value);
  transFontSettings.bgColor = document.getElementById('transFontBgColorPicker').value;
  transFontSettings.bgOpacity = parseInt(document.getElementById('transFontBgOpacityRange').value);
  transFontSettings.borderColor = document.getElementById('transFontBorderColorPicker').value;
  transFontSettings.borderWidth = parseFloat(document.getElementById('transFontBorderWidthRange').value);
  transFontSettings.borderRadius = parseInt(document.getElementById('transFontBorderRadiusRange').value);
  transFontSettings.shadow = document.getElementById('transFontShadowSelect').value;
  applyTransFontSettings();
  // رسم الإطار عند تغيير إعدادات خط الترجمة حتى لو كانت المعاينة معطلة
  if (!previewLoopRunning && currentAyahs.length > 0) {
    setTimeout(() => drawCurrentFrame(), 50);
  }
}

const transFontControlIds = [
  'transFontFamilySelect', 'transFontSizeRange', 'transFontColorPicker', 'transFontWeightSelect',
  'transLineHeightRange', 'transFontBgColorPicker', 'transFontBgOpacityRange',
  'transFontBorderColorPicker', 'transFontBorderWidthRange', 'transFontBorderRadiusRange', 'transFontShadowSelect'
];
transFontControlIds.forEach(id => {
  const el = document.getElementById(id);
  if (el) {
    el.addEventListener('input', updateTransFontSettingsFromUI);
    el.addEventListener('change', updateTransFontSettingsFromUI);
  }
});

document.getElementById('transFontSizeRange').addEventListener('input', (e) => {
  document.getElementById('transFontSizeValue').textContent = e.target.value;
});
document.getElementById('transLineHeightRange').addEventListener('input', (e) => {
  document.getElementById('transLineHeightValue').textContent = e.target.value;
});
document.getElementById('transFontBgOpacityRange').addEventListener('input', (e) => {
  document.getElementById('transFontBgOpacityValue').textContent = e.target.value;
});
document.getElementById('transFontBorderWidthRange').addEventListener('input', (e) => {
  document.getElementById('transFontBorderWidthValue').textContent = e.target.value;
});
document.getElementById('transFontBorderRadiusRange').addEventListener('input', (e) => {
  document.getElementById('transFontBorderRadiusValue').textContent = e.target.value;
});

document.getElementById('resetTransFontBtn').addEventListener('click', () => {
  transFontSettings = {
    family: 'Cairo', size: 48, color: '#a3d0ff', weight: 400, lineHeight: 1.5,
    bgColor: '#000000', bgOpacity: 0, borderColor: '#d4af37', borderWidth: 0,
    borderRadius: 8, shadow: 'none'
  };
  document.getElementById('transFontFamilySelect').value = 'Cairo';
  document.getElementById('transFontSizeRange').value = 48;
  document.getElementById('transFontSizeValue').textContent = '48';
  document.getElementById('transFontColorPicker').value = '#a3d0ff';
  document.getElementById('transFontWeightSelect').value = '400';
  document.getElementById('transLineHeightRange').value = 1.5;
  document.getElementById('transLineHeightValue').textContent = '1.5';
  document.getElementById('transFontBgColorPicker').value = '#000000';
  document.getElementById('transFontBgOpacityRange').value = 0;
  document.getElementById('transFontBgOpacityValue').textContent = '0';
  document.getElementById('transFontBorderColorPicker').value = '#d4af37';
  document.getElementById('transFontBorderWidthRange').value = 0;
  document.getElementById('transFontBorderWidthValue').textContent = '0';
  document.getElementById('transFontBorderRadiusRange').value = 8;
  document.getElementById('transFontBorderRadiusValue').textContent = '8';
  document.getElementById('transFontShadowSelect').value = 'none';
  applyTransFontSettings();
  setStatus('↺ تم إعادة تعيين إعدادات خط الترجمة والتفسير', 'success');
});

async function startFinalExport() {
  if (finalExportInProgress) return;
  if (!currentAyahs || currentAyahs.length === 0) {
    setStatus('⚠️ الرجاء جلب الآيات أولاً قبل التصدير', 'error');
    return;
  }
  const btn = document.getElementById('finalExportBtn');
  const progress = document.getElementById('finalExportProgress');
  const status = document.getElementById('finalExportStatus');
  finalExportInProgress = true;
  if (btn) { btn.disabled = true; btn.textContent = '⏳ جاري تجهيز التصدير...'; }
  if (typeof prepareReciterAudio !== 'function' || typeof prepareRange !== 'function' || typeof startRecording !== 'function') {
    setStatus('⚠️ تم تحميل نسخة قديمة مخزنة تمنع التصدير. حدّث الصفحة بقوة Ctrl+Shift+R ثم أعد المحاولة.', 'error');
    if (status) status.textContent = '⚠️ نسخة قديمة مخزنة — حدّث الصفحة بقوة Ctrl+Shift+R.';
    finalExportInProgress = false;
    if (btn) { btn.disabled = false; btn.textContent = '🚀 تصدير'; }
    if (progress) progress.value = 0;
    return;
  }
  if (progress) progress.value = 5;
  if (status) status.textContent = '🔎 يتم التحقق من الآيات ثم بدء التصدير حسب النوع المختار...';
  try {
    const mode = exportModes[currentExportMode] ? currentExportMode : 'full';
    const needsAudio = exportModes[mode]?.needsAudio !== false;
    const needsFonts = exportModes[mode]?.needsVideo !== false;
    if (needsFonts) {
      if (status) status.textContent = '🔤 جاري التأكد من جاهزية خط المصحف (KFGQPC) قبل التصدير...';
      try { if (typeof ensureQuranFontsLoaded === 'function') await ensureQuranFontsLoaded(); } catch (e) {}
    }
    if (!prepareRange()) throw new Error('تعذر تجهيز نطاق الآيات المحدد.');
    if (needsAudio) {
      if (audioSourceMode === 'reciter') {
        const ready = await prepareReciterAudio(false);
        if (!ready || !validateSelectedAyahAudio()) {
          throw new Error('تعذر تجهيز الصوت المختار لجميع الآيات.');
        }
      } else if (!manualAudioUrl) {
        throw new Error('يجب رفع ملف صوتي يدوي قبل بدء التصدير.');
      }
    }
    if (progress) progress.value = 12;
    if (status) status.textContent = `${exportModes[mode]?.icon || '🎬'} التصدير ${exportModes[mode]?.name || ''} • ${mode === 'audio-only' ? 'صوت فقط' : exportQualities[currentExportQuality].label}`;
    await startRecording();
  } catch (e) {
    finalExportInProgress = false;
    restoreExportCanvasResolution();
    if (progress) progress.value = 0;
    if (btn) { btn.disabled = false; btn.textContent = '🚀 تصدير'; }
    if (status) status.textContent = '❌ ' + (e.message || e);
    setStatus('❌ فشل التصدير النهائي: ' + (e.message || e), 'error');
  }
}

// ============ الأزرار الرئيسية ============
document.getElementById('playPauseBtn').addEventListener('click', () => {
  if (currentAyahs.length === 0) return;
  if (!isPlaying) {
    startPreview();
  } else if (isPaused) {
    isPaused = false;
    // v13: إزاحة الساعتين بمدة التوقف — زمن الإيقاف لا يُحتسب من مدة العرض ولا نافذة الترجمة.
    if (pausedAt) {
      const pausedFor = Date.now() - pausedAt;
      ayahDisplayStart += pausedFor;
      ayahTransitionStart += pausedFor;
      pausedAt = 0;
    }
    if (audioStarted && ((audioSourceMode === 'upload' && manualAudioUrl) || currentAyahs[currentAyahIndex]?.audio)) {
      audio.play().catch(() => {});
    }
    const elapsed = Date.now() - ayahDisplayStart;
    clearAyahTimer();
    const remaining = ayahDisplayDuration - elapsed;
    if (remaining <= 0) {
      if (audioEnded) advanceToNextAyah();
      else {
        audio.onended = () => { audioEnded = true; advanceToNextAyah(); };
      }
    } else {
      ayahTimerHandle = setTimeout(() => {
        if (audioEnded) advanceToNextAyah();
        else {
          audio.onended = () => {
            audioEnded = true;
            const el2 = Date.now() - ayahDisplayStart;
            if (el2 >= ayahDisplayDuration) advanceToNextAyah();
            else ayahTimerHandle = setTimeout(advanceToNextAyah, ayahDisplayDuration - el2);
          };
        }
      }, remaining);
    }
    updatePlayPauseUI();
  } else {
    isPaused = true;
    pausedAt = Date.now();
    audio.pause();
    clearAyahTimer();
    stopPlayerUiTimer();
    if (!autoPreviewEnabled && !finalExportInProgress) stopPreviewLoop();
    updatePlayPauseUI();
  }
});

document.getElementById('stopAllBtn').addEventListener('click', () => {
  audio.pause();
  try { audio.currentTime = 0; } catch (e) {}
  isPlaying = false;
  isPaused = false;
  pausedAt = 0;
  stopPlayerUiTimer();
  if (!autoPreviewEnabled && !finalExportInProgress) stopPreviewLoop();
  currentAyahIndex = 0;
  ayahDisplayStart = Date.now();
  ayahTransitionStart = Date.now();
  clearAyahTimer();
  updatePlayPauseUI();
  setStatus('⏹️ تم التوقيف النهائي', '');
});

document.getElementById('rewindBtn').addEventListener('click', () => {
  if (currentAyahs.length === 0) return;
  if (currentAyahIndex > 0) {
    currentAyahIndex--;
    ayahTransitionStart = Date.now();
    ayahDisplayStart = Date.now();
    if (isPlaying) playCurrentAyah();
  }
});

document.getElementById('forwardBtn').addEventListener('click', () => {
  if (currentAyahs.length === 0) return;
  if (currentAyahIndex < currentAyahs.length - 1) {
    currentAyahIndex++;
    ayahTransitionStart = Date.now();
    ayahDisplayStart = Date.now();
    if (isPlaying) playCurrentAyah();
  }
});

document.getElementById('slowBtn').addEventListener('click', () => {
  playbackSpeed = Math.max(0.25, playbackSpeed - 0.25);
  audio.playbackRate = playbackSpeed;
  document.getElementById('speedDisplay').textContent = playbackSpeed.toFixed(1) + 'x';
});

document.getElementById('fastBtn').addEventListener('click', () => {
  playbackSpeed = Math.min(3.0, playbackSpeed + 0.25);
  audio.playbackRate = playbackSpeed;
  document.getElementById('speedDisplay').textContent = playbackSpeed.toFixed(1) + 'x';
});

function movePlayerBySeconds(seconds) {
  if (!currentAyahs.length) return;
  const total = getTimelineTotalDurationMs() / 1000;
  let current = 0;
  for (let i = 0; i < currentAyahIndex; i++) current += getAyahSyncDurationMs(currentAyahs[i]) / 1000;
  current += isPlaying ? Math.max(0, (Date.now() - ayahDisplayStart) / 1000) : 0;
  const target = Math.max(0, Math.min(total, current + seconds));
  const targetIndex = currentAyahs.reduce((index, ayah, i) => {
    const start = currentAyahs.slice(0, i).reduce((sum, item) => sum + getAyahSyncDurationMs(item) / 1000, 0);
    return target >= start ? i : index;
  }, 0);
  currentAyahIndex = targetIndex;
  ayahTransitionStart = Date.now();
  ayahDisplayStart = Date.now();
  if (isPlaying) playCurrentAyah();
  else drawCurrentFrame();
  updatePlayerTime();
}

document.getElementById('skipBackBtn')?.addEventListener('click', () => movePlayerBySeconds(-10));
document.getElementById('skipForwardBtn')?.addEventListener('click', () => movePlayerBySeconds(10));

const volumeRange = document.getElementById('volumeRange');
const muteBtn = document.getElementById('muteBtn');
const volumeValue = document.getElementById('volumeValue');
function syncVolumeUI() {
  const volume = audio.muted ? 0 : audio.volume;
  if (volumeRange) {
    volumeRange.value = volume;
    volumeRange.style.setProperty('--vol', `${Math.round(volume * 100)}%`);
  }
  if (volumeValue) volumeValue.textContent = `${Math.round(volume * 100)}%`;
  if (muteBtn) {
    // v6: أيقونات SVG تُبدَّل عبر data-state (CSS) بدل الإيموجي.
    const st = audio.muted || audio.volume === 0 ? 'muted' : audio.volume < .5 ? 'low' : 'loud';
    muteBtn.dataset.state = st;
    muteBtn.setAttribute('aria-label', audio.muted ? 'إلغاء كتم الصوت' : 'كتم الصوت');
  }
}
volumeRange?.addEventListener('input', event => {
  audio.volume = Number(event.target.value);
  audio.muted = audio.volume === 0;
  syncVolumeUI();
});
muteBtn?.addEventListener('click', () => {
  audio.muted = !audio.muted;
  syncVolumeUI();
});
syncVolumeUI();

document.getElementById('playerProgress').addEventListener('click', (e) => {
  const rect = e.currentTarget.getBoundingClientRect();
  const pct = (e.clientX - rect.left) / rect.width;
  const targetIndex = Math.floor(pct * currentAyahs.length);
  if (targetIndex >= 0 && targetIndex < currentAyahs.length) {
    currentAyahIndex = targetIndex;
    ayahTransitionStart = Date.now();
    ayahDisplayStart = Date.now();
    if (isPlaying) playCurrentAyah();
  }
});

document.getElementById('playerProgress').addEventListener('keydown', event => {
  if (!['ArrowLeft', 'ArrowRight', 'Home', 'End'].includes(event.key)) return;
  event.preventDefault();
  const current = Number(document.getElementById('playerProgress').getAttribute('aria-valuenow')) || 0;
  const next = event.key === 'Home' ? 0 : event.key === 'End' ? 100 : Math.max(0, Math.min(100, current + (event.key === 'ArrowLeft' ? -5 : 5)));
  const targetIndex = Math.min(currentAyahs.length - 1, Math.max(0, Math.floor((next / 100) * currentAyahs.length)));
  if (targetIndex >= 0) {
    currentAyahIndex = targetIndex;
    ayahTransitionStart = Date.now();
    ayahDisplayStart = Date.now();
    if (isPlaying) playCurrentAyah(); else drawCurrentFrame();
    updatePlayerTime();
  }
});


// ============ الوضع الداكن ============
function initializeDarkMode() {
  const btn = document.getElementById('darkModeToggle');
  if (!btn) return;
  const storageKey = 'quranStudio.darkMode.v1';
  let enabled = false;
  try { enabled = localStorage.getItem(storageKey) === '1'; } catch (e) {}

  const applyDarkMode = (isDark) => {
    document.body.classList.toggle('dark-mode', isDark);
    btn.textContent = isDark ? '☀️' : '🌙';
    btn.title = isDark ? 'التبديل إلى الوضع الفاتح' : 'التبديل إلى الوضع الداكن';
  };

  applyDarkMode(enabled);
  btn.addEventListener('click', () => {
    enabled = !enabled;
    applyDarkMode(enabled);
    try { localStorage.setItem(storageKey, enabled ? '1' : '0'); } catch (e) {}
  });
}

// ============ لون الصفحة (سمات ملكية v7) ============
function initializePageTheme() {
  const storageKey = 'quranStudio.pageTheme.v1';
  const swatches = Array.from(document.querySelectorAll('.theme-swatch'));
  if (!swatches.length) return;
  const valid = new Set(swatches.map(b => b.dataset.pageTheme));
  let current = 'gold';
  try {
    const saved = localStorage.getItem(storageKey);
    if (saved && valid.has(saved)) current = saved;
  } catch (e) {}

  const applyPageTheme = (name) => {
    current = valid.has(name) ? name : 'gold';
    if (current === 'gold') document.body.removeAttribute('data-page-theme');
    else document.body.setAttribute('data-page-theme', current);
    swatches.forEach(b => b.setAttribute('aria-pressed', b.dataset.pageTheme === current ? 'true' : 'false'));
  };

  applyPageTheme(current);
  swatches.forEach(btn => btn.addEventListener('click', () => {
    applyPageTheme(btn.dataset.pageTheme);
    try { localStorage.setItem(storageKey, current); } catch (e) {}
  }));
}

function initializeSettings() {
  const reducedMotionKey = 'quranStudio.reducedMotion.v1';
  const autoPreviewKey = 'quranStudio.autoPreview.v1';
  const reducedMotionToggle = document.getElementById('reducedMotionToggle');
  const autoPreviewToggle = document.getElementById('autoPreviewToggle');

  // v29: إصلاح جذري — كان التقليل مفعّلاً افتراضياً للجميع (فيجمّد كل حركات النص
  // بينما الخلفية تتحرك). الآن: حر ما لم يُخزَّن تفضيل، ويُحترم خيار نظام التشغيل.
  let reducedMotion = false;
  let autoPreview = false;
  try {
    const stored = localStorage.getItem(reducedMotionKey);
    reducedMotion = stored == null
      ? (typeof matchMedia === 'function' && matchMedia('(prefers-reduced-motion: reduce)').matches)
      : stored !== '0';
    autoPreview = localStorage.getItem(autoPreviewKey) === '1';
  } catch (e) { reducedMotion = false; }

  if (reducedMotionToggle) {
    reducedMotionToggle.checked = reducedMotion;
    document.body.classList.toggle('reduce-motion', reducedMotion);
    reducedMotionToggle.addEventListener('change', event => {
      const enabled = event.target.checked;
      document.body.classList.toggle('reduce-motion', enabled);
      try { localStorage.setItem(reducedMotionKey, enabled ? '1' : '0'); } catch (e) {}
    });
  }

  if (autoPreviewToggle) {
    autoPreviewToggle.checked = autoPreview;
    autoPreviewEnabled = autoPreview;
    if (!autoPreview) stopPreviewLoop();
    autoPreviewToggle.addEventListener('change', event => {
      const enabled = event.target.checked;
      try { localStorage.setItem(autoPreviewKey, enabled ? '1' : '0'); } catch (e) {}
      autoPreviewEnabled = enabled;
      if (enabled) startPreviewLoop(); else if (!isPlaying && !finalExportInProgress) stopPreviewLoop();
    });
  }
}

function initializeAccessibleLabels() {
  document.querySelectorAll('label:not([for])').forEach(label => {
    const scope = label.closest('.control-group, .font-control-group, .range-label, .checkbox-row');
    const control = scope?.querySelector('input, select, textarea') || scope?.parentElement?.querySelector('input, select, textarea');
    if (control?.id) label.htmlFor = control.id;
  });
}

// تهيئة محمية: ملف ميت واحد لا يُسقط البقية (خلط نسخ الكاش).
[
  ['initializeAyahTimeline', () => initializeAyahTimeline()],
  ['initializeProjectManager', () => initializeProjectManager()],
  ['initializeDarkMode', () => initializeDarkMode()],
  ['initializePageTheme', () => initializePageTheme()],
  ['initializeSettings', () => initializeSettings()],
  ['initializeAccessibleLabels', () => initializeAccessibleLabels()]
].forEach(([label, fn]) => {
  try { fn(); } catch (e) { console.error('Init failed:', label, e); }
});

