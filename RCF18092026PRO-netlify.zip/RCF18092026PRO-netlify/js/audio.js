// ============ الصوت ============
let audioCtx = null, audioSourceNode = null, audioDestNode = null;
function getAudioGraph() {
  if (!audioCtx) {
    const AC = window.AudioContext || window.webkitAudioContext;
    audio.crossOrigin = 'anonymous';
    audioCtx = new AC();
    audioSourceNode = audioCtx.createMediaElementSource(audio);
    audioDestNode = audioCtx.createMediaStreamDestination();
    audioSourceNode.connect(audioDestNode);
    audioSourceNode.connect(audioCtx.destination);
  }
  return { audioCtx, audioDestNode };
}

// ============ دوال مساعدة ============
function hexToRgba(hex, alpha) {
  if (!hex) return 'transparent';
  const h = hex.replace('#', '');
  const r = parseInt(h.substring(0, 2), 16);
  const g = parseInt(h.substring(2, 4), 16);
  const b = parseInt(h.substring(4, 6), 16);
  return `rgba(${r}, ${g}, ${b}, ${alpha})`;
}
// P2: حُذفت getShadowCSS الميتة — ظلال Canvas مرجعها الوحيد getTextShadow في canvas.js.

