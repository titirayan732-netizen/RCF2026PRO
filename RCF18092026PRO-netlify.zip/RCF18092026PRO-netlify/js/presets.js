// ============ المرحلة 3: مكتبة القوالب الاحترافية ============
const PRESET_CATEGORIES = {
  all: 'الكل',
  islamic: 'إسلامي',
  minimal: 'هادئ',
  cinematic: 'سينمائي',
  modern: 'حديث'
};

const presets = [
  { id:'classic-gold', category:'islamic', name:'كلاسيكي ذهبي', icon:'👑', desc:'ليلي فاخر + إطار ملكي', apply:()=>applyDesignPreset({bg:0, frame:7, frameColor:'#d4af37', frameOpacity:1, textColor:'#ffffff', contrast:35, glow:true, transition:'fade', textEffect:'glow', gradient:'golden', vignette:true}) },
  { id:'emerald-mihrab', category:'islamic', name:'المحراب الزمردي', icon:'🕌', desc:'زمرد + محراب + حركة ناعمة', apply:()=>applyDesignPreset({bg:2, frame:3, frameColor:'#ffd700', frameOpacity:.9, textColor:'#ffffff', contrast:45, glow:true, transition:'slideUp', textEffect:'shadow', bgMotion:'pulse', bgSpeed:1, vignette:true}) },
  { id:'arabesque-night', category:'islamic', name:'أرابيسك وردي', icon:'🌸', desc:'وردي ديناميكي + عمق ضوئي ناعم', apply:()=>applyDesignPreset({bg:0, frame:2, frameColor:'#ff7eb6', frameOpacity:.9, textColor:'#fff5fb', contrast:42, glow:true, transition:'slideFade', textEffect:'glow', gradient:'neon', bgMotion:'pulse', bgSpeed:1.2, vignette:true}) },
  { id:'minimal-white', category:'minimal', name:'نقاء هادئ', icon:'🤍', desc:'نص واضح بأقل قدر من المؤثرات', apply:()=>applyDesignPreset({bg:1, frame:0, frameColor:'#ffffff', frameOpacity:1, textColor:'#ffffff', contrast:55, glow:false, transition:'fade', textEffect:'none', gradient:'none', vignette:false}) },
  { id:'soft-dawn', category:'minimal', name:'شفق ناعم', icon:'🌅', desc:'ألوان هادئة + أرابيسك خفيف', apply:()=>applyDesignPreset({bg:5, frame:2, frameColor:'#f4e5a1', frameOpacity:.8, textColor:'#ffffff', contrast:40, glow:false, transition:'typewriter', textEffect:'shadow', vignette:false}) },
  { id:'cinema', category:'cinematic', name:'سينمائي', icon:'🎞️', desc:'تباين عميق + حركة سينمائية', apply:()=>applyDesignPreset({bg:4, frame:0, frameColor:'#d4af37', frameOpacity:1, textColor:'#ffffff', contrast:65, glow:true, transition:'zoom', textEffect:'shadow', bgMotion:'zoomEffect', bgSpeed:.8, vignette:true}) },
  { id:'teal-water', category:'cinematic', name:'شعلة برتقالية', icon:'🔥', desc:'برتقالي ناري + شعلة متحركة', apply:()=>applyDesignPreset({bg:7, frame:1, frameColor:'#ff9f43', frameOpacity:1, textColor:'#fff8ed', contrast:38, glow:true, transition:'slideSide', textEffect:'glow', gradient:'sunset', bgMotion:'fire', bgSpeed:1.1, vignette:true, particles:true}) },
  { id:'cosmic-modern', category:'modern', name:'كوني حديث', icon:'🌌', desc:'سديم كوني + تصميم عصري', apply:()=>applyDesignPreset({bg:4, frame:0, frameColor:'#d4af37', frameOpacity:1, textColor:'#ffffff', contrast:25, glow:true, transition:'zoom', textEffect:'gradient', gradient:'golden', bgMotion:'spiral', bgSpeed:.7, vignette:true, particles:true}) },
  { id:'royal-fire', category:'modern', name:'وهج ذهبي', icon:'🔥', desc:'ناري فاخر + توهج قوي', apply:()=>applyDesignPreset({bg:7, frame:7, frameColor:'#ffcc80', frameOpacity:.9, textColor:'#fff8e1', contrast:50, glow:true, transition:'fade', textEffect:'glow', gradient:'golden', vignette:true, particles:true}) },
  { id:'modern-ocean', category:'modern', name:'محيطي عصري', icon:'🌊', desc:'أزرق محيطي + حركة موجية للخلفية', apply:()=>applyDesignPreset({bg:1, frame:4, frameColor:'#9ad8ff', frameOpacity:.85, textColor:'#ffffff', contrast:38, glow:true, transition:'slideFade', textEffect:'glow', gradient:'ocean', bgMotion:'wave', bgSpeed:1.2, vignette:true}) }
];

function applyDesignPreset(config = {}) {
  // القالب يجب أن يكون "حزمة مكتملة" لا مجموعة تعديلات جزئية.
  // القيم غير الموجودة في القالب تعود للوضع المحايد حتى لا تتسرب إعدادات قالب سابق.
  const defaults = {
    bg: 0, frame: 0, frameColor: '#d4af37', frameOpacity: 1,
    textColor: '#ffffff', contrast: 35, glow: true,
    transition: 'fade', textEffect: 'none', textIntensity: 1,
    bgMotion: 'none', bgSpeed: 1, backgroundContrast: 50, backgroundSpeed: 1, gradient: 'none',
    particles: false, vignette: false
  };
  const c = { ...defaults, ...config };

  // القالب يملك خلفيته؛ لذلك لا نسمح لخلفية مخصصة سابقة بأن تطغى عليه.
  if (typeof revokeCustomBgObjectUrl === 'function') revokeCustomBgObjectUrl();
  customBgType = null;
  customBgImage = null;
  customBgVideo = null;
  const bgUpload = document.getElementById('bgUpload');
  if (bgUpload) bgUpload.value = '';
  const clearCustomBg = document.getElementById('clearCustomBg');
  if (clearCustomBg) clearCustomBg.style.display = 'none';
  if (typeof bgVideo !== 'undefined' && bgVideo) bgVideo.src = '';

  currentBgIndex = Number.isInteger(c.bg) ? c.bg : 0;
  frameIndex = Number.isInteger(c.frame) ? c.frame : 0;
  frameColor = c.frameColor;
  frameOpacity = Math.max(0, Math.min(1, Number(c.frameOpacity)));
  textColor = c.textColor;
  fontSettings.color = c.textColor;
  contrastLevel = Number(c.contrast);
  glowEnabled = Boolean(c.glow);
  transitionEffect = c.transition;
  quranTextEffect = c.textEffect;
  quranTextEffectIntensity = Number.isFinite(Number(c.textIntensity)) ? Number(c.textIntensity) : 1;
  bgMotionEffect = c.bgMotion;
  bgMotionSpeed = Math.max(0.1, Number(c.bgSpeed) || 1);
  dynamicBackgroundContrast = Math.max(0, Math.min(100, Number(c.backgroundContrast) || 50));
  dynamicBackgroundSpeed = Math.max(0.1, Math.min(3, Number(c.backgroundSpeed) || c.bgSpeed || 1));
  gradientEffect = c.gradient;
  particleEffectEnabled = Boolean(c.particles);
  vignetteEffectEnabled = Boolean(c.vignette);

  // مزامنة عناصر التحكم مع الحالة الفعلية للقالب.
  const setValue = (id, value) => {
    const el = document.getElementById(id);
    if (el && value !== undefined) el.value = String(value);
  };
  const setChecked = (id, value) => {
    const el = document.getElementById(id);
    if (el && value !== undefined) el.checked = Boolean(value);
  };
  setValue('effectSelect', transitionEffect);
  setValue('textColorPicker', textColor);
  setValue('contrastRange', contrastLevel);
  setChecked('glowToggle', glowEnabled);
  setValue('quranTextEffectSelect', quranTextEffect);
  setValue('quranTextEffectIntensityRange', quranTextEffectIntensity);
  setValue('bgMotionEffectSelect', bgMotionEffect);
  setValue('bgMotionSpeedRange', bgMotionSpeed);
  setValue('presetBackgroundContrastRange', dynamicBackgroundContrast);
  setValue('presetBackgroundSpeedRange', dynamicBackgroundSpeed);
  setValue('gradientEffectSelect', gradientEffect);
  setChecked('particleEffectToggle', particleEffectEnabled);
  setChecked('vignetteEffectToggle', vignetteEffectEnabled);

  const labels = {
    contrastValue: contrastLevel,
    quranTextEffectIntensityValue: quranTextEffectIntensity.toFixed(1),
    bgMotionSpeedValue: bgMotionSpeed.toFixed(1),
    presetBackgroundContrastValue: Math.round(dynamicBackgroundContrast),
    presetBackgroundSpeedValue: dynamicBackgroundSpeed.toFixed(1)
  };
  Object.entries(labels).forEach(([id, value]) => {
    const el = document.getElementById(id);
    if (el) el.textContent = value;
  });

  const previewPalettes = [
    ['#070d16', '#1a3a52'], ['#160d2d', '#4a148c'], ['#003b36', '#00695c'],
    ['#3e2723', '#8d6e63'], ['#080816', '#25254a'], ['#001a1a', '#003333'],
    ['#004d5e', '#00acc1'], ['#260808', '#7a2610']
  ];
  const palette = previewPalettes[Math.max(0, Math.min(previewPalettes.length - 1, currentBgIndex))];
  const screen = document.querySelector('.phone-screen');
  const frame = document.querySelector('.phone-frame');
  if (screen) {
    screen.style.setProperty('--preview-screen-bg', `linear-gradient(145deg, ${palette[0]}, ${palette[1]})`);
    screen.style.setProperty('--preview-accent', frameColor);
    screen.dataset.activePreset = activePresetId || '';
  }
  if (frame) {
    frame.style.setProperty('--preview-frame-bg', `linear-gradient(145deg, ${palette[0]}, #020304)`);
    frame.style.setProperty('--preview-accent', frameColor);
  }

  // تحديث المعاينة فورًا؛ سابقًا كان تطبيق القالب يغيّر الحالة فقط،
  // ثم لا يظهر التغيير على Canvas إلا بعد إجراء آخر.
  if (typeof updateExportPreview === 'function') updateExportPreview(currentExportProfile);
  if (typeof drawCurrentFrame === 'function') {
    if (currentAyahs.length) drawCurrentFrame();
    else if (typeof drawCanvasBackground === 'function' && typeof ctx !== 'undefined' && ctx) {
      ctx.save();
      drawCanvasBackground((Date.now() - startTime) / 1000);
      ctx.restore();
    }
  }
  if (typeof previewNeedsAnimation === 'function' && previewNeedsAnimation()) startPreviewLoop();
  else if (typeof stopPreviewLoop === 'function') stopPreviewLoop();

  // v19: معاينة ساكنة بعد القالب — تُرجع الساعة لما بعد الاكتمال وإلا ظهر الإطار شفافاً.
  ayahTransitionStart = Date.now();
  try {
    if (!previewLoopRunning && currentAyahs.length) {
      ayahTransitionStart = Date.now() - Math.max(Number(effectAnimationDuration) || 0, Number(translationAnimationDuration) || 0) - 60;
    }
  } catch (e) {}
  if (typeof scheduleProjectAutosave === 'function') scheduleProjectAutosave();
}

let activePresetCategory = 'all';
let activePresetId = null;

const presetPreviewThemes = {
  'classic-gold': ['#070d16','#1a3a52','#d4af37'], 'emerald-mihrab': ['#003b36','#00695c','#ffd700'],
  'arabesque-night': ['#2b0d22','#8e2f67','#ff7eb6'], 'minimal-white': ['#17202a','#52616b','#ffffff'],
  'soft-dawn': ['#3e2723','#8d6e63','#f4e5a1'], 'cinema': ['#080816','#25254a','#d4af37'],
  'teal-water': ['#3b0d05','#c2410c','#ff9f43'], 'cosmic-modern': ['#160d2d','#4a148c','#d4af37'],
  'royal-fire': ['#260808','#7a2610','#ffcc80'], 'modern-ocean': ['#004d5e','#00acc1','#9ad8ff']
};

function renderPresetThumbnail(canvasElement, preset) {
  const context = canvasElement.getContext('2d');
  const width = canvasElement.width = 360;
  const height = canvasElement.height = 520;
  const theme = presetPreviewThemes[preset.id] || ['#0a1929','#1a3a52','#d4af37'];
  const gradient = context.createLinearGradient(0,0,width,height);
  gradient.addColorStop(0, theme[0]); gradient.addColorStop(1, theme[1]);
  context.fillStyle = gradient; context.fillRect(0,0,width,height);
  context.strokeStyle = theme[2]; context.lineWidth = 5; context.strokeRect(16,16,width-32,height-32);
  context.fillStyle = theme[2]; context.textAlign = 'center'; context.direction = 'rtl';
  context.font = 'bold 22px Amiri, serif'; context.fillText('سورة الفاتحة', width/2, 72);
  context.fillStyle = '#ffffff'; context.font = '28px Amiri, serif';
  context.fillText('بِسْمِ اللَّهِ الرَّحْمَنِ', width/2, 190); context.fillText('الرَّحِيمِ', width/2, 235);
  context.fillStyle = 'rgba(255,255,255,.82)'; context.font = '15px Cairo, sans-serif';
  context.fillText('In the name of Allah, the Entirely Merciful', width/2, 330);
  context.fillStyle = theme[2]; context.font = 'bold 13px Cairo, sans-serif'; context.fillText(preset.name, width/2, 465);
}

function buildPresetToolbar() {
  const toolbar = document.getElementById('presetToolbar');
  if (!toolbar) return;
  toolbar.innerHTML = Object.entries(PRESET_CATEGORIES).map(([id, label]) =>
    `<button type="button" class="preset-filter ${id === activePresetCategory ? 'active' : ''}" data-preset-category="${id}">${label}</button>`
  ).join('');
}

function updatePresetCardSelection() {
  document.querySelectorAll('.preset-card').forEach(card => {
    const selected = card.dataset.presetId === activePresetId;
    card.classList.toggle('active-preset', selected);
    card.classList.toggle('preview-selected', selected);
  });
}

function buildPresets() {
  const grid = document.getElementById('presetsGrid');
  const toolbar = document.getElementById('presetToolbar');
  if (!grid || !toolbar) return;

  buildPresetToolbar();
  const visible = activePresetCategory === 'all' ? presets : presets.filter(p => p.category === activePresetCategory);

  // إعادة البناء تحدث فقط عند تغيير التصنيف/استعادة المشروع، وليس عند كل تطبيق لقالب.
  grid.innerHTML = visible.map(p => `
    <article class="preset-card ${activePresetId === p.id ? 'active-preset preview-selected' : ''}" data-preset-id="${p.id}" tabindex="0" role="button" aria-label="قالب ${p.name}">
      <canvas class="preset-preview-canvas" width="240" height="346" aria-label="معاينة ${p.name}"></canvas>
      <div class="preset-card-copy">
        <div class="preset-icon">${p.icon}</div>
        <div class="preset-name">${p.name}</div>
        <div class="preset-desc">${p.desc}</div>
        <span class="preset-tag">${PRESET_CATEGORIES[p.category]}</span>
      </div>
      <button type="button" class="preset-apply-btn" data-preset-apply="${p.id}">✅ تطبيق القالب</button>
    </article>`).join('');

  visible.forEach(p => {
    const canvasElement = grid.querySelector(`[data-preset-id="${p.id}"] .preset-preview-canvas`);
    if (canvasElement) renderPresetThumbnail(canvasElement, p);
  });
}

// أحداث مكتبة القوالب تُربط مرة واحدة باستخدام event delegation.
function initializePresetEvents() {
  const toolbar = document.getElementById('presetToolbar');
  const grid = document.getElementById('presetsGrid');
  if (!toolbar || !grid || grid.dataset.eventsReady === 'true') return;
  grid.dataset.eventsReady = 'true';

  toolbar.addEventListener('click', event => {
    const button = event.target.closest('[data-preset-category]');
    if (!button) return;
    activePresetCategory = button.dataset.presetCategory || 'all';
    buildPresets();
  });

  const applyPreset = id => {
    const preset = presets.find(item => item.id === id);
    if (!preset) return;
    activePresetId = preset.id;
    preset.apply();
    updatePresetCardSelection();
    setStatus(`✅ تم تطبيق القالب: ${preset.name}`, 'success');
    if (typeof scheduleProjectAutosave === 'function') scheduleProjectAutosave();
  };

  grid.addEventListener('click', event => {
    const applyButton = event.target.closest('[data-preset-apply]');
    if (applyButton) {
      event.stopPropagation();
      applyPreset(applyButton.dataset.presetApply);
      return;
    }
    const card = event.target.closest('.preset-card');
    if (!card) return;
    updatePresetCardSelection();
    card.classList.add('preview-selected');
    const preset = presets.find(item => item.id === card.dataset.presetId);
    if (preset) setStatus(`👁️ معاينة القالب: ${preset.name} — اضغط «تطبيق القالب» لتثبيته`, 'success');
  });

  grid.addEventListener('keydown', event => {
    if (!['Enter', ' '].includes(event.key)) return;
    const card = event.target.closest('.preset-card');
    if (!card || event.target.closest('button')) return;
    event.preventDefault();
    applyPreset(card.dataset.presetId);
  });
}

