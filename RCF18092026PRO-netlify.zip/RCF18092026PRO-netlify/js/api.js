// ============ مصادر النص القرآني حسب الرواية ============
// مهم: مصدر النص مستقل تماماً عن المقرئ الصوتي المختار.
// لا نستخدم reciterSelect داخل طلب نص القرآن حتى لا يتحول معرّف المقرئ
// إلى edition للنص، ولا يحدث خلط بين الصوت والرواية.
const quranTextSources = {
  hafs: {
    label: 'حفص عن عاصم',
    provider: 'alquran.cloud',
    edition: 'quran-uthmani'
  },
  warsh: {
    label: 'ورش عن نافع',
    provider: 'fawazahmed0/quran-api',
    edition: 'ara-quranwarsh'
  },
};

function getQuranTextSource(riwayah = currentRiwayah) {
  return quranTextSources[riwayah] || null;
}

function clearRiwayahTextCache(surahNum = null) {
  if (surahNum == null) {
    riwayahAyahsData = {};
    return;
  }
  delete riwayahAyahsData[Number(surahNum)];
}

// ============ جلب النص القرآني حسب الرواية (مُصلَّح) ============
async function fetchRiwayahText(surahNum, riwayah, requestContext = null) {
  const statusEl = document.getElementById('riwayahStatus');
  const source = getQuranTextSource(riwayah);
  const surahNumInt = Number.parseInt(surahNum, 10);

  if (!source || !Number.isInteger(surahNumInt) || surahNumInt < 1 || surahNumInt > 114) {
    const message = `رواية ${riwayah || 'غير معروفة'} غير مدعومة أو رقم السورة غير صالح.`;
    if (statusEl) {
      statusEl.textContent = `❌ ${message} لم يتم استخدام نص بديل.`;
      statusEl.style.color = '#e74c3c';
    }
    throw new Error(message);
  }

  // حفص: يتم تحميل النص مباشرة من مصدر نصي مستقل عن المقرئ الصوتي.
  // لا نعتمد على reciterSelect هنا إطلاقاً.
  if (riwayah === 'hafs') {
    if (statusEl) {
      statusEl.textContent = '⏳ جاري التحقق من نص حفص من المصدر النصي الرسمي...';
      statusEl.style.color = '#f39c12';
    }

    if (requestContext && !isAsyncRequestCurrent('content', requestContext)) throw new DOMException('تم إلغاء الطلب القديم', 'AbortError');
    const res = await fetchWithTimeout(`https://api.alquran.cloud/v1/surah/${surahNumInt}/${source.edition}`, {
      method: 'GET',
      cache: 'no-store',
      headers: { Accept: 'application/json' },
      signal: requestContext?.signal
    });
    if (!res.ok) throw new Error(`فشل مصدر نص حفص (HTTP ${res.status})`);

    const data = await res.json();
    const parsed = Array.isArray(data?.data?.ayahs) ? data.data.ayahs.map(item => ({
      numberInSurah: Number(item?.numberInSurah),
      text: String(item?.text || '').trim()
    })) : null;
    const validation = validateRiwayahAyahs(parsed, surahNumInt);
    if (!validation.valid) throw new Error(`نص حفص غير صالح: ${validation.message}`);

    riwayahAyahsData[surahNumInt] = Object.fromEntries(
      validation.ayahs.map(item => [item.numberInSurah, item.text])
    );

    if (statusEl) {
      statusEl.textContent = `✅ تم التحقق من ${validation.ayahs.length} آية برواية حفص عن عاصم.`;
      statusEl.style.color = '#7ed6a5';
    }
    return riwayahAyahsData[surahNumInt];
  }

  try {
    if (statusEl) {
      statusEl.textContent = `⏳ جاري جلب نص رواية ${source.label}...`;
      statusEl.style.color = '#f39c12';
    }

    // نمسح أي نسخة قديمة قبل طلب المصدر الجديد حتى لا تختلط سورة/رواية سابقة.
    clearRiwayahTextCache(surahNumInt);

    // مصدر النص: fawazahmed0/quran-api.
    // نتبع آلية fallback الخاصة بالمصدر: jsDelivr ثم raw GitHub،
    // لكن لا ننتقل أبداً إلى نص حفص عند فشل رواية أخرى.
    const baseUrls = [
      `https://cdn.jsdelivr.net/gh/fawazahmed0/quran-api@1/editions/${source.edition}/${surahNumInt}`,
      `https://raw.githubusercontent.com/fawazahmed0/quran-api/1/editions/${source.edition}/${surahNumInt}`
    ];

    const urls = [];
    baseUrls.forEach(base => {
      urls.push(`${base}.min.json`);
      urls.push(`${base}.json`);
    });

    let ayahList = null;
    let sourceUrl = '';
    let lastError = null;

    for (const url of urls) {
      try {
        const controller = typeof AbortController !== 'undefined' ? new AbortController() : null;
        const timeoutId = setTimeout(() => {
          try { controller?.abort(); } catch (e) {}
        }, 12000);

        let response;
        try {
          response = await fetchWithTimeout(url, {
            method: 'GET',
            cache: 'no-store',
            headers: { Accept: 'application/json' },
            signal: requestContext?.signal || controller?.signal
          });
        } finally {
          clearTimeout(timeoutId);
        }

        if (!response.ok) {
          lastError = new Error(`HTTP ${response.status}`);
          continue;
        }

        const data = await response.json();
        const parsed = parseFawazAyahs(data);
        const validation = validateRiwayahAyahs(parsed, surahNumInt);

        if (!validation.valid) {
          lastError = new Error(validation.message);
          continue;
        }

        ayahList = validation.ayahs;
        sourceUrl = url;
        break;
      } catch (e) {
        lastError = e;
      }
    }

    if (!ayahList || ayahList.length === 0) {
      throw new Error(
        lastError?.message || `تعذّر العثور على بيانات رواية ${source.label} للسورة ${surahNumInt}`
      );
    }

    riwayahAyahsData[surahNumInt] = Object.fromEntries(
      ayahList.map(item => [item.numberInSurah, item.text])
    );

    const count = Object.keys(riwayahAyahsData[surahNumInt]).length;
    const expectedCount = Number(surahsData.find(s => Number(s.number) === surahNumInt)?.numberOfAyahs)
      || Number(fullSurahData?.numberOfAyahs)
      || count;

    if (count !== expectedCount) {
      clearRiwayahTextCache(surahNumInt);
      throw new Error(`عدد آيات الرواية غير مطابق: ${count} بدل ${expectedCount}`);
    }

    console.info(`✅ ${source.label}: تم تحميل ${count} آية من المصدر`, sourceUrl);

    if (statusEl) {
      statusEl.textContent = `✅ تم جلب ${count} آية برواية ${source.label}`;
      statusEl.style.color = '#7ed6a5';
    }

    return riwayahAyahsData[surahNumInt];
  } catch (e) {
    clearRiwayahTextCache(surahNumInt);
    console.warn(`تعذّر جلب نص رواية ${source.label}:`, e);
    if (statusEl) {
      statusEl.textContent = `❌ تعذّر جلب نص ${source.label}. لن يتم استخدام نص حفص كبديل.`;
      statusEl.style.color = '#e74c3c';
    }
    throw new Error(`فشل تحميل نص ${source.label}: ${e.message || e}`);
  }
}

// ============ دوال استخراج وتحقيق نص الرواية ============

function parseFawazAyahs(data) {
  if (!data) return null;

  // endpoint الخاص بالسورة في quran-api يعيد عادةً:
  // { chapter: [{ chapter, verse, text }, ...] }
  if (Array.isArray(data.chapter)) {
    return data.chapter.map((item, idx) => ({
      numberInSurah: Number(item?.verse ?? item?.ayah ?? item?.aya ?? idx + 1),
      text: String(item?.text ?? item?.arabic ?? item?.content ?? '').trim()
    }));
  }

  // احتياط لبنية مصفوفة مباشرة.
  if (Array.isArray(data)) {
    return data.map((item, idx) => ({
      numberInSurah: Number(item?.verse ?? item?.ayah ?? item?.aya ?? item?.numberInSurah ?? idx + 1),
      text: String(item?.text ?? item?.arabic ?? item?.content ?? '').trim()
    }));
  }

  // احتياط لبنية { ayahs: [...] }.
  if (Array.isArray(data.ayahs)) {
    return data.ayahs.map((item, idx) => ({
      numberInSurah: Number(item?.numberInSurah ?? item?.verse ?? item?.ayah ?? item?.aya ?? idx + 1),
      text: String(item?.text ?? item?.arabic ?? item?.content ?? '').trim()
    }));
  }

  return null;
}

function validateRiwayahAyahs(ayahs, surahNum) {
  if (!Array.isArray(ayahs) || ayahs.length === 0) {
    return { valid: false, message: `لا توجد آيات للسورة ${surahNum}` };
  }

  const cleaned = ayahs
    .map((item, idx) => ({
      numberInSurah: Number(item?.numberInSurah),
      text: String(item?.text || '').trim(),
      index: idx
    }))
    .filter(item => Number.isInteger(item.numberInSurah) && item.numberInSurah > 0 && item.text);

  if (cleaned.length !== ayahs.length) {
    return { valid: false, message: 'توجد آيات ناقصة أو أرقام آيات غير صالحة' };
  }

  cleaned.sort((a, b) => a.numberInSurah - b.numberInSurah);

  for (let i = 0; i < cleaned.length; i++) {
    const expected = i + 1;
    if (cleaned[i].numberInSurah !== expected) {
      return {
        valid: false,
        message: `ترقيم الآيات غير متسلسل عند الآية ${expected}`
      };
    }

    if (i > 0 && cleaned[i].numberInSurah === cleaned[i - 1].numberInSurah) {
      return {
        valid: false,
        message: `رقم الآية ${cleaned[i].numberInSurah} مكرر`
      };
    }
  }

  return {
    valid: true,
    ayahs: cleaned.map(({ numberInSurah, text }) => ({ numberInSurah, text }))
  };
}

// ============ اكتشاف مفاتيح الترجمة ============
async function discoverTranslations() {
  try {
    const res = await fetchWithTimeout('https://quranenc.com/api/v1/translations/list/?localization=ar');
    if (!res.ok) throw new Error('HTTP ' + res.status);
    const data = await res.json();
    availableTranslations = {};
    const list = Array.isArray(data) ? data : (data.translations || data.data || []);
    list.forEach(t => {
      const key = t.key || t.translation_key;
      if (key) {
        availableTranslations[key] = {
          title: t.title || key,
          lang: t.language_iso_code || '',
          version: t.version || ''
        };
      }
    });
    return availableTranslations;
  } catch (e) {
    availableTranslations = {
      'english_saheeh': { title: 'الإنجليزية - صحيح إنترناشونال', lang: 'en' },
      'french_rashid':  { title: 'الفرنسية - رشيد معاش', lang: 'fr' },
      'spanish_noor':   { title: 'الإسبانية - نور إنترناشونال', lang: 'es' },
      'german_bubenheim': { title: 'الألمانية - بوبنهايم', lang: 'de' },
      'indonesian_affairs': { title: 'الإندونيسية - وزارة الشؤون', lang: 'id' },
      'urdu_junagarhi': { title: 'الأردية - جناغرهي', lang: 'ur' },
      'turkish_diyanet':{ title: 'التركية - ديانت', lang: 'tr' },
      'russian_abuadel':{ title: 'الروسية - أبو عادل', lang: 'ru' }
    };
    return availableTranslations;
  }
}

// ============ جلب الترجمة ============
async function fetchTranslations(surahNum, transKey, requestContext = null) {
  if (!transKey) {
    translationsData = {};
    document.getElementById('translationStatus').textContent = '';
    return true;
  }
  try {
    document.getElementById('translationStatus').textContent = '⏳ جاري جلب الترجمة...';
    document.getElementById('translationStatus').style.color = '#f39c12';

    if (requestContext && !isAsyncRequestCurrent(requestContext.kind, requestContext)) throw new DOMException('تم إلغاء طلب الترجمة القديم', 'AbortError');
    const res = await fetchWithTimeout(`https://quranenc.com/api/v1/translation/sura/${transKey}/${surahNum}`, { signal: requestContext?.signal });
    if (!res.ok) throw new Error('HTTP ' + res.status);
    const data = await res.json();

    let list = null;
    if (Array.isArray(data)) list = data;
    else if (data && Array.isArray(data.result)) list = data.result;
    else if (data && Array.isArray(data.data)) list = data.data;

    if (!list || list.length === 0) throw new Error('لا توجد بيانات');

    translationsData = {};
    list.forEach(item => {
      const ayahNum = item.aya || item.ayah || item.aya_number;
      const text = item.translation || item.text;
      if (ayahNum != null && text) translationsData[ayahNum] = { text, footnotes: item.footnotes || '' };
    });

    const count = Object.keys(translationsData).length;
    if (count === 0) throw new Error('لم يتم استخراج ترجمة');

    document.getElementById('translationStatus').textContent = `✅ تم جلب ${count} ترجمة`;
    document.getElementById('translationStatus').style.color = '#7ed6a5';
    return true;
  } catch (e) {
    if (isAbortError(e) || (requestContext && !isAsyncRequestCurrent(requestContext.kind, requestContext))) return false;
    translationsData = {};
    document.getElementById('translationStatus').textContent = '❌ فشل جلب الترجمة: ' + e.message;
    document.getElementById('translationStatus').style.color = '#e74c3c';
    return false;
  }
}

// ============ جلب المختصر في التفسير (معاني القرآن) ============
async function fetchTafsirMukhtasar(surahNum, requestContext = null) {
  if (!tafsirEnabled) {
    tafsirData = {};
    document.getElementById('tafsirStatus').textContent = '';
    return true;
  }
  try {
    document.getElementById('tafsirStatus').textContent = '⏳ جاري جلب المختصر في التفسير...';
    document.getElementById('tafsirStatus').style.color = '#f39c12';

    const slug = 'ar-tafsir-al-mukhtasar';
    const url = `https://cdn.jsdelivr.net/gh/spa5k/tafsir_api@main/tafsir/${slug}/${surahNum}.json`;

    if (requestContext && !isAsyncRequestCurrent(requestContext.kind, requestContext)) throw new DOMException('تم إلغاء طلب التفسير القديم', 'AbortError');
    const res = await fetchWithTimeout(url, { signal: requestContext?.signal });
    if (!res.ok) throw new Error('HTTP ' + res.status);
    const data = await res.json();

    let list = null;
    if (data && Array.isArray(data.ayahs)) list = data.ayahs;
    else if (Array.isArray(data)) list = data;

    if (!list || list.length === 0) throw new Error('لا يوجد تفسير');

    tafsirData = {};
    list.forEach(item => {
      const ayahNum = item.ayah ?? item.ayah_number ?? item.numberInSurah;
      const rawText = item.text || item.tafsir || item.content || '';
      if (ayahNum != null && rawText) {
        const cleanText = String(rawText)
          .replace(/<[^>]+>/g, '').replace(/&nbsp;/g, ' ')
          .replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>')
          .replace(/\s+/g, ' ').trim();
        tafsirData[ayahNum] = cleanText;
      }
    });

    const count = Object.keys(tafsirData).length;
    if (count === 0) throw new Error('لم يتم استخراج تفسير');

    document.getElementById('tafsirStatus').textContent = `✅ تم جلب التفسير (${count} آية)`;
    document.getElementById('tafsirStatus').style.color = '#7ed6a5';
    return true;
  } catch (e) {
    if (isAbortError(e) || (requestContext && !isAsyncRequestCurrent(requestContext.kind, requestContext))) return false;
    tafsirData = {};
    document.getElementById('tafsirStatus').textContent = '⚠️ تعذّر جلب التفسير: ' + e.message;
    document.getElementById('tafsirStatus').style.color = '#e74c3c';
    return false;
  }
}

// ============ تحميل السور ============
async function loadSurahs() {
  try {
    setStatus('جاري تحميل قائمة السور...', 'loading');
    const res = await fetchWithTimeout('https://api.alquran.cloud/v1/surah');
    const data = await res.json();
    surahsData = data.data;
    renderSurahOptions(surahsData);
    if (pendingProjectRestore) {
      const project = pendingProjectRestore;
      pendingProjectRestore = null;
      restoreProject(project);
    }
    setStatus('تم التحميل ✅ اختر السورة ثم اضغط "جلب الآيات"', 'success');
    resetHistoryBaseline();
  } catch (e) {
    setStatus('❌ فشل تحميل السور. تحقق من الاتصال', 'error');
  }
}

function renderSurahOptions(list) {
  const select = document.getElementById('surahSelect');
  const currentVal = select.value;
  select.innerHTML = '<option value="">-- اختر السورة --</option>';
  list.forEach(s => {
    const opt = document.createElement('option');
    opt.value = s.number;
    opt.textContent = `${s.number}. ${s.name} (${s.englishName})`;
    select.appendChild(opt);
  });
  if (currentVal) select.value = currentVal;
}

// تم حذف البحث الذكي عن السور — الاختيار مباشرة من القائمة الكاملة.
// ============ اختيار نطاق الآيات قبل الجلب ============
function syncAyahRangeControls() {
  const toggle = document.getElementById('ayahRangeToggle');
  const start = document.getElementById('startAyah');
  const end = document.getElementById('endAyah');
  const status = document.getElementById('rangeStatus');
  const surahNum = document.getElementById('surahSelect').value;
  const surah = surahsData.find(s => String(s.number) === String(surahNum));
  const max = surah ? Number(surah.numberOfAyahs) : 1;

  start.max = max;
  end.max = max;

  if (!toggle.checked) {
    start.disabled = true;
    end.disabled = true;
    start.value = 1;
    end.value = max;
    status.textContent = 'سيتم جلب وعرض جميع آيات السورة. فعّل الاختيار لتحديد نطاق محدد.';
    status.style.color = '#7a8a99';
    return;
  }

  start.disabled = false;
  end.disabled = false;
  let s = parseInt(start.value, 10) || 1;
  let e = parseInt(end.value, 10) || s;
  s = Math.max(1, Math.min(s, max));
  e = Math.max(s, Math.min(e, max));
  start.value = s;
  end.value = e;
  status.textContent = `سيتم جلب وعرض الآيات من ${s} إلى ${e} فقط.`;
  status.style.color = '#7ed6a5';
}

function getRequestedAyahRange() {
  const toggle = document.getElementById('ayahRangeToggle');
  const surahNum = document.getElementById('surahSelect').value;
  const surah = surahsData.find(s => String(s.number) === String(surahNum));
  const max = surah ? Number(surah.numberOfAyahs) : (fullSurahData?.numberOfAyahs || 1);

  if (!toggle.checked) return { start: 1, end: max, enabled: false };

  let start = parseInt(document.getElementById('startAyah').value, 10) || 1;
  let end = parseInt(document.getElementById('endAyah').value, 10) || start;
  start = Math.max(1, Math.min(start, max));
  end = Math.max(start, Math.min(end, max));
  document.getElementById('startAyah').value = start;
  document.getElementById('endAyah').value = end;
  return { start, end, enabled: true };
}

// ============ P1-2: كاش مدد الصوت + فحص متوازي ============
// يخزن مدة كل آية لكل قارئ لمدة 30 يوماً لتسريع الزيارات المتكررة وتقليل الضغط على everyayah.
const AUDIO_DURATION_CACHE_KEY = 'quranStudio.audioDur.v1';
const AUDIO_CACHE_TTL_MS = 30 * 24 * 3600 * 1000;
const AUDIO_CACHE_MAX_ENTRIES = 2000;

function _readAudioDurationCache() {
  try {
    const raw = localStorage.getItem(AUDIO_DURATION_CACHE_KEY);
    const parsed = raw ? JSON.parse(raw) : {};
    return parsed && typeof parsed === 'object' ? parsed : {};
  } catch (e) { return {}; }
}

function getCachedAudioDuration(reciterValue, surahNum, ayahNum) {
  try {
    const key = `${reciterValue}|${Number(surahNum)}|${Number(ayahNum)}`;
    const entry = _readAudioDurationCache()[key];
    if (!entry || typeof entry !== 'object') return null;
    if (!entry.url || !(Number(entry.durationMs) > 0)) return null;
    if (Date.now() - Number(entry.at || 0) > AUDIO_CACHE_TTL_MS) return null;
    return { url: String(entry.url), durationMs: Number(entry.durationMs) };
  } catch (e) { return null; }
}

function setCachedAudioDuration(reciterValue, surahNum, ayahNum, url, durationMs) {
  try {
    if (!url || !(Number(durationMs) > 0)) return;
    const cache = _readAudioDurationCache();
    const key = `${reciterValue}|${Number(surahNum)}|${Number(ayahNum)}`;
    cache[key] = { url: String(url), durationMs: Number(durationMs), at: Date.now() };
    const keys = Object.keys(cache);
    if (keys.length > AUDIO_CACHE_MAX_ENTRIES) {
      // إزالة الأقدم أولاً.
      const sorted = keys.map(k => [k, Number(cache[k]?.at || 0)]).sort((a, b) => a[1] - b[1]);
      const overflow = sorted.length - AUDIO_CACHE_MAX_ENTRIES;
      for (let i = 0; i < overflow; i++) delete cache[sorted[i][0]];
    }
    try { localStorage.setItem(AUDIO_DURATION_CACHE_KEY, JSON.stringify(cache)); } catch (e) {}
  } catch (e) {}
}

async function mapWithConcurrency(items, limit, fn) {
  const results = new Array(items.length);
  let next = 0;
  const workers = new Array(Math.max(1, Math.min(limit || 5, items.length))).fill(0).map(async () => {
    while (true) {
      const i = next++;
      if (i >= items.length) return;
      results[i] = await fn(items[i], i);
    }
  });
  await Promise.all(workers);
  return results;
}

// ============ جلب صوت المقرئ للنطاق المحدد ============
let activeReciterAudioPreparation = null;

async function prepareReciterAudio(showStatus = true) {
  // لا تُرجع Promise قديمة تم إلغاؤها: بعد تغيير القارئ/السورة قد يبقى الـ Promise
  // السابق موجوداً لبرهة حتى ينفذ finally. نتحقق من token قبل إعادة استخدامه.
  if (activeReciterAudioPreparation && isAsyncRequestCurrent('audio', activeReciterAudioPreparation.request)) {
    return activeReciterAudioPreparation.promise;
  }

  const request = beginAsyncRequest('audio');
  const preparation = { request, promise: null };
  preparation.promise = (async () => {
    if (!fullSurahData || !currentAyahs.length) { if (showStatus) setAudioStatus('⚠️ اضغط "جلب الآيات" أولاً، ثم اختر نطاق الآيات.', 'warning'); return false; }
    const surahNum = Number(document.getElementById('surahSelect').value);
    const reciterValue = document.getElementById('reciterSelect').value;
    const reciterConfig = (riwayahReciters[currentRiwayah] || []).find(r => r.value === reciterValue);
    const btn = document.getElementById('prepareAudioBtn');
    const originalLabel = btn ? btn.textContent : '';
    if (!reciterConfig) { setAudioStatus('❌ لم يتم العثور على إعداد صوتي مطابق للرواية الحالية.', 'error'); return false; }
    if (btn) { btn.disabled = true; btn.innerHTML = '<span class="loader"></span> جاري فحص جميع المقاطع الصوتية...'; }
    setAudioStatus(`⏳ جاري فحص صوت ${reciterConfig.label} للآيات ${currentAyahs[0]?.numberInSurah}–${currentAyahs[currentAyahs.length - 1]?.numberInSurah} قبل السماح بالتصدير...`, 'warning');
    const pad3 = n => String(n).padStart(3, '0');
    const ayahFileName = ayah => `${pad3(surahNum)}${pad3(Number(ayah.numberInSurah))}.mp3`;
    function assertCurrent() {
      if (!isAsyncRequestCurrent('audio', request)) throw new DOMException('تم إلغاء تجهيز صوت قديم', 'AbortError');
      if (Number(document.getElementById('surahSelect').value) !== surahNum || document.getElementById('reciterSelect').value !== reciterValue || currentRiwayah !== fullSurahData?.riwayah) throw new DOMException('تغيرت اختيارات الصوت أثناء التجهيز', 'AbortError');
    }
    function buildAudioCandidates(ayah) {
      const file = ayahFileName(ayah), candidates=[];
      if (reciterConfig.everyAyahFolder) candidates.push(`https://everyayah.com/data/${reciterConfig.everyAyahFolder}/${file}`);
      if (reciterConfig.maqraFolder) candidates.push(`${reciterConfig.maqraFolder}/${file}`);
      if (currentRiwayah === 'hafs') { const globalNumber=Number(ayah.number); if(Number.isInteger(globalNumber)) candidates.push(`https://api.alquran.cloud/v1/ayah/${globalNumber}/${encodeURIComponent(reciterValue)}`); }
      return [...new Set(candidates)];
    }
    function resolveApiAudioUrl(apiUrl) {
      return new Promise(resolve=>{
        const controller=createAbortController(); let settled=false;
        const finish=value=>{if(settled)return;settled=true;clearTimeout(timer);request.signal?.removeEventListener('abort',onAbort);resolve(value);};
        const onAbort=()=>{try{controller?.abort();}catch(e){} finish(null);};
        const timer=setTimeout(()=>{try{controller?.abort();}catch(e){} finish(null);},7000);
        request.signal?.addEventListener('abort',onAbort,{once:true});
        fetchWithTimeout(apiUrl,{signal:controller?.signal},7000).then(r=>r.ok?r.json():null).then(data=>finish(data?.data?.audio||null)).catch(()=>finish(null));
      });
    }
    function probeAudioUrl(url,timeoutMs=8000){
      return new Promise(resolve=>{
        const probe=new Audio(); let settled=false;
        const finish=durationMs=>{if(settled)return;settled=true;clearTimeout(timer);request.signal?.removeEventListener('abort',onAbort);probe.pause();probe.removeAttribute('src');try{probe.load();}catch(e){}resolve(Number.isFinite(durationMs)&&durationMs>0?durationMs:0);};
        const onAbort=()=>finish(0); const timer=setTimeout(()=>finish(0),timeoutMs);
        request.signal?.addEventListener('abort',onAbort,{once:true}); probe.preload='metadata';
        probe.onloadedmetadata=()=>{const duration=Number(probe.duration);finish(Number.isFinite(duration)&&duration>0?duration*1000:0);}; probe.onerror=()=>finish(0); probe.src=url; try{probe.load();}catch(e){finish(0);}
      });
    }
    try {
      // P1-2: فحص متوازي (5) مع كاش محلي — نفس نتيجة الفحص التسلسلي بسرعة أعلى بكثير للسور الطويلة.
      let verified=0, completed=0, cacheHits=0;
      const failed=[];
      const prepared=new Array(currentAyahs.length);
      const snapshot = currentAyahs.slice();
      const checkOneAyah = async (ayah, i) => {
        assertCurrent();
        // 1) الكاش أولاً: يتجاوز الشبكة كلياً عند التكرار.
        try {
          const cached = getCachedAudioDuration(reciterValue, surahNum, ayah.numberInSurah);
          if (cached?.url && cached.durationMs > 0) {
            cacheHits++;
            return { index: i, ok: true, ayah, url: cached.url, durationMs: cached.durationMs, fromCache: true };
          }
        } catch (e) {}
        const rawCandidates=buildAudioCandidates(ayah);
        let candidates=rawCandidates;
        if(currentRiwayah==='hafs'&&rawCandidates.length){
          const resolved=await resolveApiAudioUrl(rawCandidates[rawCandidates.length-1]);
          assertCurrent();
          candidates=rawCandidates.slice(0,-1);
          if(resolved)candidates.push(resolved);
        }
        for(const url of candidates){
          assertCurrent();
          const durationMs=await probeAudioUrl(url);
          assertCurrent();
          if(durationMs>0){
            try { setCachedAudioDuration(reciterValue, surahNum, ayah.numberInSurah, url, durationMs); } catch (e) {}
            return { index: i, ok: true, ayah, url, durationMs, fromCache: false };
          }
        }
        return { index: i, ok: false, ayah };
      };
      const results = await mapWithConcurrency(snapshot, 5, checkOneAyah);
      assertCurrent();
      results.forEach(r => {
        completed++;
        if (r?.ok) {
          verified++;
          prepared[r.index] = { ...r.ayah, audio: r.url, audioCandidates: [r.url], audioCandidateIndex: 0, audioVerified: true, audioDurationMs: r.durationMs };
        } else {
          const ayah = r?.ayah || snapshot[r?.index ?? 0];
          prepared[r?.index ?? 0] = { ...ayah, audio: null, audioCandidates: [], audioCandidateIndex: 0, audioVerified: false };
          failed.push(Number(ayah?.numberInSurah));
        }
        if (completed % 2 === 0 || completed === snapshot.length) {
          const cacheNote = cacheHits ? ` (من الكاش: ${cacheHits})` : '';
          setAudioStatus(`⏳ تم فحص ${completed}/${snapshot.length} آية — الصالح: ${verified}${cacheNote}...`, 'warning');
        }
      });
      assertCurrent(); currentAyahs=prepared;
      if(Array.isArray(fullSurahData?.ayahs)){const byNumber=new Map(prepared.map(a=>[Number(a.numberInSurah),a]));fullSurahData.ayahs=fullSurahData.ayahs.map(a=>{const hit=byNumber.get(Number(a.numberInSurah));return hit?.audioVerified?{...a,audio:hit.audio,audioCandidates:hit.audioCandidates,audioCandidateIndex:hit.audioCandidateIndex,audioVerified:true,audioDurationMs:hit.audioDurationMs}:a;});}
      audioSourceMode='reciter';document.getElementById('audioModeReciter').checked=true;updateAudioSourceUI();audio.pause();audio.removeAttribute('src');audio.load();
      const first=currentAyahs[0]?.numberInSurah,last=currentAyahs[currentAyahs.length-1]?.numberInSurah;
      if(verified===currentAyahs.length){setAudioStatus(`✅ تم التحقق بنجاح من ${verified} آية — ${reciterConfig.label} — الآيات ${first}–${last}. 🔒 التصدير متاح الآن.`,'success');return true;}
      setAudioStatus(`❌ لم يكتمل التحقق الصوتي: ${verified}/${currentAyahs.length} آية فقط صالحة. الآيات التي فشل مصدرها: ${failed.join('، ')}. لن يبدأ التصدير حتى تصبح جميع الآيات صالحة.`,'error');return false;
    } catch(e){if(isAbortError(e))return false;console.error('prepareReciterAudio preflight error:',e);setAudioStatus('❌ تعذر إكمال الفحص المسبق للصوت: '+(e.message||e),'error');return false;}
    finally{if(btn){btn.disabled=false;btn.textContent=originalLabel;}}
  })();
  activeReciterAudioPreparation = preparation;
  try {
    return await preparation.promise;
  } finally {
    if (isAsyncRequestCurrent('audio', request)) asyncRequestState.audio.controller = null;
    if (activeReciterAudioPreparation === preparation) activeReciterAudioPreparation = null;
  }
}
