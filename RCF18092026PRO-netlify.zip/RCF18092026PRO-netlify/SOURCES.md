# مصادر وتراخيص — ريلز القرآن الكريم Pro

> وثيقة صيانة (P3): كل مصدر خارجي مستخدم في التطبيق مع الغرض والرخصة قدر الإمكان.
> راجع `index.html` (CSP) و `js/api.js` و `css/base.css` و `js/state.js` للمطابقة.

## 1) النصوص القرآنية
| الرواية | المصدر | الغرض | ملاحظات |
|---|---|---|---|
| حفص عن عاصم | `https://api.alquran.cloud/v1/surah/{n}/quran-uthmani` | النص الأساسي + قائمة السور | مزود AlQuran Cloud (بيانات Tanzil/Open Source) |
| ورش عن نافع | `https://cdn.jsdelivr.net/gh/fawazahmed0/quran-api@1/editions/ara-quranwarsh/{n}(.min).json` مع fallback إلى `raw.githubusercontent.com` | نص ورش فقط — لا fallback إلى حفص عند الفشل (قرار شرعي مقصود في `api.js`) | مشروع fawazahmed0/quran-api (مفتوح المصدر) |

## 2) الخطوط
| الخط | المصدر | الاستخدام |
|---|---|---|
| KFGQPC Hafs18 / Warsh10 / HafsSmart8 | `cdn.jsdelivr.net/gh/thetruetruth/quran-data-kfgqpc` | الرسم العثماني الرسمي — يُنتظر عبر `ensureQuranFontsLoaded` قبل الرسم/التصدير |
| UthmanicHafs / UthmanTNaskh | `cdn.jsdelivr.net/gh/mustafa0x/qpc-fonts` | بدائل حفص فقط — محظورة عند تفعيل ورش عبر `isFontAllowedForRiwayah` (v5) |
| WarshV8 | `cdn.jsdelivr.net/gh/fawazahmed0/quran-api@1/fonts` | بديل ورش (v10: مُوثّق الوجود `warsh-v8-full.woff2`) |
| Uthmanic Warsh v2.1 | `cdn.jsdelivr.net/gh/mustafa0x/qpc-fonts@master/mushaf-v4-warsh` (بديل `raw.githubusercontent.com/nuqayah`) | رسم ورش العثماني الأصلي QCF — v10 |
| Lateef / Noto Naskh / Scheherazade (SIL) | `fonts.googleapis.com` | متوافقة مع رسم ورش — v10 |
| Cairo/Amiri/Tajawal/... | `fonts.googleapis.com` + `fonts.gstatic.com` | واجهة + ترجمة (يُحمّل الديناميكي عبر `ensureGoogleFont`) |

## 3) الصوت
| المصدر | النمط | ملاحظات CORS |
|---|---|---|
| `https://everyayah.com/data/{folder}/{SSSA}.mp3` | آية-بآية لكل قارئ (حفص 14 قارئاً + ورش) | قد يحجب CORS — التطبيق يفحص عبر `probeAudioCorsOk` ويحذر من فيديو صامت ويقترح الرفع اليدوي |
| `https://huggingface.co/datasets/maqra-project/...` | مصدر ورش (إبراهيم الدوسري) | نفس ملاحظة CORS |
| `https://api.alquran.cloud/v1/ayah/{global}/{reciter}` | حل احتياطي لحفص فقط (يُحلل إلى mp3 مباشر) | — |
| رفع يدوي `audio/*` (حتى 200MB) | بديل مضمون CORS لأنه Blob محلي | يُوزع زمنياً على الآيات |

## 4) الترجمة والتفسير
| المحتوى | المصدر |
|---|---|
| 8 ترجمات (EN/FR/ES/DE/ID/UR/TR/RU) | `https://quranenc.com/api/v1/...` — موسوعة القرآن الرسمية |
| المختصر في التفسير (معاني القرآن) | `https://cdn.jsdelivr.net/gh/spa5k/tafsir_api@main/tafsir/ar-tafsir-al-mukhtasar/{n}.json` |

## 5) التخزين المحلي
- المشاريع: `localStorage` بنمط خفيف (مراجع سورة/نطاق/رواية + إعدادات) — النصوص تُعاد جلبها (P0-2).
- التسجيلات (فيديو Blob): `IndexedDB` قاعدة `quranStudioRecordings`.
- كاش مدد الصوت: `localStorage` مفتاح `quranStudio.audioDur.v1` (TTL 30 يوماً).

## 6) التنبيه الشرعي والتقني
- لا خلط بين الروايات نصاً وصوتاً وخطاً: القارئ مقيد بقائمة `riwayahReciters` والخط مقيد بـ `riwayahFontMap`.
- التصدير يتطلب فحص كل آيات النطاق (`prepareReciterAudio`) ولا يبدأ ناقصاً.
- الحقوق لأصحابها (التلاوات والمصاحف). هذا المشروع واجهة تجميع فقط ولا يدعي ملكية المحتوى.
